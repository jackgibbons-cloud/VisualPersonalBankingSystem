﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBudgets
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBudgets))
        Me.DataGridDirBudget = New System.Windows.Forms.DataGridView()
        Me.BudgetNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BudgetTypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DescriptionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PeriodFromDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PeriodToDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartMonthDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RefreshReqdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DirbudBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VPBSDataSet = New VPBS13.VPBSDataSet()
        Me.DirbudTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.dirbudTableAdapter()
        Me.VPBSTestDataSet = New VPBS13.VPBSTestDataSet()
        Me.DirbudTableAdapterTest = New VPBS13.VPBSTestDataSetTableAdapters.dirbudTableAdapter()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdRptOk = New System.Windows.Forms.Button()
        Me.cmdReport = New System.Windows.Forms.Button()
        Me.CmdSelect = New System.Windows.Forms.Button()
        Me.CmdClose = New System.Windows.Forms.Button()
        Me.CmdCancel = New System.Windows.Forms.Button()
        Me.CmdOk = New System.Windows.Forms.Button()
        Me.CmdChange = New System.Windows.Forms.Button()
        Me.CmdRepeat = New System.Windows.Forms.Button()
        Me.CmdDelete = New System.Windows.Forms.Button()
        Me.DataGridBudget = New System.Windows.Forms.DataGridView()
        Me.BudgetNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BudgetType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PeriodFrom = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IncomeExpDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget3DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget4DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget5DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget6DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget7DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget8DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget9DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget10DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget11DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget12DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual3DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual4DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual5DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual6DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual7DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual8DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual9DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual10DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual11DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual12DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance3DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance4DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance5DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance6DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance7DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance8DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance9DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance10DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance11DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance12DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BudgetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BudgetTableAdapterTest = New VPBS13.VPBSTestDataSetTableAdapters.BudgetTableAdapter()
        Me.BudgetTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.BudgetTableAdapter()
        Me.cmdScrollLft = New System.Windows.Forms.Button()
        Me.cmdScrollRgt = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cboIncExp = New System.Windows.Forms.ComboBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.txtHeading = New System.Windows.Forms.TextBox()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.lblIncExp = New System.Windows.Forms.Label()
        Me.lblAmt12 = New System.Windows.Forms.Label()
        Me.txtAmount12 = New System.Windows.Forms.TextBox()
        Me.txtAmount11 = New System.Windows.Forms.TextBox()
        Me.txtAmount10 = New System.Windows.Forms.TextBox()
        Me.lblAmt10 = New System.Windows.Forms.Label()
        Me.txtAmount9 = New System.Windows.Forms.TextBox()
        Me.lblAmt9 = New System.Windows.Forms.Label()
        Me.lblAmt11 = New System.Windows.Forms.Label()
        Me.txtAmount8 = New System.Windows.Forms.TextBox()
        Me.lblAmt8 = New System.Windows.Forms.Label()
        Me.txtAmount7 = New System.Windows.Forms.TextBox()
        Me.txtAmount6 = New System.Windows.Forms.TextBox()
        Me.lblAmt6 = New System.Windows.Forms.Label()
        Me.txtAmount5 = New System.Windows.Forms.TextBox()
        Me.lblAmt5 = New System.Windows.Forms.Label()
        Me.lblAmt7 = New System.Windows.Forms.Label()
        Me.txtAmount4 = New System.Windows.Forms.TextBox()
        Me.lblAmt4 = New System.Windows.Forms.Label()
        Me.txtAmount3 = New System.Windows.Forms.TextBox()
        Me.txtAmount2 = New System.Windows.Forms.TextBox()
        Me.lblAmt2 = New System.Windows.Forms.Label()
        Me.txtAmount1 = New System.Windows.Forms.TextBox()
        Me.lblAmt1 = New System.Windows.Forms.Label()
        Me.lblAmt3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.rdo3Option2 = New System.Windows.Forms.RadioButton()
        Me.rdo3Option1 = New System.Windows.Forms.RadioButton()
        Me.rdo3Option0 = New System.Windows.Forms.RadioButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.rdo2Option2 = New System.Windows.Forms.RadioButton()
        Me.rdo2Option1 = New System.Windows.Forms.RadioButton()
        Me.rdo2Option0 = New System.Windows.Forms.RadioButton()
        Me.lblBudgetHeader = New System.Windows.Forms.Label()
        Me.DataGridActuals = New System.Windows.Forms.DataGridView()
        Me.BudgetNoDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BudgetTypeDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PeriodFromDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CodeDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IncomeExpDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual1DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget1DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance1DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual2DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget2DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance2DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual3DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget3DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance3DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual4DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget4DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance4DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual5DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget5DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance5DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual6DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget6DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance6DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual7DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget7DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance7DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual8DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget8DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance8DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual9DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget9DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance9DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual10DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget10DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance10DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual11DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget11DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance11DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual12DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget12DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance12DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblHeader2 = New System.Windows.Forms.Label()
        Me.lblHeader3 = New System.Windows.Forms.Label()
        Me.lblHeader1 = New System.Windows.Forms.Label()
        Me.TotalsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridTotals = New System.Windows.Forms.DataGridView()
        Me.BudgetNoDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BudgetTypeDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PeriodFromDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CodeDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IncomeExpDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual1DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget1DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance1DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual2DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget2DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance2DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual3DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget3DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance3DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance4DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual4DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget4DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual5DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget5DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance5DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual6DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget6DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance6DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual7DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget7DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance7DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual8DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget8DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance8DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual9DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget9DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance9DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual10DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget10DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance10DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual11DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget11DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance11DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Actual12DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Budget12DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Variance12DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblHeader4 = New System.Windows.Forms.Label()
        Me.lblTotal2 = New System.Windows.Forms.Label()
        Me.lblTotal1 = New System.Windows.Forms.Label()
        Me.AxCrystalReport2 = New AxCrystal.AxCrystalReport()
        Me.VpbsArchiveDataSet = New VPBS13.VpbsArchiveDataSet()
        Me.DirbudTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.dirbudTableAdapter()
        Me.BudgetTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.BudgetTableAdapter()
        CType(Me.DataGridDirBudget, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DirbudBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VPBSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VPBSTestDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridBudget, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BudgetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.DataGridActuals, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TotalsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridTotals, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxCrystalReport2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VpbsArchiveDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridDirBudget
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.DataGridDirBudget.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridDirBudget.AutoGenerateColumns = False
        Me.DataGridDirBudget.BackgroundColor = System.Drawing.Color.White
        Me.DataGridDirBudget.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridDirBudget.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridDirBudget.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridDirBudget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridDirBudget.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BudgetNoDataGridViewTextBoxColumn, Me.BudgetTypeDataGridViewTextBoxColumn, Me.DescriptionDataGridViewTextBoxColumn, Me.PeriodFromDataGridViewTextBoxColumn, Me.PeriodToDataGridViewTextBoxColumn, Me.StartMonthDataGridViewTextBoxColumn, Me.StatusDataGridViewTextBoxColumn, Me.RefreshReqdDataGridViewTextBoxColumn})
        Me.DataGridDirBudget.Cursor = System.Windows.Forms.Cursors.Default
        Me.DataGridDirBudget.DataSource = Me.DirbudBindingSource
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridDirBudget.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridDirBudget.GridColor = System.Drawing.SystemColors.ControlLight
        Me.DataGridDirBudget.Location = New System.Drawing.Point(12, 39)
        Me.DataGridDirBudget.Name = "DataGridDirBudget"
        Me.DataGridDirBudget.ReadOnly = True
        Me.DataGridDirBudget.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridDirBudget.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridDirBudget.Size = New System.Drawing.Size(786, 243)
        Me.DataGridDirBudget.TabIndex = 1
        '
        'BudgetNoDataGridViewTextBoxColumn
        '
        Me.BudgetNoDataGridViewTextBoxColumn.DataPropertyName = "BudgetNo"
        Me.BudgetNoDataGridViewTextBoxColumn.HeaderText = "BudgetNo"
        Me.BudgetNoDataGridViewTextBoxColumn.Name = "BudgetNoDataGridViewTextBoxColumn"
        Me.BudgetNoDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BudgetTypeDataGridViewTextBoxColumn
        '
        Me.BudgetTypeDataGridViewTextBoxColumn.DataPropertyName = "BudgetType"
        Me.BudgetTypeDataGridViewTextBoxColumn.HeaderText = "BudgetType"
        Me.BudgetTypeDataGridViewTextBoxColumn.Name = "BudgetTypeDataGridViewTextBoxColumn"
        Me.BudgetTypeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DescriptionDataGridViewTextBoxColumn
        '
        Me.DescriptionDataGridViewTextBoxColumn.DataPropertyName = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.HeaderText = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.Name = "DescriptionDataGridViewTextBoxColumn"
        Me.DescriptionDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PeriodFromDataGridViewTextBoxColumn
        '
        Me.PeriodFromDataGridViewTextBoxColumn.DataPropertyName = "PeriodFrom"
        Me.PeriodFromDataGridViewTextBoxColumn.HeaderText = "PeriodFrom"
        Me.PeriodFromDataGridViewTextBoxColumn.Name = "PeriodFromDataGridViewTextBoxColumn"
        Me.PeriodFromDataGridViewTextBoxColumn.ReadOnly = True
        Me.PeriodFromDataGridViewTextBoxColumn.Width = 90
        '
        'PeriodToDataGridViewTextBoxColumn
        '
        Me.PeriodToDataGridViewTextBoxColumn.DataPropertyName = "PeriodTo"
        Me.PeriodToDataGridViewTextBoxColumn.HeaderText = "PeriodTo"
        Me.PeriodToDataGridViewTextBoxColumn.Name = "PeriodToDataGridViewTextBoxColumn"
        Me.PeriodToDataGridViewTextBoxColumn.ReadOnly = True
        Me.PeriodToDataGridViewTextBoxColumn.Width = 90
        '
        'StartMonthDataGridViewTextBoxColumn
        '
        Me.StartMonthDataGridViewTextBoxColumn.DataPropertyName = "StartMonth"
        Me.StartMonthDataGridViewTextBoxColumn.HeaderText = "StartMonth"
        Me.StartMonthDataGridViewTextBoxColumn.Name = "StartMonthDataGridViewTextBoxColumn"
        Me.StartMonthDataGridViewTextBoxColumn.ReadOnly = True
        Me.StartMonthDataGridViewTextBoxColumn.Width = 90
        '
        'StatusDataGridViewTextBoxColumn
        '
        Me.StatusDataGridViewTextBoxColumn.DataPropertyName = "Status"
        Me.StatusDataGridViewTextBoxColumn.HeaderText = "Status"
        Me.StatusDataGridViewTextBoxColumn.Name = "StatusDataGridViewTextBoxColumn"
        Me.StatusDataGridViewTextBoxColumn.ReadOnly = True
        Me.StatusDataGridViewTextBoxColumn.Width = 60
        '
        'RefreshReqdDataGridViewTextBoxColumn
        '
        Me.RefreshReqdDataGridViewTextBoxColumn.DataPropertyName = "RefreshReqd"
        Me.RefreshReqdDataGridViewTextBoxColumn.HeaderText = "RefreshReqd"
        Me.RefreshReqdDataGridViewTextBoxColumn.Name = "RefreshReqdDataGridViewTextBoxColumn"
        Me.RefreshReqdDataGridViewTextBoxColumn.ReadOnly = True
        Me.RefreshReqdDataGridViewTextBoxColumn.Width = 110
        '
        'DirbudBindingSource
        '
        Me.DirbudBindingSource.DataMember = "dirbud"
        Me.DirbudBindingSource.DataSource = Me.VPBSDataSet
        '
        'VPBSDataSet
        '
        Me.VPBSDataSet.DataSetName = "VPBSDataSet"
        Me.VPBSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DirbudTableAdapterLive
        '
        Me.DirbudTableAdapterLive.ClearBeforeFill = True
        '
        'VPBSTestDataSet
        '
        Me.VPBSTestDataSet.DataSetName = "VPBSTestDataSet"
        Me.VPBSTestDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DirbudTableAdapterTest
        '
        Me.DirbudTableAdapterTest.ClearBeforeFill = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmdRptOk)
        Me.GroupBox1.Controls.Add(Me.cmdReport)
        Me.GroupBox1.Controls.Add(Me.CmdSelect)
        Me.GroupBox1.Controls.Add(Me.CmdClose)
        Me.GroupBox1.Controls.Add(Me.CmdCancel)
        Me.GroupBox1.Controls.Add(Me.CmdOk)
        Me.GroupBox1.Controls.Add(Me.CmdChange)
        Me.GroupBox1.Controls.Add(Me.CmdRepeat)
        Me.GroupBox1.Controls.Add(Me.CmdDelete)
        Me.GroupBox1.Location = New System.Drawing.Point(11, 507)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(787, 66)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'cmdRptOk
        '
        Me.cmdRptOk.BackColor = System.Drawing.Color.LightGray
        Me.cmdRptOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRptOk.Location = New System.Drawing.Point(490, 19)
        Me.cmdRptOk.Name = "cmdRptOk"
        Me.cmdRptOk.Size = New System.Drawing.Size(80, 35)
        Me.cmdRptOk.TabIndex = 24
        Me.cmdRptOk.Text = "&Rpt&Ok"
        Me.cmdRptOk.UseVisualStyleBackColor = False
        '
        'cmdReport
        '
        Me.cmdReport.BackColor = System.Drawing.Color.LightGray
        Me.cmdReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdReport.Location = New System.Drawing.Point(103, 19)
        Me.cmdReport.Name = "cmdReport"
        Me.cmdReport.Size = New System.Drawing.Size(80, 35)
        Me.cmdReport.TabIndex = 23
        Me.cmdReport.Text = "&Report"
        Me.cmdReport.UseVisualStyleBackColor = False
        '
        'CmdSelect
        '
        Me.CmdSelect.BackColor = System.Drawing.Color.LightGray
        Me.CmdSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSelect.Location = New System.Drawing.Point(17, 19)
        Me.CmdSelect.Name = "CmdSelect"
        Me.CmdSelect.Size = New System.Drawing.Size(80, 35)
        Me.CmdSelect.TabIndex = 22
        Me.CmdSelect.Text = "&Select"
        Me.CmdSelect.UseVisualStyleBackColor = False
        '
        'CmdClose
        '
        Me.CmdClose.BackColor = System.Drawing.Color.LightGray
        Me.CmdClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdClose.Location = New System.Drawing.Point(683, 19)
        Me.CmdClose.Name = "CmdClose"
        Me.CmdClose.Size = New System.Drawing.Size(80, 35)
        Me.CmdClose.TabIndex = 21
        Me.CmdClose.Text = "&Close"
        Me.CmdClose.UseVisualStyleBackColor = False
        '
        'CmdCancel
        '
        Me.CmdCancel.BackColor = System.Drawing.Color.LightGray
        Me.CmdCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdCancel.Location = New System.Drawing.Point(576, 19)
        Me.CmdCancel.Name = "CmdCancel"
        Me.CmdCancel.Size = New System.Drawing.Size(80, 35)
        Me.CmdCancel.TabIndex = 20
        Me.CmdCancel.Text = "&Cancel"
        Me.CmdCancel.UseVisualStyleBackColor = False
        '
        'CmdOk
        '
        Me.CmdOk.BackColor = System.Drawing.Color.LightGray
        Me.CmdOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdOk.Location = New System.Drawing.Point(490, 19)
        Me.CmdOk.Name = "CmdOk"
        Me.CmdOk.Size = New System.Drawing.Size(80, 35)
        Me.CmdOk.TabIndex = 19
        Me.CmdOk.Text = "&Ok"
        Me.CmdOk.UseVisualStyleBackColor = False
        '
        'CmdChange
        '
        Me.CmdChange.BackColor = System.Drawing.Color.LightGray
        Me.CmdChange.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdChange.Location = New System.Drawing.Point(212, 19)
        Me.CmdChange.Name = "CmdChange"
        Me.CmdChange.Size = New System.Drawing.Size(80, 35)
        Me.CmdChange.TabIndex = 17
        Me.CmdChange.Text = "&Change"
        Me.CmdChange.UseVisualStyleBackColor = False
        '
        'CmdRepeat
        '
        Me.CmdRepeat.BackColor = System.Drawing.Color.LightGray
        Me.CmdRepeat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdRepeat.Location = New System.Drawing.Point(298, 19)
        Me.CmdRepeat.Name = "CmdRepeat"
        Me.CmdRepeat.Size = New System.Drawing.Size(80, 35)
        Me.CmdRepeat.TabIndex = 16
        Me.CmdRepeat.Text = "&Repeat"
        Me.CmdRepeat.UseVisualStyleBackColor = False
        '
        'CmdDelete
        '
        Me.CmdDelete.BackColor = System.Drawing.Color.LightGray
        Me.CmdDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdDelete.Location = New System.Drawing.Point(384, 19)
        Me.CmdDelete.Name = "CmdDelete"
        Me.CmdDelete.Size = New System.Drawing.Size(80, 35)
        Me.CmdDelete.TabIndex = 18
        Me.CmdDelete.Text = "&Delete"
        Me.CmdDelete.UseVisualStyleBackColor = False
        '
        'DataGridBudget
        '
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        Me.DataGridBudget.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridBudget.AutoGenerateColumns = False
        Me.DataGridBudget.BackgroundColor = System.Drawing.Color.White
        Me.DataGridBudget.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridBudget.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridBudget.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridBudget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridBudget.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BudgetNo, Me.BudgetType, Me.PeriodFrom, Me.CodeDataGridViewTextBoxColumn, Me.IncomeExpDataGridViewTextBoxColumn, Me.Budget1DataGridViewTextBoxColumn, Me.Budget2DataGridViewTextBoxColumn, Me.Budget3DataGridViewTextBoxColumn, Me.Budget4DataGridViewTextBoxColumn, Me.Budget5DataGridViewTextBoxColumn, Me.Budget6DataGridViewTextBoxColumn, Me.Budget7DataGridViewTextBoxColumn, Me.Budget8DataGridViewTextBoxColumn, Me.Budget9DataGridViewTextBoxColumn, Me.Budget10DataGridViewTextBoxColumn, Me.Budget11DataGridViewTextBoxColumn, Me.Budget12DataGridViewTextBoxColumn, Me.Actual1DataGridViewTextBoxColumn, Me.Actual2DataGridViewTextBoxColumn, Me.Actual3DataGridViewTextBoxColumn, Me.Actual4DataGridViewTextBoxColumn, Me.Actual5DataGridViewTextBoxColumn, Me.Actual6DataGridViewTextBoxColumn, Me.Actual7DataGridViewTextBoxColumn, Me.Actual8DataGridViewTextBoxColumn, Me.Actual9DataGridViewTextBoxColumn, Me.Actual10DataGridViewTextBoxColumn, Me.Actual11DataGridViewTextBoxColumn, Me.Actual12DataGridViewTextBoxColumn, Me.Variance1DataGridViewTextBoxColumn, Me.Variance2DataGridViewTextBoxColumn, Me.Variance3DataGridViewTextBoxColumn, Me.Variance4DataGridViewTextBoxColumn, Me.Variance5DataGridViewTextBoxColumn, Me.Variance6DataGridViewTextBoxColumn, Me.Variance7DataGridViewTextBoxColumn, Me.Variance8DataGridViewTextBoxColumn, Me.Variance9DataGridViewTextBoxColumn, Me.Variance10DataGridViewTextBoxColumn, Me.Variance11DataGridViewTextBoxColumn, Me.Variance12DataGridViewTextBoxColumn})
        Me.DataGridBudget.Cursor = System.Windows.Forms.Cursors.Default
        Me.DataGridBudget.DataSource = Me.BudgetBindingSource
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridBudget.DefaultCellStyle = DataGridViewCellStyle18
        Me.DataGridBudget.GridColor = System.Drawing.SystemColors.ControlLight
        Me.DataGridBudget.Location = New System.Drawing.Point(12, 39)
        Me.DataGridBudget.Name = "DataGridBudget"
        Me.DataGridBudget.ReadOnly = True
        Me.DataGridBudget.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridBudget.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridBudget.Size = New System.Drawing.Size(786, 243)
        Me.DataGridBudget.TabIndex = 3
        '
        'BudgetNo
        '
        Me.BudgetNo.DataPropertyName = "BudgetNo"
        Me.BudgetNo.HeaderText = "BudgetNo"
        Me.BudgetNo.Name = "BudgetNo"
        Me.BudgetNo.ReadOnly = True
        Me.BudgetNo.Visible = False
        '
        'BudgetType
        '
        Me.BudgetType.DataPropertyName = "BudgetType"
        Me.BudgetType.HeaderText = "BudgetType"
        Me.BudgetType.Name = "BudgetType"
        Me.BudgetType.ReadOnly = True
        Me.BudgetType.Visible = False
        '
        'PeriodFrom
        '
        Me.PeriodFrom.DataPropertyName = "PeriodFrom"
        Me.PeriodFrom.HeaderText = "PeriodFrom"
        Me.PeriodFrom.Name = "PeriodFrom"
        Me.PeriodFrom.ReadOnly = True
        Me.PeriodFrom.Visible = False
        '
        'CodeDataGridViewTextBoxColumn
        '
        Me.CodeDataGridViewTextBoxColumn.DataPropertyName = "Code"
        Me.CodeDataGridViewTextBoxColumn.HeaderText = "Heading"
        Me.CodeDataGridViewTextBoxColumn.Name = "CodeDataGridViewTextBoxColumn"
        Me.CodeDataGridViewTextBoxColumn.ReadOnly = True
        Me.CodeDataGridViewTextBoxColumn.Width = 118
        '
        'IncomeExpDataGridViewTextBoxColumn
        '
        Me.IncomeExpDataGridViewTextBoxColumn.DataPropertyName = "IncomeExp"
        Me.IncomeExpDataGridViewTextBoxColumn.HeaderText = "IncomeExp"
        Me.IncomeExpDataGridViewTextBoxColumn.Name = "IncomeExpDataGridViewTextBoxColumn"
        Me.IncomeExpDataGridViewTextBoxColumn.ReadOnly = True
        '
        'Budget1DataGridViewTextBoxColumn
        '
        Me.Budget1DataGridViewTextBoxColumn.DataPropertyName = "Budget1"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle6.NullValue = Nothing
        Me.Budget1DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle6
        Me.Budget1DataGridViewTextBoxColumn.HeaderText = "Budget1"
        Me.Budget1DataGridViewTextBoxColumn.Name = "Budget1DataGridViewTextBoxColumn"
        Me.Budget1DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget1DataGridViewTextBoxColumn.Width = 85
        '
        'Budget2DataGridViewTextBoxColumn
        '
        Me.Budget2DataGridViewTextBoxColumn.DataPropertyName = "Budget2"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget2DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle7
        Me.Budget2DataGridViewTextBoxColumn.HeaderText = "Budget2"
        Me.Budget2DataGridViewTextBoxColumn.Name = "Budget2DataGridViewTextBoxColumn"
        Me.Budget2DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget2DataGridViewTextBoxColumn.Width = 85
        '
        'Budget3DataGridViewTextBoxColumn
        '
        Me.Budget3DataGridViewTextBoxColumn.DataPropertyName = "Budget3"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget3DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle8
        Me.Budget3DataGridViewTextBoxColumn.HeaderText = "Budget3"
        Me.Budget3DataGridViewTextBoxColumn.Name = "Budget3DataGridViewTextBoxColumn"
        Me.Budget3DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget3DataGridViewTextBoxColumn.Width = 85
        '
        'Budget4DataGridViewTextBoxColumn
        '
        Me.Budget4DataGridViewTextBoxColumn.DataPropertyName = "Budget4"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget4DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle9
        Me.Budget4DataGridViewTextBoxColumn.HeaderText = "Budget4"
        Me.Budget4DataGridViewTextBoxColumn.Name = "Budget4DataGridViewTextBoxColumn"
        Me.Budget4DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget4DataGridViewTextBoxColumn.Width = 85
        '
        'Budget5DataGridViewTextBoxColumn
        '
        Me.Budget5DataGridViewTextBoxColumn.DataPropertyName = "Budget5"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget5DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle10
        Me.Budget5DataGridViewTextBoxColumn.HeaderText = "Budget5"
        Me.Budget5DataGridViewTextBoxColumn.Name = "Budget5DataGridViewTextBoxColumn"
        Me.Budget5DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget5DataGridViewTextBoxColumn.Width = 85
        '
        'Budget6DataGridViewTextBoxColumn
        '
        Me.Budget6DataGridViewTextBoxColumn.DataPropertyName = "Budget6"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget6DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle11
        Me.Budget6DataGridViewTextBoxColumn.HeaderText = "Budget6"
        Me.Budget6DataGridViewTextBoxColumn.Name = "Budget6DataGridViewTextBoxColumn"
        Me.Budget6DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget6DataGridViewTextBoxColumn.Width = 85
        '
        'Budget7DataGridViewTextBoxColumn
        '
        Me.Budget7DataGridViewTextBoxColumn.DataPropertyName = "Budget7"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget7DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle12
        Me.Budget7DataGridViewTextBoxColumn.HeaderText = "Budget7"
        Me.Budget7DataGridViewTextBoxColumn.Name = "Budget7DataGridViewTextBoxColumn"
        Me.Budget7DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget7DataGridViewTextBoxColumn.Width = 85
        '
        'Budget8DataGridViewTextBoxColumn
        '
        Me.Budget8DataGridViewTextBoxColumn.DataPropertyName = "Budget8"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget8DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle13
        Me.Budget8DataGridViewTextBoxColumn.HeaderText = "Budget8"
        Me.Budget8DataGridViewTextBoxColumn.Name = "Budget8DataGridViewTextBoxColumn"
        Me.Budget8DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget8DataGridViewTextBoxColumn.Width = 85
        '
        'Budget9DataGridViewTextBoxColumn
        '
        Me.Budget9DataGridViewTextBoxColumn.DataPropertyName = "Budget9"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget9DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle14
        Me.Budget9DataGridViewTextBoxColumn.HeaderText = "Budget9"
        Me.Budget9DataGridViewTextBoxColumn.Name = "Budget9DataGridViewTextBoxColumn"
        Me.Budget9DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget9DataGridViewTextBoxColumn.Width = 85
        '
        'Budget10DataGridViewTextBoxColumn
        '
        Me.Budget10DataGridViewTextBoxColumn.DataPropertyName = "Budget10"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget10DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle15
        Me.Budget10DataGridViewTextBoxColumn.HeaderText = "Budget10"
        Me.Budget10DataGridViewTextBoxColumn.Name = "Budget10DataGridViewTextBoxColumn"
        Me.Budget10DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget10DataGridViewTextBoxColumn.Width = 85
        '
        'Budget11DataGridViewTextBoxColumn
        '
        Me.Budget11DataGridViewTextBoxColumn.DataPropertyName = "Budget11"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget11DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle16
        Me.Budget11DataGridViewTextBoxColumn.HeaderText = "Budget11"
        Me.Budget11DataGridViewTextBoxColumn.Name = "Budget11DataGridViewTextBoxColumn"
        Me.Budget11DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget11DataGridViewTextBoxColumn.Width = 85
        '
        'Budget12DataGridViewTextBoxColumn
        '
        Me.Budget12DataGridViewTextBoxColumn.DataPropertyName = "Budget12"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget12DataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle17
        Me.Budget12DataGridViewTextBoxColumn.HeaderText = "Budget12"
        Me.Budget12DataGridViewTextBoxColumn.Name = "Budget12DataGridViewTextBoxColumn"
        Me.Budget12DataGridViewTextBoxColumn.ReadOnly = True
        Me.Budget12DataGridViewTextBoxColumn.Width = 85
        '
        'Actual1DataGridViewTextBoxColumn
        '
        Me.Actual1DataGridViewTextBoxColumn.DataPropertyName = "Actual1"
        Me.Actual1DataGridViewTextBoxColumn.HeaderText = "Actual1"
        Me.Actual1DataGridViewTextBoxColumn.Name = "Actual1DataGridViewTextBoxColumn"
        Me.Actual1DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual1DataGridViewTextBoxColumn.Visible = False
        '
        'Actual2DataGridViewTextBoxColumn
        '
        Me.Actual2DataGridViewTextBoxColumn.DataPropertyName = "Actual2"
        Me.Actual2DataGridViewTextBoxColumn.HeaderText = "Actual2"
        Me.Actual2DataGridViewTextBoxColumn.Name = "Actual2DataGridViewTextBoxColumn"
        Me.Actual2DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual2DataGridViewTextBoxColumn.Visible = False
        '
        'Actual3DataGridViewTextBoxColumn
        '
        Me.Actual3DataGridViewTextBoxColumn.DataPropertyName = "Actual3"
        Me.Actual3DataGridViewTextBoxColumn.HeaderText = "Actual3"
        Me.Actual3DataGridViewTextBoxColumn.Name = "Actual3DataGridViewTextBoxColumn"
        Me.Actual3DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual3DataGridViewTextBoxColumn.Visible = False
        '
        'Actual4DataGridViewTextBoxColumn
        '
        Me.Actual4DataGridViewTextBoxColumn.DataPropertyName = "Actual4"
        Me.Actual4DataGridViewTextBoxColumn.HeaderText = "Actual4"
        Me.Actual4DataGridViewTextBoxColumn.Name = "Actual4DataGridViewTextBoxColumn"
        Me.Actual4DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual4DataGridViewTextBoxColumn.Visible = False
        '
        'Actual5DataGridViewTextBoxColumn
        '
        Me.Actual5DataGridViewTextBoxColumn.DataPropertyName = "Actual5"
        Me.Actual5DataGridViewTextBoxColumn.HeaderText = "Actual5"
        Me.Actual5DataGridViewTextBoxColumn.Name = "Actual5DataGridViewTextBoxColumn"
        Me.Actual5DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual5DataGridViewTextBoxColumn.Visible = False
        '
        'Actual6DataGridViewTextBoxColumn
        '
        Me.Actual6DataGridViewTextBoxColumn.DataPropertyName = "Actual6"
        Me.Actual6DataGridViewTextBoxColumn.HeaderText = "Actual6"
        Me.Actual6DataGridViewTextBoxColumn.Name = "Actual6DataGridViewTextBoxColumn"
        Me.Actual6DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual6DataGridViewTextBoxColumn.Visible = False
        '
        'Actual7DataGridViewTextBoxColumn
        '
        Me.Actual7DataGridViewTextBoxColumn.DataPropertyName = "Actual7"
        Me.Actual7DataGridViewTextBoxColumn.HeaderText = "Actual7"
        Me.Actual7DataGridViewTextBoxColumn.Name = "Actual7DataGridViewTextBoxColumn"
        Me.Actual7DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual7DataGridViewTextBoxColumn.Visible = False
        '
        'Actual8DataGridViewTextBoxColumn
        '
        Me.Actual8DataGridViewTextBoxColumn.DataPropertyName = "Actual8"
        Me.Actual8DataGridViewTextBoxColumn.HeaderText = "Actual8"
        Me.Actual8DataGridViewTextBoxColumn.Name = "Actual8DataGridViewTextBoxColumn"
        Me.Actual8DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual8DataGridViewTextBoxColumn.Visible = False
        '
        'Actual9DataGridViewTextBoxColumn
        '
        Me.Actual9DataGridViewTextBoxColumn.DataPropertyName = "Actual9"
        Me.Actual9DataGridViewTextBoxColumn.HeaderText = "Actual9"
        Me.Actual9DataGridViewTextBoxColumn.Name = "Actual9DataGridViewTextBoxColumn"
        Me.Actual9DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual9DataGridViewTextBoxColumn.Visible = False
        '
        'Actual10DataGridViewTextBoxColumn
        '
        Me.Actual10DataGridViewTextBoxColumn.DataPropertyName = "Actual10"
        Me.Actual10DataGridViewTextBoxColumn.HeaderText = "Actual10"
        Me.Actual10DataGridViewTextBoxColumn.Name = "Actual10DataGridViewTextBoxColumn"
        Me.Actual10DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual10DataGridViewTextBoxColumn.Visible = False
        '
        'Actual11DataGridViewTextBoxColumn
        '
        Me.Actual11DataGridViewTextBoxColumn.DataPropertyName = "Actual11"
        Me.Actual11DataGridViewTextBoxColumn.HeaderText = "Actual11"
        Me.Actual11DataGridViewTextBoxColumn.Name = "Actual11DataGridViewTextBoxColumn"
        Me.Actual11DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual11DataGridViewTextBoxColumn.Visible = False
        '
        'Actual12DataGridViewTextBoxColumn
        '
        Me.Actual12DataGridViewTextBoxColumn.DataPropertyName = "Actual12"
        Me.Actual12DataGridViewTextBoxColumn.HeaderText = "Actual12"
        Me.Actual12DataGridViewTextBoxColumn.Name = "Actual12DataGridViewTextBoxColumn"
        Me.Actual12DataGridViewTextBoxColumn.ReadOnly = True
        Me.Actual12DataGridViewTextBoxColumn.Visible = False
        '
        'Variance1DataGridViewTextBoxColumn
        '
        Me.Variance1DataGridViewTextBoxColumn.DataPropertyName = "Variance1"
        Me.Variance1DataGridViewTextBoxColumn.HeaderText = "Variance1"
        Me.Variance1DataGridViewTextBoxColumn.Name = "Variance1DataGridViewTextBoxColumn"
        Me.Variance1DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance1DataGridViewTextBoxColumn.Visible = False
        '
        'Variance2DataGridViewTextBoxColumn
        '
        Me.Variance2DataGridViewTextBoxColumn.DataPropertyName = "Variance2"
        Me.Variance2DataGridViewTextBoxColumn.HeaderText = "Variance2"
        Me.Variance2DataGridViewTextBoxColumn.Name = "Variance2DataGridViewTextBoxColumn"
        Me.Variance2DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance2DataGridViewTextBoxColumn.Visible = False
        '
        'Variance3DataGridViewTextBoxColumn
        '
        Me.Variance3DataGridViewTextBoxColumn.DataPropertyName = "Variance3"
        Me.Variance3DataGridViewTextBoxColumn.HeaderText = "Variance3"
        Me.Variance3DataGridViewTextBoxColumn.Name = "Variance3DataGridViewTextBoxColumn"
        Me.Variance3DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance3DataGridViewTextBoxColumn.Visible = False
        '
        'Variance4DataGridViewTextBoxColumn
        '
        Me.Variance4DataGridViewTextBoxColumn.DataPropertyName = "Variance4"
        Me.Variance4DataGridViewTextBoxColumn.HeaderText = "Variance4"
        Me.Variance4DataGridViewTextBoxColumn.Name = "Variance4DataGridViewTextBoxColumn"
        Me.Variance4DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance4DataGridViewTextBoxColumn.Visible = False
        '
        'Variance5DataGridViewTextBoxColumn
        '
        Me.Variance5DataGridViewTextBoxColumn.DataPropertyName = "Variance5"
        Me.Variance5DataGridViewTextBoxColumn.HeaderText = "Variance5"
        Me.Variance5DataGridViewTextBoxColumn.Name = "Variance5DataGridViewTextBoxColumn"
        Me.Variance5DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance5DataGridViewTextBoxColumn.Visible = False
        '
        'Variance6DataGridViewTextBoxColumn
        '
        Me.Variance6DataGridViewTextBoxColumn.DataPropertyName = "Variance6"
        Me.Variance6DataGridViewTextBoxColumn.HeaderText = "Variance6"
        Me.Variance6DataGridViewTextBoxColumn.Name = "Variance6DataGridViewTextBoxColumn"
        Me.Variance6DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance6DataGridViewTextBoxColumn.Visible = False
        '
        'Variance7DataGridViewTextBoxColumn
        '
        Me.Variance7DataGridViewTextBoxColumn.DataPropertyName = "Variance7"
        Me.Variance7DataGridViewTextBoxColumn.HeaderText = "Variance7"
        Me.Variance7DataGridViewTextBoxColumn.Name = "Variance7DataGridViewTextBoxColumn"
        Me.Variance7DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance7DataGridViewTextBoxColumn.Visible = False
        '
        'Variance8DataGridViewTextBoxColumn
        '
        Me.Variance8DataGridViewTextBoxColumn.DataPropertyName = "Variance8"
        Me.Variance8DataGridViewTextBoxColumn.HeaderText = "Variance8"
        Me.Variance8DataGridViewTextBoxColumn.Name = "Variance8DataGridViewTextBoxColumn"
        Me.Variance8DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance8DataGridViewTextBoxColumn.Visible = False
        '
        'Variance9DataGridViewTextBoxColumn
        '
        Me.Variance9DataGridViewTextBoxColumn.DataPropertyName = "Variance9"
        Me.Variance9DataGridViewTextBoxColumn.HeaderText = "Variance9"
        Me.Variance9DataGridViewTextBoxColumn.Name = "Variance9DataGridViewTextBoxColumn"
        Me.Variance9DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance9DataGridViewTextBoxColumn.Visible = False
        '
        'Variance10DataGridViewTextBoxColumn
        '
        Me.Variance10DataGridViewTextBoxColumn.DataPropertyName = "Variance10"
        Me.Variance10DataGridViewTextBoxColumn.HeaderText = "Variance10"
        Me.Variance10DataGridViewTextBoxColumn.Name = "Variance10DataGridViewTextBoxColumn"
        Me.Variance10DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance10DataGridViewTextBoxColumn.Visible = False
        '
        'Variance11DataGridViewTextBoxColumn
        '
        Me.Variance11DataGridViewTextBoxColumn.DataPropertyName = "Variance11"
        Me.Variance11DataGridViewTextBoxColumn.HeaderText = "Variance11"
        Me.Variance11DataGridViewTextBoxColumn.Name = "Variance11DataGridViewTextBoxColumn"
        Me.Variance11DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance11DataGridViewTextBoxColumn.Visible = False
        '
        'Variance12DataGridViewTextBoxColumn
        '
        Me.Variance12DataGridViewTextBoxColumn.DataPropertyName = "Variance12"
        Me.Variance12DataGridViewTextBoxColumn.HeaderText = "Variance12"
        Me.Variance12DataGridViewTextBoxColumn.Name = "Variance12DataGridViewTextBoxColumn"
        Me.Variance12DataGridViewTextBoxColumn.ReadOnly = True
        Me.Variance12DataGridViewTextBoxColumn.Visible = False
        '
        'BudgetBindingSource
        '
        Me.BudgetBindingSource.DataMember = "Budget"
        Me.BudgetBindingSource.DataSource = Me.VPBSDataSet
        Me.BudgetBindingSource.Sort = "IncomeExp Desc, Code Asc"
        '
        'BudgetTableAdapterTest
        '
        Me.BudgetTableAdapterTest.ClearBeforeFill = True
        '
        'BudgetTableAdapterLive
        '
        Me.BudgetTableAdapterLive.ClearBeforeFill = True
        '
        'cmdScrollLft
        '
        Me.cmdScrollLft.BackColor = System.Drawing.Color.LightGray
        Me.cmdScrollLft.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdScrollLft.Location = New System.Drawing.Point(122, 313)
        Me.cmdScrollLft.Name = "cmdScrollLft"
        Me.cmdScrollLft.Size = New System.Drawing.Size(109, 27)
        Me.cmdScrollLft.TabIndex = 23
        Me.cmdScrollLft.Text = "<<- Scroll Left"
        Me.cmdScrollLft.UseVisualStyleBackColor = False
        '
        'cmdScrollRgt
        '
        Me.cmdScrollRgt.BackColor = System.Drawing.Color.LightGray
        Me.cmdScrollRgt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdScrollRgt.Location = New System.Drawing.Point(587, 313)
        Me.cmdScrollRgt.Name = "cmdScrollRgt"
        Me.cmdScrollRgt.Size = New System.Drawing.Size(109, 27)
        Me.cmdScrollRgt.TabIndex = 24
        Me.cmdScrollRgt.Text = "Scroll Right ->>"
        Me.cmdScrollRgt.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.cboIncExp)
        Me.GroupBox3.Controls.Add(Me.txtDescription)
        Me.GroupBox3.Controls.Add(Me.lblDescription)
        Me.GroupBox3.Controls.Add(Me.txtHeading)
        Me.GroupBox3.Controls.Add(Me.lblHeading)
        Me.GroupBox3.Controls.Add(Me.lblIncExp)
        Me.GroupBox3.Controls.Add(Me.lblAmt12)
        Me.GroupBox3.Controls.Add(Me.txtAmount12)
        Me.GroupBox3.Controls.Add(Me.txtAmount11)
        Me.GroupBox3.Controls.Add(Me.txtAmount10)
        Me.GroupBox3.Controls.Add(Me.lblAmt10)
        Me.GroupBox3.Controls.Add(Me.txtAmount9)
        Me.GroupBox3.Controls.Add(Me.lblAmt9)
        Me.GroupBox3.Controls.Add(Me.lblAmt11)
        Me.GroupBox3.Controls.Add(Me.txtAmount8)
        Me.GroupBox3.Controls.Add(Me.lblAmt8)
        Me.GroupBox3.Controls.Add(Me.txtAmount7)
        Me.GroupBox3.Controls.Add(Me.txtAmount6)
        Me.GroupBox3.Controls.Add(Me.lblAmt6)
        Me.GroupBox3.Controls.Add(Me.txtAmount5)
        Me.GroupBox3.Controls.Add(Me.lblAmt5)
        Me.GroupBox3.Controls.Add(Me.lblAmt7)
        Me.GroupBox3.Controls.Add(Me.txtAmount4)
        Me.GroupBox3.Controls.Add(Me.lblAmt4)
        Me.GroupBox3.Controls.Add(Me.txtAmount3)
        Me.GroupBox3.Controls.Add(Me.txtAmount2)
        Me.GroupBox3.Controls.Add(Me.lblAmt2)
        Me.GroupBox3.Controls.Add(Me.txtAmount1)
        Me.GroupBox3.Controls.Add(Me.lblAmt1)
        Me.GroupBox3.Controls.Add(Me.lblAmt3)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(13, 346)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(786, 159)
        Me.GroupBox3.TabIndex = 25
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Change"
        Me.GroupBox3.Visible = False
        '
        'cboIncExp
        '
        Me.cboIncExp.FormattingEnabled = True
        Me.cboIncExp.Location = New System.Drawing.Point(507, 19)
        Me.cboIncExp.Name = "cboIncExp"
        Me.cboIncExp.Size = New System.Drawing.Size(86, 24)
        Me.cboIncExp.TabIndex = 57
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(319, 20)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(100, 24)
        Me.txtDescription.TabIndex = 52
        '
        'lblDescription
        '
        Me.lblDescription.BackColor = System.Drawing.Color.Silver
        Me.lblDescription.Location = New System.Drawing.Point(234, 20)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(79, 24)
        Me.lblDescription.TabIndex = 55
        Me.lblDescription.Text = "Description"
        Me.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtHeading
        '
        Me.txtHeading.Location = New System.Drawing.Point(111, 21)
        Me.txtHeading.Multiline = True
        Me.txtHeading.Name = "txtHeading"
        Me.txtHeading.Size = New System.Drawing.Size(100, 24)
        Me.txtHeading.TabIndex = 51
        '
        'lblHeading
        '
        Me.lblHeading.BackColor = System.Drawing.Color.Silver
        Me.lblHeading.Location = New System.Drawing.Point(27, 20)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(78, 24)
        Me.lblHeading.TabIndex = 54
        Me.lblHeading.Text = "Heading"
        Me.lblHeading.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblIncExp
        '
        Me.lblIncExp.BackColor = System.Drawing.Color.Silver
        Me.lblIncExp.Location = New System.Drawing.Point(441, 19)
        Me.lblIncExp.Name = "lblIncExp"
        Me.lblIncExp.Size = New System.Drawing.Size(60, 25)
        Me.lblIncExp.TabIndex = 56
        Me.lblIncExp.Text = "Inc/Exp"
        Me.lblIncExp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAmt12
        '
        Me.lblAmt12.BackColor = System.Drawing.Color.Silver
        Me.lblAmt12.Location = New System.Drawing.Point(625, 119)
        Me.lblAmt12.Name = "lblAmt12"
        Me.lblAmt12.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt12.TabIndex = 50
        Me.lblAmt12.Text = "lblAmt12"
        Me.lblAmt12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAmount12
        '
        Me.txtAmount12.Location = New System.Drawing.Point(693, 120)
        Me.txtAmount12.Multiline = True
        Me.txtAmount12.Name = "txtAmount12"
        Me.txtAmount12.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount12.TabIndex = 46
        '
        'txtAmount11
        '
        Me.txtAmount11.Location = New System.Drawing.Point(507, 122)
        Me.txtAmount11.Multiline = True
        Me.txtAmount11.Name = "txtAmount11"
        Me.txtAmount11.Size = New System.Drawing.Size(70, 25)
        Me.txtAmount11.TabIndex = 45
        '
        'txtAmount10
        '
        Me.txtAmount10.Location = New System.Drawing.Point(319, 122)
        Me.txtAmount10.Multiline = True
        Me.txtAmount10.Name = "txtAmount10"
        Me.txtAmount10.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount10.TabIndex = 44
        '
        'lblAmt10
        '
        Me.lblAmt10.BackColor = System.Drawing.Color.Silver
        Me.lblAmt10.Location = New System.Drawing.Point(253, 122)
        Me.lblAmt10.Name = "lblAmt10"
        Me.lblAmt10.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt10.TabIndex = 48
        Me.lblAmt10.Text = "lblAmt10"
        Me.lblAmt10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAmount9
        '
        Me.txtAmount9.Location = New System.Drawing.Point(111, 123)
        Me.txtAmount9.Multiline = True
        Me.txtAmount9.Name = "txtAmount9"
        Me.txtAmount9.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount9.TabIndex = 43
        '
        'lblAmt9
        '
        Me.lblAmt9.BackColor = System.Drawing.Color.Silver
        Me.lblAmt9.Location = New System.Drawing.Point(45, 122)
        Me.lblAmt9.Name = "lblAmt9"
        Me.lblAmt9.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt9.TabIndex = 47
        Me.lblAmt9.Text = "lblAmt9"
        Me.lblAmt9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAmt11
        '
        Me.lblAmt11.BackColor = System.Drawing.Color.Silver
        Me.lblAmt11.Location = New System.Drawing.Point(441, 121)
        Me.lblAmt11.Name = "lblAmt11"
        Me.lblAmt11.Size = New System.Drawing.Size(60, 25)
        Me.lblAmt11.TabIndex = 49
        Me.lblAmt11.Text = "lblAmt11"
        Me.lblAmt11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAmount8
        '
        Me.txtAmount8.Location = New System.Drawing.Point(693, 85)
        Me.txtAmount8.Multiline = True
        Me.txtAmount8.Name = "txtAmount8"
        Me.txtAmount8.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount8.TabIndex = 38
        '
        'lblAmt8
        '
        Me.lblAmt8.BackColor = System.Drawing.Color.Silver
        Me.lblAmt8.Location = New System.Drawing.Point(625, 84)
        Me.lblAmt8.Name = "lblAmt8"
        Me.lblAmt8.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt8.TabIndex = 42
        Me.lblAmt8.Text = "lblAmt8"
        Me.lblAmt8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAmount7
        '
        Me.txtAmount7.Location = New System.Drawing.Point(507, 86)
        Me.txtAmount7.Multiline = True
        Me.txtAmount7.Name = "txtAmount7"
        Me.txtAmount7.Size = New System.Drawing.Size(70, 25)
        Me.txtAmount7.TabIndex = 37
        '
        'txtAmount6
        '
        Me.txtAmount6.Location = New System.Drawing.Point(319, 87)
        Me.txtAmount6.Multiline = True
        Me.txtAmount6.Name = "txtAmount6"
        Me.txtAmount6.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount6.TabIndex = 36
        '
        'lblAmt6
        '
        Me.lblAmt6.BackColor = System.Drawing.Color.Silver
        Me.lblAmt6.Location = New System.Drawing.Point(253, 87)
        Me.lblAmt6.Name = "lblAmt6"
        Me.lblAmt6.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt6.TabIndex = 40
        Me.lblAmt6.Text = "lblAmt6"
        Me.lblAmt6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAmount5
        '
        Me.txtAmount5.Location = New System.Drawing.Point(111, 88)
        Me.txtAmount5.Multiline = True
        Me.txtAmount5.Name = "txtAmount5"
        Me.txtAmount5.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount5.TabIndex = 35
        '
        'lblAmt5
        '
        Me.lblAmt5.BackColor = System.Drawing.Color.Silver
        Me.lblAmt5.Location = New System.Drawing.Point(45, 87)
        Me.lblAmt5.Name = "lblAmt5"
        Me.lblAmt5.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt5.TabIndex = 39
        Me.lblAmt5.Text = "lblAmt5"
        Me.lblAmt5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAmt7
        '
        Me.lblAmt7.BackColor = System.Drawing.Color.Silver
        Me.lblAmt7.Location = New System.Drawing.Point(441, 86)
        Me.lblAmt7.Name = "lblAmt7"
        Me.lblAmt7.Size = New System.Drawing.Size(60, 25)
        Me.lblAmt7.TabIndex = 41
        Me.lblAmt7.Text = "lblAmt7"
        Me.lblAmt7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAmount4
        '
        Me.txtAmount4.Location = New System.Drawing.Point(693, 51)
        Me.txtAmount4.Multiline = True
        Me.txtAmount4.Name = "txtAmount4"
        Me.txtAmount4.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount4.TabIndex = 15
        '
        'lblAmt4
        '
        Me.lblAmt4.BackColor = System.Drawing.Color.Silver
        Me.lblAmt4.Location = New System.Drawing.Point(625, 50)
        Me.lblAmt4.Name = "lblAmt4"
        Me.lblAmt4.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt4.TabIndex = 34
        Me.lblAmt4.Text = "lblAmt4"
        Me.lblAmt4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAmount3
        '
        Me.txtAmount3.Location = New System.Drawing.Point(507, 53)
        Me.txtAmount3.Multiline = True
        Me.txtAmount3.Name = "txtAmount3"
        Me.txtAmount3.Size = New System.Drawing.Size(70, 25)
        Me.txtAmount3.TabIndex = 14
        '
        'txtAmount2
        '
        Me.txtAmount2.Location = New System.Drawing.Point(319, 53)
        Me.txtAmount2.Multiline = True
        Me.txtAmount2.Name = "txtAmount2"
        Me.txtAmount2.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount2.TabIndex = 13
        '
        'lblAmt2
        '
        Me.lblAmt2.BackColor = System.Drawing.Color.Silver
        Me.lblAmt2.Location = New System.Drawing.Point(253, 53)
        Me.lblAmt2.Name = "lblAmt2"
        Me.lblAmt2.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt2.TabIndex = 30
        Me.lblAmt2.Text = "lblAmt2"
        Me.lblAmt2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAmount1
        '
        Me.txtAmount1.Location = New System.Drawing.Point(111, 54)
        Me.txtAmount1.Multiline = True
        Me.txtAmount1.Name = "txtAmount1"
        Me.txtAmount1.Size = New System.Drawing.Size(70, 24)
        Me.txtAmount1.TabIndex = 12
        '
        'lblAmt1
        '
        Me.lblAmt1.BackColor = System.Drawing.Color.Silver
        Me.lblAmt1.Location = New System.Drawing.Point(45, 53)
        Me.lblAmt1.Name = "lblAmt1"
        Me.lblAmt1.Size = New System.Drawing.Size(60, 24)
        Me.lblAmt1.TabIndex = 28
        Me.lblAmt1.Text = "lblAmt1"
        Me.lblAmt1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAmt3
        '
        Me.lblAmt3.BackColor = System.Drawing.Color.Silver
        Me.lblAmt3.Location = New System.Drawing.Point(441, 52)
        Me.lblAmt3.Name = "lblAmt3"
        Me.lblAmt3.Size = New System.Drawing.Size(60, 25)
        Me.lblAmt3.TabIndex = 31
        Me.lblAmt3.Text = "lblAmt3"
        Me.lblAmt3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.GroupBox6)
        Me.GroupBox2.Controls.Add(Me.GroupBox5)
        Me.GroupBox2.Location = New System.Drawing.Point(11, 346)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(786, 157)
        Me.GroupBox2.TabIndex = 35
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Visible = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.rdo3Option2)
        Me.GroupBox6.Controls.Add(Me.rdo3Option1)
        Me.GroupBox6.Controls.Add(Me.rdo3Option0)
        Me.GroupBox6.Location = New System.Drawing.Point(507, 34)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(180, 90)
        Me.GroupBox6.TabIndex = 2
        Me.GroupBox6.TabStop = False
        '
        'rdo3Option2
        '
        Me.rdo3Option2.AutoSize = True
        Me.rdo3Option2.Location = New System.Drawing.Point(17, 65)
        Me.rdo3Option2.Name = "rdo3Option2"
        Me.rdo3Option2.Size = New System.Drawing.Size(116, 17)
        Me.rdo3Option2.TabIndex = 8
        Me.rdo3Option2.Text = "Pint months 7 to 12"
        Me.rdo3Option2.UseVisualStyleBackColor = True
        '
        'rdo3Option1
        '
        Me.rdo3Option1.AutoSize = True
        Me.rdo3Option1.Location = New System.Drawing.Point(17, 39)
        Me.rdo3Option1.Name = "rdo3Option1"
        Me.rdo3Option1.Size = New System.Drawing.Size(110, 17)
        Me.rdo3Option1.TabIndex = 7
        Me.rdo3Option1.Text = "Pint months 1 to 6"
        Me.rdo3Option1.UseVisualStyleBackColor = True
        '
        'rdo3Option0
        '
        Me.rdo3Option0.AutoSize = True
        Me.rdo3Option0.Checked = True
        Me.rdo3Option0.Location = New System.Drawing.Point(17, 13)
        Me.rdo3Option0.Name = "rdo3Option0"
        Me.rdo3Option0.Size = New System.Drawing.Size(125, 17)
        Me.rdo3Option0.TabIndex = 6
        Me.rdo3Option0.TabStop = True
        Me.rdo3Option0.Text = "Show months 1 to 12"
        Me.rdo3Option0.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.rdo2Option2)
        Me.GroupBox5.Controls.Add(Me.rdo2Option1)
        Me.GroupBox5.Controls.Add(Me.rdo2Option0)
        Me.GroupBox5.Location = New System.Drawing.Point(110, 34)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(176, 90)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        '
        'rdo2Option2
        '
        Me.rdo2Option2.AutoSize = True
        Me.rdo2Option2.Location = New System.Drawing.Point(15, 65)
        Me.rdo2Option2.Name = "rdo2Option2"
        Me.rdo2Option2.Size = New System.Drawing.Size(94, 17)
        Me.rdo2Option2.TabIndex = 6
        Me.rdo2Option2.Text = "Accumulate all"
        Me.rdo2Option2.UseVisualStyleBackColor = True
        '
        'rdo2Option1
        '
        Me.rdo2Option1.AutoSize = True
        Me.rdo2Option1.Location = New System.Drawing.Point(15, 39)
        Me.rdo2Option1.Name = "rdo2Option1"
        Me.rdo2Option1.Size = New System.Drawing.Size(125, 17)
        Me.rdo2Option1.TabIndex = 5
        Me.rdo2Option1.Text = "Accumulate variance"
        Me.rdo2Option1.UseVisualStyleBackColor = True
        '
        'rdo2Option0
        '
        Me.rdo2Option0.AutoSize = True
        Me.rdo2Option0.Location = New System.Drawing.Point(15, 13)
        Me.rdo2Option0.Name = "rdo2Option0"
        Me.rdo2Option0.Size = New System.Drawing.Size(104, 17)
        Me.rdo2Option0.TabIndex = 4
        Me.rdo2Option0.Text = "Totals per month"
        Me.rdo2Option0.UseVisualStyleBackColor = True
        '
        'lblBudgetHeader
        '
        Me.lblBudgetHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblBudgetHeader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBudgetHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBudgetHeader.Location = New System.Drawing.Point(12, 9)
        Me.lblBudgetHeader.Name = "lblBudgetHeader"
        Me.lblBudgetHeader.Size = New System.Drawing.Size(786, 27)
        Me.lblBudgetHeader.TabIndex = 26
        Me.lblBudgetHeader.Text = "Select a Budget Number to start..."
        Me.lblBudgetHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblBudgetHeader.UseMnemonic = False
        '
        'DataGridActuals
        '
        Me.DataGridActuals.AllowUserToAddRows = False
        Me.DataGridActuals.AllowUserToDeleteRows = False
        Me.DataGridActuals.AllowUserToResizeColumns = False
        Me.DataGridActuals.AllowUserToResizeRows = False
        Me.DataGridActuals.AutoGenerateColumns = False
        Me.DataGridActuals.BackgroundColor = System.Drawing.Color.White
        Me.DataGridActuals.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridActuals.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridActuals.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle19
        Me.DataGridActuals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridActuals.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BudgetNoDataGridViewTextBoxColumn1, Me.BudgetTypeDataGridViewTextBoxColumn1, Me.PeriodFromDataGridViewTextBoxColumn1, Me.CodeDataGridViewTextBoxColumn1, Me.IncomeExpDataGridViewTextBoxColumn1, Me.Actual1DataGridViewTextBoxColumn1, Me.Budget1DataGridViewTextBoxColumn1, Me.Variance1DataGridViewTextBoxColumn1, Me.Actual2DataGridViewTextBoxColumn1, Me.Budget2DataGridViewTextBoxColumn1, Me.Variance2DataGridViewTextBoxColumn1, Me.Actual3DataGridViewTextBoxColumn1, Me.Budget3DataGridViewTextBoxColumn1, Me.Variance3DataGridViewTextBoxColumn1, Me.Actual4DataGridViewTextBoxColumn1, Me.Budget4DataGridViewTextBoxColumn1, Me.Variance4DataGridViewTextBoxColumn1, Me.Actual5DataGridViewTextBoxColumn1, Me.Budget5DataGridViewTextBoxColumn1, Me.Variance5DataGridViewTextBoxColumn1, Me.Actual6DataGridViewTextBoxColumn1, Me.Budget6DataGridViewTextBoxColumn1, Me.Variance6DataGridViewTextBoxColumn1, Me.Actual7DataGridViewTextBoxColumn1, Me.Budget7DataGridViewTextBoxColumn1, Me.Variance7DataGridViewTextBoxColumn1, Me.Actual8DataGridViewTextBoxColumn1, Me.Budget8DataGridViewTextBoxColumn1, Me.Variance8DataGridViewTextBoxColumn1, Me.Actual9DataGridViewTextBoxColumn1, Me.Budget9DataGridViewTextBoxColumn1, Me.Variance9DataGridViewTextBoxColumn1, Me.Actual10DataGridViewTextBoxColumn1, Me.Budget10DataGridViewTextBoxColumn1, Me.Variance10DataGridViewTextBoxColumn1, Me.Actual11DataGridViewTextBoxColumn1, Me.Budget11DataGridViewTextBoxColumn1, Me.Variance11DataGridViewTextBoxColumn1, Me.Actual12DataGridViewTextBoxColumn1, Me.Budget12DataGridViewTextBoxColumn1, Me.Variance12DataGridViewTextBoxColumn1})
        Me.DataGridActuals.DataSource = Me.BudgetBindingSource
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridActuals.DefaultCellStyle = DataGridViewCellStyle28
        Me.DataGridActuals.Location = New System.Drawing.Point(12, 63)
        Me.DataGridActuals.MultiSelect = False
        Me.DataGridActuals.Name = "DataGridActuals"
        Me.DataGridActuals.ReadOnly = True
        Me.DataGridActuals.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridActuals.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridActuals.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridActuals.Size = New System.Drawing.Size(786, 181)
        Me.DataGridActuals.TabIndex = 27
        '
        'BudgetNoDataGridViewTextBoxColumn1
        '
        Me.BudgetNoDataGridViewTextBoxColumn1.DataPropertyName = "BudgetNo"
        DataGridViewCellStyle20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BudgetNoDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle20
        Me.BudgetNoDataGridViewTextBoxColumn1.HeaderText = "BudgetNo"
        Me.BudgetNoDataGridViewTextBoxColumn1.Name = "BudgetNoDataGridViewTextBoxColumn1"
        Me.BudgetNoDataGridViewTextBoxColumn1.ReadOnly = True
        Me.BudgetNoDataGridViewTextBoxColumn1.Visible = False
        '
        'BudgetTypeDataGridViewTextBoxColumn1
        '
        Me.BudgetTypeDataGridViewTextBoxColumn1.DataPropertyName = "BudgetType"
        Me.BudgetTypeDataGridViewTextBoxColumn1.HeaderText = "BudgetType"
        Me.BudgetTypeDataGridViewTextBoxColumn1.Name = "BudgetTypeDataGridViewTextBoxColumn1"
        Me.BudgetTypeDataGridViewTextBoxColumn1.ReadOnly = True
        Me.BudgetTypeDataGridViewTextBoxColumn1.Visible = False
        '
        'PeriodFromDataGridViewTextBoxColumn1
        '
        Me.PeriodFromDataGridViewTextBoxColumn1.DataPropertyName = "PeriodFrom"
        Me.PeriodFromDataGridViewTextBoxColumn1.HeaderText = "PeriodFrom"
        Me.PeriodFromDataGridViewTextBoxColumn1.Name = "PeriodFromDataGridViewTextBoxColumn1"
        Me.PeriodFromDataGridViewTextBoxColumn1.ReadOnly = True
        Me.PeriodFromDataGridViewTextBoxColumn1.Visible = False
        '
        'CodeDataGridViewTextBoxColumn1
        '
        Me.CodeDataGridViewTextBoxColumn1.DataPropertyName = "Code"
        DataGridViewCellStyle21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CodeDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle21
        Me.CodeDataGridViewTextBoxColumn1.HeaderText = "Heading"
        Me.CodeDataGridViewTextBoxColumn1.Name = "CodeDataGridViewTextBoxColumn1"
        Me.CodeDataGridViewTextBoxColumn1.ReadOnly = True
        Me.CodeDataGridViewTextBoxColumn1.Width = 118
        '
        'IncomeExpDataGridViewTextBoxColumn1
        '
        Me.IncomeExpDataGridViewTextBoxColumn1.DataPropertyName = "IncomeExp"
        Me.IncomeExpDataGridViewTextBoxColumn1.HeaderText = "IncomeExp"
        Me.IncomeExpDataGridViewTextBoxColumn1.Name = "IncomeExpDataGridViewTextBoxColumn1"
        Me.IncomeExpDataGridViewTextBoxColumn1.ReadOnly = True
        '
        'Actual1DataGridViewTextBoxColumn1
        '
        Me.Actual1DataGridViewTextBoxColumn1.DataPropertyName = "Actual1"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Actual1DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle22
        Me.Actual1DataGridViewTextBoxColumn1.HeaderText = "Actual1"
        Me.Actual1DataGridViewTextBoxColumn1.Name = "Actual1DataGridViewTextBoxColumn1"
        Me.Actual1DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual1DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget1DataGridViewTextBoxColumn1
        '
        Me.Budget1DataGridViewTextBoxColumn1.DataPropertyName = "Budget1"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget1DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle23
        Me.Budget1DataGridViewTextBoxColumn1.HeaderText = "Budget1"
        Me.Budget1DataGridViewTextBoxColumn1.Name = "Budget1DataGridViewTextBoxColumn1"
        Me.Budget1DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget1DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance1DataGridViewTextBoxColumn1
        '
        Me.Variance1DataGridViewTextBoxColumn1.DataPropertyName = "Variance1"
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Variance1DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle24
        Me.Variance1DataGridViewTextBoxColumn1.HeaderText = "Variance1"
        Me.Variance1DataGridViewTextBoxColumn1.Name = "Variance1DataGridViewTextBoxColumn1"
        Me.Variance1DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance1DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual2DataGridViewTextBoxColumn1
        '
        Me.Actual2DataGridViewTextBoxColumn1.DataPropertyName = "Actual2"
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Actual2DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle25
        Me.Actual2DataGridViewTextBoxColumn1.HeaderText = "Actual2"
        Me.Actual2DataGridViewTextBoxColumn1.Name = "Actual2DataGridViewTextBoxColumn1"
        Me.Actual2DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual2DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget2DataGridViewTextBoxColumn1
        '
        Me.Budget2DataGridViewTextBoxColumn1.DataPropertyName = "Budget2"
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Budget2DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle26
        Me.Budget2DataGridViewTextBoxColumn1.HeaderText = "Budget2"
        Me.Budget2DataGridViewTextBoxColumn1.Name = "Budget2DataGridViewTextBoxColumn1"
        Me.Budget2DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget2DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance2DataGridViewTextBoxColumn1
        '
        Me.Variance2DataGridViewTextBoxColumn1.DataPropertyName = "Variance2"
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Variance2DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle27
        Me.Variance2DataGridViewTextBoxColumn1.HeaderText = "Variance2"
        Me.Variance2DataGridViewTextBoxColumn1.Name = "Variance2DataGridViewTextBoxColumn1"
        Me.Variance2DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance2DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual3DataGridViewTextBoxColumn1
        '
        Me.Actual3DataGridViewTextBoxColumn1.DataPropertyName = "Actual3"
        Me.Actual3DataGridViewTextBoxColumn1.HeaderText = "Actual3"
        Me.Actual3DataGridViewTextBoxColumn1.Name = "Actual3DataGridViewTextBoxColumn1"
        Me.Actual3DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual3DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget3DataGridViewTextBoxColumn1
        '
        Me.Budget3DataGridViewTextBoxColumn1.DataPropertyName = "Budget3"
        Me.Budget3DataGridViewTextBoxColumn1.HeaderText = "Budget3"
        Me.Budget3DataGridViewTextBoxColumn1.Name = "Budget3DataGridViewTextBoxColumn1"
        Me.Budget3DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget3DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance3DataGridViewTextBoxColumn1
        '
        Me.Variance3DataGridViewTextBoxColumn1.DataPropertyName = "Variance3"
        Me.Variance3DataGridViewTextBoxColumn1.HeaderText = "Variance3"
        Me.Variance3DataGridViewTextBoxColumn1.Name = "Variance3DataGridViewTextBoxColumn1"
        Me.Variance3DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance3DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual4DataGridViewTextBoxColumn1
        '
        Me.Actual4DataGridViewTextBoxColumn1.DataPropertyName = "Actual4"
        Me.Actual4DataGridViewTextBoxColumn1.HeaderText = "Actual4"
        Me.Actual4DataGridViewTextBoxColumn1.Name = "Actual4DataGridViewTextBoxColumn1"
        Me.Actual4DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual4DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget4DataGridViewTextBoxColumn1
        '
        Me.Budget4DataGridViewTextBoxColumn1.DataPropertyName = "Budget4"
        Me.Budget4DataGridViewTextBoxColumn1.HeaderText = "Budget4"
        Me.Budget4DataGridViewTextBoxColumn1.Name = "Budget4DataGridViewTextBoxColumn1"
        Me.Budget4DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget4DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance4DataGridViewTextBoxColumn1
        '
        Me.Variance4DataGridViewTextBoxColumn1.DataPropertyName = "Variance4"
        Me.Variance4DataGridViewTextBoxColumn1.HeaderText = "Variance4"
        Me.Variance4DataGridViewTextBoxColumn1.Name = "Variance4DataGridViewTextBoxColumn1"
        Me.Variance4DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance4DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual5DataGridViewTextBoxColumn1
        '
        Me.Actual5DataGridViewTextBoxColumn1.DataPropertyName = "Actual5"
        Me.Actual5DataGridViewTextBoxColumn1.HeaderText = "Actual5"
        Me.Actual5DataGridViewTextBoxColumn1.Name = "Actual5DataGridViewTextBoxColumn1"
        Me.Actual5DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual5DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget5DataGridViewTextBoxColumn1
        '
        Me.Budget5DataGridViewTextBoxColumn1.DataPropertyName = "Budget5"
        Me.Budget5DataGridViewTextBoxColumn1.HeaderText = "Budget5"
        Me.Budget5DataGridViewTextBoxColumn1.Name = "Budget5DataGridViewTextBoxColumn1"
        Me.Budget5DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget5DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance5DataGridViewTextBoxColumn1
        '
        Me.Variance5DataGridViewTextBoxColumn1.DataPropertyName = "Variance5"
        Me.Variance5DataGridViewTextBoxColumn1.HeaderText = "Variance5"
        Me.Variance5DataGridViewTextBoxColumn1.Name = "Variance5DataGridViewTextBoxColumn1"
        Me.Variance5DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance5DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual6DataGridViewTextBoxColumn1
        '
        Me.Actual6DataGridViewTextBoxColumn1.DataPropertyName = "Actual6"
        Me.Actual6DataGridViewTextBoxColumn1.HeaderText = "Actual6"
        Me.Actual6DataGridViewTextBoxColumn1.Name = "Actual6DataGridViewTextBoxColumn1"
        Me.Actual6DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual6DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget6DataGridViewTextBoxColumn1
        '
        Me.Budget6DataGridViewTextBoxColumn1.DataPropertyName = "Budget6"
        Me.Budget6DataGridViewTextBoxColumn1.HeaderText = "Budget6"
        Me.Budget6DataGridViewTextBoxColumn1.Name = "Budget6DataGridViewTextBoxColumn1"
        Me.Budget6DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget6DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance6DataGridViewTextBoxColumn1
        '
        Me.Variance6DataGridViewTextBoxColumn1.DataPropertyName = "Variance6"
        Me.Variance6DataGridViewTextBoxColumn1.HeaderText = "Variance6"
        Me.Variance6DataGridViewTextBoxColumn1.Name = "Variance6DataGridViewTextBoxColumn1"
        Me.Variance6DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance6DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual7DataGridViewTextBoxColumn1
        '
        Me.Actual7DataGridViewTextBoxColumn1.DataPropertyName = "Actual7"
        Me.Actual7DataGridViewTextBoxColumn1.HeaderText = "Actual7"
        Me.Actual7DataGridViewTextBoxColumn1.Name = "Actual7DataGridViewTextBoxColumn1"
        Me.Actual7DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual7DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget7DataGridViewTextBoxColumn1
        '
        Me.Budget7DataGridViewTextBoxColumn1.DataPropertyName = "Budget7"
        Me.Budget7DataGridViewTextBoxColumn1.HeaderText = "Budget7"
        Me.Budget7DataGridViewTextBoxColumn1.Name = "Budget7DataGridViewTextBoxColumn1"
        Me.Budget7DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget7DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance7DataGridViewTextBoxColumn1
        '
        Me.Variance7DataGridViewTextBoxColumn1.DataPropertyName = "Variance7"
        Me.Variance7DataGridViewTextBoxColumn1.HeaderText = "Variance7"
        Me.Variance7DataGridViewTextBoxColumn1.Name = "Variance7DataGridViewTextBoxColumn1"
        Me.Variance7DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance7DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual8DataGridViewTextBoxColumn1
        '
        Me.Actual8DataGridViewTextBoxColumn1.DataPropertyName = "Actual8"
        Me.Actual8DataGridViewTextBoxColumn1.HeaderText = "Actual8"
        Me.Actual8DataGridViewTextBoxColumn1.Name = "Actual8DataGridViewTextBoxColumn1"
        Me.Actual8DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual8DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget8DataGridViewTextBoxColumn1
        '
        Me.Budget8DataGridViewTextBoxColumn1.DataPropertyName = "Budget8"
        Me.Budget8DataGridViewTextBoxColumn1.HeaderText = "Budget8"
        Me.Budget8DataGridViewTextBoxColumn1.Name = "Budget8DataGridViewTextBoxColumn1"
        Me.Budget8DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget8DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance8DataGridViewTextBoxColumn1
        '
        Me.Variance8DataGridViewTextBoxColumn1.DataPropertyName = "Variance8"
        Me.Variance8DataGridViewTextBoxColumn1.HeaderText = "Variance8"
        Me.Variance8DataGridViewTextBoxColumn1.Name = "Variance8DataGridViewTextBoxColumn1"
        Me.Variance8DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance8DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual9DataGridViewTextBoxColumn1
        '
        Me.Actual9DataGridViewTextBoxColumn1.DataPropertyName = "Actual9"
        Me.Actual9DataGridViewTextBoxColumn1.HeaderText = "Actual9"
        Me.Actual9DataGridViewTextBoxColumn1.Name = "Actual9DataGridViewTextBoxColumn1"
        Me.Actual9DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual9DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget9DataGridViewTextBoxColumn1
        '
        Me.Budget9DataGridViewTextBoxColumn1.DataPropertyName = "Budget9"
        Me.Budget9DataGridViewTextBoxColumn1.HeaderText = "Budget9"
        Me.Budget9DataGridViewTextBoxColumn1.Name = "Budget9DataGridViewTextBoxColumn1"
        Me.Budget9DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget9DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance9DataGridViewTextBoxColumn1
        '
        Me.Variance9DataGridViewTextBoxColumn1.DataPropertyName = "Variance9"
        Me.Variance9DataGridViewTextBoxColumn1.HeaderText = "Variance9"
        Me.Variance9DataGridViewTextBoxColumn1.Name = "Variance9DataGridViewTextBoxColumn1"
        Me.Variance9DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance9DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual10DataGridViewTextBoxColumn1
        '
        Me.Actual10DataGridViewTextBoxColumn1.DataPropertyName = "Actual10"
        Me.Actual10DataGridViewTextBoxColumn1.HeaderText = "Actual10"
        Me.Actual10DataGridViewTextBoxColumn1.Name = "Actual10DataGridViewTextBoxColumn1"
        Me.Actual10DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual10DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget10DataGridViewTextBoxColumn1
        '
        Me.Budget10DataGridViewTextBoxColumn1.DataPropertyName = "Budget10"
        Me.Budget10DataGridViewTextBoxColumn1.HeaderText = "Budget10"
        Me.Budget10DataGridViewTextBoxColumn1.Name = "Budget10DataGridViewTextBoxColumn1"
        Me.Budget10DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget10DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance10DataGridViewTextBoxColumn1
        '
        Me.Variance10DataGridViewTextBoxColumn1.DataPropertyName = "Variance10"
        Me.Variance10DataGridViewTextBoxColumn1.HeaderText = "Variance10"
        Me.Variance10DataGridViewTextBoxColumn1.Name = "Variance10DataGridViewTextBoxColumn1"
        Me.Variance10DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance10DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual11DataGridViewTextBoxColumn1
        '
        Me.Actual11DataGridViewTextBoxColumn1.DataPropertyName = "Actual11"
        Me.Actual11DataGridViewTextBoxColumn1.HeaderText = "Actual11"
        Me.Actual11DataGridViewTextBoxColumn1.Name = "Actual11DataGridViewTextBoxColumn1"
        Me.Actual11DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual11DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget11DataGridViewTextBoxColumn1
        '
        Me.Budget11DataGridViewTextBoxColumn1.DataPropertyName = "Budget11"
        Me.Budget11DataGridViewTextBoxColumn1.HeaderText = "Budget11"
        Me.Budget11DataGridViewTextBoxColumn1.Name = "Budget11DataGridViewTextBoxColumn1"
        Me.Budget11DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget11DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance11DataGridViewTextBoxColumn1
        '
        Me.Variance11DataGridViewTextBoxColumn1.DataPropertyName = "Variance11"
        Me.Variance11DataGridViewTextBoxColumn1.HeaderText = "Variance11"
        Me.Variance11DataGridViewTextBoxColumn1.Name = "Variance11DataGridViewTextBoxColumn1"
        Me.Variance11DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance11DataGridViewTextBoxColumn1.Width = 85
        '
        'Actual12DataGridViewTextBoxColumn1
        '
        Me.Actual12DataGridViewTextBoxColumn1.DataPropertyName = "Actual12"
        Me.Actual12DataGridViewTextBoxColumn1.HeaderText = "Actual12"
        Me.Actual12DataGridViewTextBoxColumn1.Name = "Actual12DataGridViewTextBoxColumn1"
        Me.Actual12DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Actual12DataGridViewTextBoxColumn1.Width = 85
        '
        'Budget12DataGridViewTextBoxColumn1
        '
        Me.Budget12DataGridViewTextBoxColumn1.DataPropertyName = "Budget12"
        Me.Budget12DataGridViewTextBoxColumn1.HeaderText = "Budget12"
        Me.Budget12DataGridViewTextBoxColumn1.Name = "Budget12DataGridViewTextBoxColumn1"
        Me.Budget12DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Budget12DataGridViewTextBoxColumn1.Width = 85
        '
        'Variance12DataGridViewTextBoxColumn1
        '
        Me.Variance12DataGridViewTextBoxColumn1.DataPropertyName = "Variance12"
        Me.Variance12DataGridViewTextBoxColumn1.HeaderText = "Variance12"
        Me.Variance12DataGridViewTextBoxColumn1.Name = "Variance12DataGridViewTextBoxColumn1"
        Me.Variance12DataGridViewTextBoxColumn1.ReadOnly = True
        Me.Variance12DataGridViewTextBoxColumn1.Width = 85
        '
        'lblHeader2
        '
        Me.lblHeader2.BackColor = System.Drawing.SystemColors.Control
        Me.lblHeader2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader2.Location = New System.Drawing.Point(273, 39)
        Me.lblHeader2.Name = "lblHeader2"
        Me.lblHeader2.Size = New System.Drawing.Size(253, 24)
        Me.lblHeader2.TabIndex = 28
        Me.lblHeader2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblHeader2.Visible = False
        '
        'lblHeader3
        '
        Me.lblHeader3.BackColor = System.Drawing.SystemColors.Control
        Me.lblHeader3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader3.Location = New System.Drawing.Point(526, 39)
        Me.lblHeader3.Name = "lblHeader3"
        Me.lblHeader3.Size = New System.Drawing.Size(252, 24)
        Me.lblHeader3.TabIndex = 29
        Me.lblHeader3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblHeader3.Visible = False
        '
        'lblHeader1
        '
        Me.lblHeader1.BackColor = System.Drawing.SystemColors.Control
        Me.lblHeader1.Location = New System.Drawing.Point(13, 39)
        Me.lblHeader1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHeader1.Name = "lblHeader1"
        Me.lblHeader1.Size = New System.Drawing.Size(258, 24)
        Me.lblHeader1.TabIndex = 30
        Me.lblHeader1.Visible = False
        '
        'TotalsBindingSource
        '
        Me.TotalsBindingSource.DataMember = "Budget"
        Me.TotalsBindingSource.DataSource = Me.VPBSDataSet
        Me.TotalsBindingSource.Filter = "BudgetNo = '99999999'"
        Me.TotalsBindingSource.Sort = "BudgetType"
        '
        'DataGridTotals
        '
        Me.DataGridTotals.AllowUserToAddRows = False
        Me.DataGridTotals.AllowUserToDeleteRows = False
        Me.DataGridTotals.AllowUserToResizeColumns = False
        Me.DataGridTotals.AllowUserToResizeRows = False
        Me.DataGridTotals.AutoGenerateColumns = False
        Me.DataGridTotals.BackgroundColor = System.Drawing.Color.White
        Me.DataGridTotals.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridTotals.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle29
        Me.DataGridTotals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridTotals.ColumnHeadersVisible = False
        Me.DataGridTotals.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BudgetNoDataGridViewTextBoxColumn2, Me.BudgetTypeDataGridViewTextBoxColumn2, Me.PeriodFromDataGridViewTextBoxColumn2, Me.CodeDataGridViewTextBoxColumn2, Me.IncomeExpDataGridViewTextBoxColumn2, Me.Actual1DataGridViewTextBoxColumn2, Me.Budget1DataGridViewTextBoxColumn2, Me.Variance1DataGridViewTextBoxColumn2, Me.Actual2DataGridViewTextBoxColumn2, Me.Budget2DataGridViewTextBoxColumn2, Me.Variance2DataGridViewTextBoxColumn2, Me.Actual3DataGridViewTextBoxColumn2, Me.Budget3DataGridViewTextBoxColumn2, Me.Variance3DataGridViewTextBoxColumn2, Me.Variance4DataGridViewTextBoxColumn2, Me.Actual4DataGridViewTextBoxColumn2, Me.Budget4DataGridViewTextBoxColumn2, Me.Actual5DataGridViewTextBoxColumn2, Me.Budget5DataGridViewTextBoxColumn2, Me.Variance5DataGridViewTextBoxColumn2, Me.Actual6DataGridViewTextBoxColumn2, Me.Budget6DataGridViewTextBoxColumn2, Me.Variance6DataGridViewTextBoxColumn2, Me.Actual7DataGridViewTextBoxColumn2, Me.Budget7DataGridViewTextBoxColumn2, Me.Variance7DataGridViewTextBoxColumn2, Me.Actual8DataGridViewTextBoxColumn2, Me.Budget8DataGridViewTextBoxColumn2, Me.Variance8DataGridViewTextBoxColumn2, Me.Actual9DataGridViewTextBoxColumn2, Me.Budget9DataGridViewTextBoxColumn2, Me.Variance9DataGridViewTextBoxColumn2, Me.Actual10DataGridViewTextBoxColumn2, Me.Budget10DataGridViewTextBoxColumn2, Me.Variance10DataGridViewTextBoxColumn2, Me.Actual11DataGridViewTextBoxColumn2, Me.Budget11DataGridViewTextBoxColumn2, Me.Variance11DataGridViewTextBoxColumn2, Me.Actual12DataGridViewTextBoxColumn2, Me.Budget12DataGridViewTextBoxColumn2, Me.Variance12DataGridViewTextBoxColumn2})
        Me.DataGridTotals.Cursor = System.Windows.Forms.Cursors.No
        Me.DataGridTotals.DataSource = Me.TotalsBindingSource
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridTotals.DefaultCellStyle = DataGridViewCellStyle30
        Me.DataGridTotals.Location = New System.Drawing.Point(52, 244)
        Me.DataGridTotals.MultiSelect = False
        Me.DataGridTotals.Name = "DataGridTotals"
        Me.DataGridTotals.ReadOnly = True
        Me.DataGridTotals.RowHeadersVisible = False
        Me.DataGridTotals.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridTotals.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DataGridTotals.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridTotals.ShowEditingIcon = False
        Me.DataGridTotals.ShowRowErrors = False
        Me.DataGridTotals.Size = New System.Drawing.Size(729, 68)
        Me.DataGridTotals.TabIndex = 31
        Me.DataGridTotals.TabStop = False
        Me.DataGridTotals.Visible = False
        '
        'BudgetNoDataGridViewTextBoxColumn2
        '
        Me.BudgetNoDataGridViewTextBoxColumn2.DataPropertyName = "BudgetNo"
        Me.BudgetNoDataGridViewTextBoxColumn2.HeaderText = "BudgetNo"
        Me.BudgetNoDataGridViewTextBoxColumn2.Name = "BudgetNoDataGridViewTextBoxColumn2"
        Me.BudgetNoDataGridViewTextBoxColumn2.ReadOnly = True
        Me.BudgetNoDataGridViewTextBoxColumn2.Visible = False
        '
        'BudgetTypeDataGridViewTextBoxColumn2
        '
        Me.BudgetTypeDataGridViewTextBoxColumn2.DataPropertyName = "BudgetType"
        Me.BudgetTypeDataGridViewTextBoxColumn2.HeaderText = "BudgetType"
        Me.BudgetTypeDataGridViewTextBoxColumn2.Name = "BudgetTypeDataGridViewTextBoxColumn2"
        Me.BudgetTypeDataGridViewTextBoxColumn2.ReadOnly = True
        Me.BudgetTypeDataGridViewTextBoxColumn2.Visible = False
        '
        'PeriodFromDataGridViewTextBoxColumn2
        '
        Me.PeriodFromDataGridViewTextBoxColumn2.DataPropertyName = "PeriodFrom"
        Me.PeriodFromDataGridViewTextBoxColumn2.HeaderText = "PeriodFrom"
        Me.PeriodFromDataGridViewTextBoxColumn2.Name = "PeriodFromDataGridViewTextBoxColumn2"
        Me.PeriodFromDataGridViewTextBoxColumn2.ReadOnly = True
        Me.PeriodFromDataGridViewTextBoxColumn2.Visible = False
        '
        'CodeDataGridViewTextBoxColumn2
        '
        Me.CodeDataGridViewTextBoxColumn2.DataPropertyName = "Code"
        Me.CodeDataGridViewTextBoxColumn2.HeaderText = "Code"
        Me.CodeDataGridViewTextBoxColumn2.Name = "CodeDataGridViewTextBoxColumn2"
        Me.CodeDataGridViewTextBoxColumn2.ReadOnly = True
        Me.CodeDataGridViewTextBoxColumn2.Width = 118
        '
        'IncomeExpDataGridViewTextBoxColumn2
        '
        Me.IncomeExpDataGridViewTextBoxColumn2.DataPropertyName = "IncomeExp"
        Me.IncomeExpDataGridViewTextBoxColumn2.HeaderText = "IncomeExp"
        Me.IncomeExpDataGridViewTextBoxColumn2.Name = "IncomeExpDataGridViewTextBoxColumn2"
        Me.IncomeExpDataGridViewTextBoxColumn2.ReadOnly = True
        '
        'Actual1DataGridViewTextBoxColumn2
        '
        Me.Actual1DataGridViewTextBoxColumn2.DataPropertyName = "Actual1"
        Me.Actual1DataGridViewTextBoxColumn2.HeaderText = "Actual1"
        Me.Actual1DataGridViewTextBoxColumn2.Name = "Actual1DataGridViewTextBoxColumn2"
        Me.Actual1DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual1DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget1DataGridViewTextBoxColumn2
        '
        Me.Budget1DataGridViewTextBoxColumn2.DataPropertyName = "Budget1"
        Me.Budget1DataGridViewTextBoxColumn2.HeaderText = "Budget1"
        Me.Budget1DataGridViewTextBoxColumn2.Name = "Budget1DataGridViewTextBoxColumn2"
        Me.Budget1DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget1DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance1DataGridViewTextBoxColumn2
        '
        Me.Variance1DataGridViewTextBoxColumn2.DataPropertyName = "Variance1"
        Me.Variance1DataGridViewTextBoxColumn2.HeaderText = "Variance1"
        Me.Variance1DataGridViewTextBoxColumn2.Name = "Variance1DataGridViewTextBoxColumn2"
        Me.Variance1DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance1DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual2DataGridViewTextBoxColumn2
        '
        Me.Actual2DataGridViewTextBoxColumn2.DataPropertyName = "Actual2"
        Me.Actual2DataGridViewTextBoxColumn2.HeaderText = "Actual2"
        Me.Actual2DataGridViewTextBoxColumn2.Name = "Actual2DataGridViewTextBoxColumn2"
        Me.Actual2DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual2DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget2DataGridViewTextBoxColumn2
        '
        Me.Budget2DataGridViewTextBoxColumn2.DataPropertyName = "Budget2"
        Me.Budget2DataGridViewTextBoxColumn2.HeaderText = "Budget2"
        Me.Budget2DataGridViewTextBoxColumn2.Name = "Budget2DataGridViewTextBoxColumn2"
        Me.Budget2DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget2DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance2DataGridViewTextBoxColumn2
        '
        Me.Variance2DataGridViewTextBoxColumn2.DataPropertyName = "Variance2"
        Me.Variance2DataGridViewTextBoxColumn2.HeaderText = "Variance2"
        Me.Variance2DataGridViewTextBoxColumn2.Name = "Variance2DataGridViewTextBoxColumn2"
        Me.Variance2DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance2DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual3DataGridViewTextBoxColumn2
        '
        Me.Actual3DataGridViewTextBoxColumn2.DataPropertyName = "Actual3"
        Me.Actual3DataGridViewTextBoxColumn2.HeaderText = "Actual3"
        Me.Actual3DataGridViewTextBoxColumn2.Name = "Actual3DataGridViewTextBoxColumn2"
        Me.Actual3DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual3DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget3DataGridViewTextBoxColumn2
        '
        Me.Budget3DataGridViewTextBoxColumn2.DataPropertyName = "Budget3"
        Me.Budget3DataGridViewTextBoxColumn2.HeaderText = "Budget3"
        Me.Budget3DataGridViewTextBoxColumn2.Name = "Budget3DataGridViewTextBoxColumn2"
        Me.Budget3DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget3DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance3DataGridViewTextBoxColumn2
        '
        Me.Variance3DataGridViewTextBoxColumn2.DataPropertyName = "Variance3"
        Me.Variance3DataGridViewTextBoxColumn2.HeaderText = "Variance3"
        Me.Variance3DataGridViewTextBoxColumn2.Name = "Variance3DataGridViewTextBoxColumn2"
        Me.Variance3DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance3DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance4DataGridViewTextBoxColumn2
        '
        Me.Variance4DataGridViewTextBoxColumn2.DataPropertyName = "Variance4"
        Me.Variance4DataGridViewTextBoxColumn2.HeaderText = "Variance4"
        Me.Variance4DataGridViewTextBoxColumn2.Name = "Variance4DataGridViewTextBoxColumn2"
        Me.Variance4DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance4DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual4DataGridViewTextBoxColumn2
        '
        Me.Actual4DataGridViewTextBoxColumn2.DataPropertyName = "Actual4"
        Me.Actual4DataGridViewTextBoxColumn2.HeaderText = "Actual4"
        Me.Actual4DataGridViewTextBoxColumn2.Name = "Actual4DataGridViewTextBoxColumn2"
        Me.Actual4DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual4DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget4DataGridViewTextBoxColumn2
        '
        Me.Budget4DataGridViewTextBoxColumn2.DataPropertyName = "Budget4"
        Me.Budget4DataGridViewTextBoxColumn2.HeaderText = "Budget4"
        Me.Budget4DataGridViewTextBoxColumn2.Name = "Budget4DataGridViewTextBoxColumn2"
        Me.Budget4DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget4DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual5DataGridViewTextBoxColumn2
        '
        Me.Actual5DataGridViewTextBoxColumn2.DataPropertyName = "Actual5"
        Me.Actual5DataGridViewTextBoxColumn2.HeaderText = "Actual5"
        Me.Actual5DataGridViewTextBoxColumn2.Name = "Actual5DataGridViewTextBoxColumn2"
        Me.Actual5DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual5DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget5DataGridViewTextBoxColumn2
        '
        Me.Budget5DataGridViewTextBoxColumn2.DataPropertyName = "Budget5"
        Me.Budget5DataGridViewTextBoxColumn2.HeaderText = "Budget5"
        Me.Budget5DataGridViewTextBoxColumn2.Name = "Budget5DataGridViewTextBoxColumn2"
        Me.Budget5DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget5DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance5DataGridViewTextBoxColumn2
        '
        Me.Variance5DataGridViewTextBoxColumn2.DataPropertyName = "Variance5"
        Me.Variance5DataGridViewTextBoxColumn2.HeaderText = "Variance5"
        Me.Variance5DataGridViewTextBoxColumn2.Name = "Variance5DataGridViewTextBoxColumn2"
        Me.Variance5DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance5DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual6DataGridViewTextBoxColumn2
        '
        Me.Actual6DataGridViewTextBoxColumn2.DataPropertyName = "Actual6"
        Me.Actual6DataGridViewTextBoxColumn2.HeaderText = "Actual6"
        Me.Actual6DataGridViewTextBoxColumn2.Name = "Actual6DataGridViewTextBoxColumn2"
        Me.Actual6DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual6DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget6DataGridViewTextBoxColumn2
        '
        Me.Budget6DataGridViewTextBoxColumn2.DataPropertyName = "Budget6"
        Me.Budget6DataGridViewTextBoxColumn2.HeaderText = "Budget6"
        Me.Budget6DataGridViewTextBoxColumn2.Name = "Budget6DataGridViewTextBoxColumn2"
        Me.Budget6DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget6DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance6DataGridViewTextBoxColumn2
        '
        Me.Variance6DataGridViewTextBoxColumn2.DataPropertyName = "Variance6"
        Me.Variance6DataGridViewTextBoxColumn2.HeaderText = "Variance6"
        Me.Variance6DataGridViewTextBoxColumn2.Name = "Variance6DataGridViewTextBoxColumn2"
        Me.Variance6DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance6DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual7DataGridViewTextBoxColumn2
        '
        Me.Actual7DataGridViewTextBoxColumn2.DataPropertyName = "Actual7"
        Me.Actual7DataGridViewTextBoxColumn2.HeaderText = "Actual7"
        Me.Actual7DataGridViewTextBoxColumn2.Name = "Actual7DataGridViewTextBoxColumn2"
        Me.Actual7DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual7DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget7DataGridViewTextBoxColumn2
        '
        Me.Budget7DataGridViewTextBoxColumn2.DataPropertyName = "Budget7"
        Me.Budget7DataGridViewTextBoxColumn2.HeaderText = "Budget7"
        Me.Budget7DataGridViewTextBoxColumn2.Name = "Budget7DataGridViewTextBoxColumn2"
        Me.Budget7DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget7DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance7DataGridViewTextBoxColumn2
        '
        Me.Variance7DataGridViewTextBoxColumn2.DataPropertyName = "Variance7"
        Me.Variance7DataGridViewTextBoxColumn2.HeaderText = "Variance7"
        Me.Variance7DataGridViewTextBoxColumn2.Name = "Variance7DataGridViewTextBoxColumn2"
        Me.Variance7DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance7DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual8DataGridViewTextBoxColumn2
        '
        Me.Actual8DataGridViewTextBoxColumn2.DataPropertyName = "Actual8"
        Me.Actual8DataGridViewTextBoxColumn2.HeaderText = "Actual8"
        Me.Actual8DataGridViewTextBoxColumn2.Name = "Actual8DataGridViewTextBoxColumn2"
        Me.Actual8DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual8DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget8DataGridViewTextBoxColumn2
        '
        Me.Budget8DataGridViewTextBoxColumn2.DataPropertyName = "Budget8"
        Me.Budget8DataGridViewTextBoxColumn2.HeaderText = "Budget8"
        Me.Budget8DataGridViewTextBoxColumn2.Name = "Budget8DataGridViewTextBoxColumn2"
        Me.Budget8DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget8DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance8DataGridViewTextBoxColumn2
        '
        Me.Variance8DataGridViewTextBoxColumn2.DataPropertyName = "Variance8"
        Me.Variance8DataGridViewTextBoxColumn2.HeaderText = "Variance8"
        Me.Variance8DataGridViewTextBoxColumn2.Name = "Variance8DataGridViewTextBoxColumn2"
        Me.Variance8DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance8DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual9DataGridViewTextBoxColumn2
        '
        Me.Actual9DataGridViewTextBoxColumn2.DataPropertyName = "Actual9"
        Me.Actual9DataGridViewTextBoxColumn2.HeaderText = "Actual9"
        Me.Actual9DataGridViewTextBoxColumn2.Name = "Actual9DataGridViewTextBoxColumn2"
        Me.Actual9DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual9DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget9DataGridViewTextBoxColumn2
        '
        Me.Budget9DataGridViewTextBoxColumn2.DataPropertyName = "Budget9"
        Me.Budget9DataGridViewTextBoxColumn2.HeaderText = "Budget9"
        Me.Budget9DataGridViewTextBoxColumn2.Name = "Budget9DataGridViewTextBoxColumn2"
        Me.Budget9DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget9DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance9DataGridViewTextBoxColumn2
        '
        Me.Variance9DataGridViewTextBoxColumn2.DataPropertyName = "Variance9"
        Me.Variance9DataGridViewTextBoxColumn2.HeaderText = "Variance9"
        Me.Variance9DataGridViewTextBoxColumn2.Name = "Variance9DataGridViewTextBoxColumn2"
        Me.Variance9DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance9DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual10DataGridViewTextBoxColumn2
        '
        Me.Actual10DataGridViewTextBoxColumn2.DataPropertyName = "Actual10"
        Me.Actual10DataGridViewTextBoxColumn2.HeaderText = "Actual10"
        Me.Actual10DataGridViewTextBoxColumn2.Name = "Actual10DataGridViewTextBoxColumn2"
        Me.Actual10DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual10DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget10DataGridViewTextBoxColumn2
        '
        Me.Budget10DataGridViewTextBoxColumn2.DataPropertyName = "Budget10"
        Me.Budget10DataGridViewTextBoxColumn2.HeaderText = "Budget10"
        Me.Budget10DataGridViewTextBoxColumn2.Name = "Budget10DataGridViewTextBoxColumn2"
        Me.Budget10DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget10DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance10DataGridViewTextBoxColumn2
        '
        Me.Variance10DataGridViewTextBoxColumn2.DataPropertyName = "Variance10"
        Me.Variance10DataGridViewTextBoxColumn2.HeaderText = "Variance10"
        Me.Variance10DataGridViewTextBoxColumn2.Name = "Variance10DataGridViewTextBoxColumn2"
        Me.Variance10DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance10DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual11DataGridViewTextBoxColumn2
        '
        Me.Actual11DataGridViewTextBoxColumn2.DataPropertyName = "Actual11"
        Me.Actual11DataGridViewTextBoxColumn2.HeaderText = "Actual11"
        Me.Actual11DataGridViewTextBoxColumn2.Name = "Actual11DataGridViewTextBoxColumn2"
        Me.Actual11DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual11DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget11DataGridViewTextBoxColumn2
        '
        Me.Budget11DataGridViewTextBoxColumn2.DataPropertyName = "Budget11"
        Me.Budget11DataGridViewTextBoxColumn2.HeaderText = "Budget11"
        Me.Budget11DataGridViewTextBoxColumn2.Name = "Budget11DataGridViewTextBoxColumn2"
        Me.Budget11DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget11DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance11DataGridViewTextBoxColumn2
        '
        Me.Variance11DataGridViewTextBoxColumn2.DataPropertyName = "Variance11"
        Me.Variance11DataGridViewTextBoxColumn2.HeaderText = "Variance11"
        Me.Variance11DataGridViewTextBoxColumn2.Name = "Variance11DataGridViewTextBoxColumn2"
        Me.Variance11DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance11DataGridViewTextBoxColumn2.Width = 85
        '
        'Actual12DataGridViewTextBoxColumn2
        '
        Me.Actual12DataGridViewTextBoxColumn2.DataPropertyName = "Actual12"
        Me.Actual12DataGridViewTextBoxColumn2.HeaderText = "Actual12"
        Me.Actual12DataGridViewTextBoxColumn2.Name = "Actual12DataGridViewTextBoxColumn2"
        Me.Actual12DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Actual12DataGridViewTextBoxColumn2.Width = 85
        '
        'Budget12DataGridViewTextBoxColumn2
        '
        Me.Budget12DataGridViewTextBoxColumn2.DataPropertyName = "Budget12"
        Me.Budget12DataGridViewTextBoxColumn2.HeaderText = "Budget12"
        Me.Budget12DataGridViewTextBoxColumn2.Name = "Budget12DataGridViewTextBoxColumn2"
        Me.Budget12DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Budget12DataGridViewTextBoxColumn2.Width = 85
        '
        'Variance12DataGridViewTextBoxColumn2
        '
        Me.Variance12DataGridViewTextBoxColumn2.DataPropertyName = "Variance12"
        Me.Variance12DataGridViewTextBoxColumn2.HeaderText = "Variance12"
        Me.Variance12DataGridViewTextBoxColumn2.Name = "Variance12DataGridViewTextBoxColumn2"
        Me.Variance12DataGridViewTextBoxColumn2.ReadOnly = True
        Me.Variance12DataGridViewTextBoxColumn2.Width = 85
        '
        'lblHeader4
        '
        Me.lblHeader4.BackColor = System.Drawing.SystemColors.Control
        Me.lblHeader4.Location = New System.Drawing.Point(780, 39)
        Me.lblHeader4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHeader4.Name = "lblHeader4"
        Me.lblHeader4.Size = New System.Drawing.Size(17, 24)
        Me.lblHeader4.TabIndex = 32
        Me.lblHeader4.Visible = False
        '
        'lblTotal2
        '
        Me.lblTotal2.BackColor = System.Drawing.SystemColors.Control
        Me.lblTotal2.Location = New System.Drawing.Point(781, 244)
        Me.lblTotal2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTotal2.Name = "lblTotal2"
        Me.lblTotal2.Size = New System.Drawing.Size(16, 67)
        Me.lblTotal2.TabIndex = 33
        Me.lblTotal2.Visible = False
        '
        'lblTotal1
        '
        Me.lblTotal1.BackColor = System.Drawing.SystemColors.Control
        Me.lblTotal1.Location = New System.Drawing.Point(13, 244)
        Me.lblTotal1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTotal1.Name = "lblTotal1"
        Me.lblTotal1.Size = New System.Drawing.Size(39, 67)
        Me.lblTotal1.TabIndex = 34
        Me.lblTotal1.Visible = False
        '
        'AxCrystalReport2
        '
        Me.AxCrystalReport2.Enabled = True
        Me.AxCrystalReport2.Location = New System.Drawing.Point(16, 314)
        Me.AxCrystalReport2.Margin = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.AxCrystalReport2.Name = "AxCrystalReport2"
        Me.AxCrystalReport2.OcxState = CType(resources.GetObject("AxCrystalReport2.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxCrystalReport2.Size = New System.Drawing.Size(28, 28)
        Me.AxCrystalReport2.TabIndex = 35
        '
        'VpbsArchiveDataSet
        '
        Me.VpbsArchiveDataSet.DataSetName = "VpbsArchiveDataSet"
        Me.VpbsArchiveDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DirbudTableAdapterArc
        '
        Me.DirbudTableAdapterArc.ClearBeforeFill = True
        '
        'BudgetTableAdapterArc
        '
        Me.BudgetTableAdapterArc.ClearBeforeFill = True
        '
        'frmBudgets
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ClientSize = New System.Drawing.Size(810, 585)
        Me.ControlBox = False
        Me.Controls.Add(Me.AxCrystalReport2)
        Me.Controls.Add(Me.lblTotal1)
        Me.Controls.Add(Me.lblTotal2)
        Me.Controls.Add(Me.lblHeader4)
        Me.Controls.Add(Me.DataGridTotals)
        Me.Controls.Add(Me.lblHeader1)
        Me.Controls.Add(Me.lblHeader3)
        Me.Controls.Add(Me.lblHeader2)
        Me.Controls.Add(Me.lblBudgetHeader)
        Me.Controls.Add(Me.cmdScrollRgt)
        Me.Controls.Add(Me.cmdScrollLft)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DataGridActuals)
        Me.Controls.Add(Me.DataGridBudget)
        Me.Controls.Add(Me.DataGridDirBudget)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBudgets"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "VPBS - Budgets"
        CType(Me.DataGridDirBudget, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DirbudBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VPBSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VPBSTestDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.DataGridBudget, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BudgetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.DataGridActuals, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TotalsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridTotals, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxCrystalReport2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VpbsArchiveDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridDirBudget As System.Windows.Forms.DataGridView
    Friend WithEvents VPBSDataSet As VPBS13.VPBSDataSet
    Friend WithEvents DirbudBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DirbudTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.dirbudTableAdapter
    Friend WithEvents VPBSTestDataSet As VPBS13.VPBSTestDataSet
    Friend WithEvents DirbudTableAdapterTest As VPBS13.VPBSTestDataSetTableAdapters.dirbudTableAdapter
    Friend WithEvents BudgetNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BudgetTypeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DescriptionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PeriodFromDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PeriodToDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartMonthDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RefreshReqdDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CmdSelect As System.Windows.Forms.Button
    Friend WithEvents CmdClose As System.Windows.Forms.Button
    Friend WithEvents CmdCancel As System.Windows.Forms.Button
    Friend WithEvents CmdOk As System.Windows.Forms.Button
    Friend WithEvents CmdDelete As System.Windows.Forms.Button
    Friend WithEvents CmdChange As System.Windows.Forms.Button
    Friend WithEvents CmdRepeat As System.Windows.Forms.Button
    Friend WithEvents DataGridBudget As System.Windows.Forms.DataGridView
    Friend WithEvents BudgetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents BudgetTableAdapterTest As VPBS13.VPBSTestDataSetTableAdapters.BudgetTableAdapter
    Friend WithEvents BudgetTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.BudgetTableAdapter
    Friend WithEvents cmdScrollLft As System.Windows.Forms.Button
    Friend WithEvents cmdScrollRgt As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAmount4 As System.Windows.Forms.TextBox
    Friend WithEvents lblAmt4 As System.Windows.Forms.Label
    Friend WithEvents txtAmount3 As System.Windows.Forms.TextBox
    Friend WithEvents txtAmount2 As System.Windows.Forms.TextBox
    Friend WithEvents lblAmt2 As System.Windows.Forms.Label
    Friend WithEvents txtAmount1 As System.Windows.Forms.TextBox
    Friend WithEvents lblAmt1 As System.Windows.Forms.Label
    Friend WithEvents lblAmt3 As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents txtHeading As System.Windows.Forms.TextBox
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents lblIncExp As System.Windows.Forms.Label
    Friend WithEvents lblAmt12 As System.Windows.Forms.Label
    Friend WithEvents txtAmount12 As System.Windows.Forms.TextBox
    Friend WithEvents txtAmount11 As System.Windows.Forms.TextBox
    Friend WithEvents txtAmount10 As System.Windows.Forms.TextBox
    Friend WithEvents lblAmt10 As System.Windows.Forms.Label
    Friend WithEvents txtAmount9 As System.Windows.Forms.TextBox
    Friend WithEvents lblAmt9 As System.Windows.Forms.Label
    Friend WithEvents lblAmt11 As System.Windows.Forms.Label
    Friend WithEvents txtAmount8 As System.Windows.Forms.TextBox
    Friend WithEvents lblAmt8 As System.Windows.Forms.Label
    Friend WithEvents txtAmount7 As System.Windows.Forms.TextBox
    Friend WithEvents txtAmount6 As System.Windows.Forms.TextBox
    Friend WithEvents lblAmt6 As System.Windows.Forms.Label
    Friend WithEvents txtAmount5 As System.Windows.Forms.TextBox
    Friend WithEvents lblAmt5 As System.Windows.Forms.Label
    Friend WithEvents lblAmt7 As System.Windows.Forms.Label
    Friend WithEvents cboIncExp As System.Windows.Forms.ComboBox
    Friend WithEvents lblBudgetHeader As System.Windows.Forms.Label
    Friend WithEvents DataGridActuals As System.Windows.Forms.DataGridView
    Friend WithEvents lblHeader2 As System.Windows.Forms.Label
    Friend WithEvents lblHeader3 As System.Windows.Forms.Label
    Friend WithEvents lblHeader1 As System.Windows.Forms.Label
    Friend WithEvents TotalsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridTotals As System.Windows.Forms.DataGridView
    Friend WithEvents BudgetNo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BudgetType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PeriodFrom As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CodeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IncomeExpDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget2DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget3DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget4DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget5DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget6DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget7DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget8DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget9DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget10DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget11DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget12DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual2DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual3DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual4DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual5DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual6DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual7DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual8DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual9DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual10DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual11DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual12DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance2DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance3DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance4DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance5DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance6DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance7DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance8DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance9DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance10DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance11DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance12DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblHeader4 As System.Windows.Forms.Label
    Friend WithEvents lblTotal2 As System.Windows.Forms.Label
    Friend WithEvents lblTotal1 As System.Windows.Forms.Label
    Friend WithEvents BudgetNoDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BudgetTypeDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PeriodFromDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CodeDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IncomeExpDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual1DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget1DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance1DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual2DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget2DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance2DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual3DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget3DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance3DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance4DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual4DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget4DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual5DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget5DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance5DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual6DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget6DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance6DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual7DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget7DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance7DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual8DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget8DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance8DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual9DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget9DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance9DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual10DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget10DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance10DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual11DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget11DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance11DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual12DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget12DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance12DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BudgetNoDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BudgetTypeDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PeriodFromDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CodeDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IncomeExpDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual1DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget1DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance1DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual2DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget2DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance2DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual3DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget3DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance3DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual4DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget4DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance4DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual5DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget5DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance5DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual6DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget6DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance6DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual7DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget7DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance7DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual8DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget8DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance8DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual9DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget9DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance9DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual10DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget10DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance10DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual11DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget11DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance11DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Actual12DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Budget12DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Variance12DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmdRptOk As System.Windows.Forms.Button
    Friend WithEvents cmdReport As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents rdo3Option1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdo3Option0 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents rdo2Option2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdo2Option1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdo2Option0 As System.Windows.Forms.RadioButton
    Friend WithEvents rdo3Option2 As System.Windows.Forms.RadioButton
    Friend WithEvents AxCrystalReport2 As AxCrystal.AxCrystalReport
    Friend WithEvents VpbsArchiveDataSet As VPBS13.VpbsArchiveDataSet
    Friend WithEvents DirbudTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.dirbudTableAdapter
    Friend WithEvents BudgetTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.BudgetTableAdapter
End Class
