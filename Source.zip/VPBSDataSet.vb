﻿Partial Class VPBSDataSet

    Partial Class TransferIDDataTable

    End Class

    Partial Class pbstransDataTable

        Private Sub pbstransDataTable_pbstransRowChanging(sender As Object, e As pbstransRowChangeEvent) Handles Me.pbstransRowChanging

        End Sub

    End Class

    Partial Class TransferIDDataTable

    End Class
End Class
