﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmQueries
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmQueries))
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.VpbsDataSet = New VPBS13.VPBSDataSet()
        Me.VpbsTestDataSet = New VPBS13.VPBSTestDataSet()
        Me.PbstransBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PbstransTableAdapterTest = New VPBS13.VPBSTestDataSetTableAdapters.pbstransTableAdapter()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdOkRpt = New System.Windows.Forms.Button()
        Me.GroupBox20 = New System.Windows.Forms.GroupBox()
        Me.rdoOptSelect1 = New System.Windows.Forms.RadioButton()
        Me.rdoOptSelect0 = New System.Windows.Forms.RadioButton()
        Me.CmdReport = New System.Windows.Forms.Button()
        Me.CmdClose = New System.Windows.Forms.Button()
        Me.CmdCancel = New System.Windows.Forms.Button()
        Me.CmdOk = New System.Windows.Forms.Button()
        Me.CmdNew = New System.Windows.Forms.Button()
        Me.CmdSave = New System.Windows.Forms.Button()
        Me.CmdFilter = New System.Windows.Forms.Button()
        Me.CmdOkProj = New System.Windows.Forms.Button()
        Me.CmdOkFind = New System.Windows.Forms.Button()
        Me.CmdOkReport = New System.Windows.Forms.Button()
        Me.lblAccountHeader = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker0 = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rdoDate5 = New System.Windows.Forms.RadioButton()
        Me.rdoDate3 = New System.Windows.Forms.RadioButton()
        Me.rdoDate4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.rdoDate2 = New System.Windows.Forms.RadioButton()
        Me.rdoDate1 = New System.Windows.Forms.RadioButton()
        Me.rdoDate0 = New System.Windows.Forms.RadioButton()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtRef1 = New System.Windows.Forms.TextBox()
        Me.txtRef0 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.rdoRef5 = New System.Windows.Forms.RadioButton()
        Me.rdoRef3 = New System.Windows.Forms.RadioButton()
        Me.rdoRef4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.rdoRef2 = New System.Windows.Forms.RadioButton()
        Me.rdoRef1 = New System.Windows.Forms.RadioButton()
        Me.rdoRef0 = New System.Windows.Forms.RadioButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.cboCust1 = New System.Windows.Forms.ComboBox()
        Me.CustomersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboCust0 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.rdoCust5 = New System.Windows.Forms.RadioButton()
        Me.rdoCust3 = New System.Windows.Forms.RadioButton()
        Me.rdoCust4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.rdoCust2 = New System.Windows.Forms.RadioButton()
        Me.rdoCust1 = New System.Windows.Forms.RadioButton()
        Me.rdoCust0 = New System.Windows.Forms.RadioButton()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.cboAnalysis1 = New System.Windows.Forms.ComboBox()
        Me.AnalysisBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboAnalysis0 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.rdoAnal5 = New System.Windows.Forms.RadioButton()
        Me.rdoAnal3 = New System.Windows.Forms.RadioButton()
        Me.rdoAnal4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.rdoAnal2 = New System.Windows.Forms.RadioButton()
        Me.rdoAnal1 = New System.Windows.Forms.RadioButton()
        Me.rdoAnal0 = New System.Windows.Forms.RadioButton()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.cboGLCode1 = New System.Windows.Forms.ComboBox()
        Me.GLCodeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboGLCode0 = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.rdoGL5 = New System.Windows.Forms.RadioButton()
        Me.rdoGL3 = New System.Windows.Forms.RadioButton()
        Me.rdoGL4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox19 = New System.Windows.Forms.GroupBox()
        Me.rdoGL2 = New System.Windows.Forms.RadioButton()
        Me.rdoGL1 = New System.Windows.Forms.RadioButton()
        Me.rdoGL0 = New System.Windows.Forms.RadioButton()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.txtAmount1 = New System.Windows.Forms.TextBox()
        Me.txtAmount0 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.rdoAmt5 = New System.Windows.Forms.RadioButton()
        Me.rdoAmt3 = New System.Windows.Forms.RadioButton()
        Me.rdoAmt4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.rdoAmt2 = New System.Windows.Forms.RadioButton()
        Me.rdoAmt1 = New System.Windows.Forms.RadioButton()
        Me.rdoAmt0 = New System.Windows.Forms.RadioButton()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.GroupBox21 = New System.Windows.Forms.GroupBox()
        Me.txtReportGroup0 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cboReportGroup0 = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.GroupBox22 = New System.Windows.Forms.GroupBox()
        Me.txtGroup4 = New System.Windows.Forms.TextBox()
        Me.txtGroup3 = New System.Windows.Forms.TextBox()
        Me.txtGroup2 = New System.Windows.Forms.TextBox()
        Me.txtGroup1 = New System.Windows.Forms.TextBox()
        Me.cboGroup4 = New System.Windows.Forms.ComboBox()
        Me.cboGroup3 = New System.Windows.Forms.ComboBox()
        Me.cboGroup2 = New System.Windows.Forms.ComboBox()
        Me.cboGroup1 = New System.Windows.Forms.ComboBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.CustomersTableAdapterTest = New VPBS13.VPBSTestDataSetTableAdapters.CustomersTableAdapter()
        Me.GLCodeTableAdapterTest = New VPBS13.VPBSTestDataSetTableAdapters.GLCodeTableAdapter()
        Me.AnalysisTableAdapterTest = New VPBS13.VPBSTestDataSetTableAdapters.AnalysisTableAdapter()
        Me.PbstransTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.pbstransTableAdapter()
        Me.AnalysisTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.AnalysisTableAdapter()
        Me.GLCodeTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.GLCodeTableAdapter()
        Me.CustomersTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.CustomersTableAdapter()
        Me.TransQueryBBindingSourceLive = New System.Windows.Forms.BindingSource(Me.components)
        Me.VPBSDataSet1 = New VPBS13.VPBSDataSet1()
        Me.AxCrystalReport1 = New AxCrystal.AxCrystalReport()
        Me.DataGridQueries = New System.Windows.Forms.DataGridView()
        Me.DateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReferenceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomerDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AmountDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AnalysisDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GlcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FolioDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReconciledDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VATDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BalanceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DebitCreditDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TimeKeyDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TransferDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TransferIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PaymentDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReceiptDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TransQueryATableAdapterTest = New VPBS13.VPBSTestDataSetTableAdapters.TransQueryATableAdapter()
        Me.TransQueryBTableAdapterTest = New VPBS13.VPBSTestDataSetTableAdapters.TransQueryBTableAdapter()
        Me.DataGridQueriesB = New System.Windows.Forms.DataGridView()
        Me.DateDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReferenceDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomerDataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailsDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AmountDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DebitCreditDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VATDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AnalysisDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GlCodeDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FolioDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReconciledDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BalanceDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TimeKeyDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountNoDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TransferDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TransferIDDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PaymentDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReceiptDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PbstransTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.pbstransTableAdapter()
        Me.AnalysisTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.AnalysisTableAdapter()
        Me.GLCodeTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.GLCodeTableAdapter()
        Me.CustomersTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.CustomersTableAdapter()
        Me.TransQueryATableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.TransQueryATableAdapter()
        Me.TransQueryBTableAdapterLive = New VPBS13.VPBSDataSet1TableAdapters.TransQueryBTableAdapter()
        Me.VpbsArchiveDataSet = New VPBS13.VpbsArchiveDataSet()
        Me.TransQueryBBindingSourceArc = New System.Windows.Forms.BindingSource(Me.components)
        Me.VpbsArchiveDataSet3 = New VPBS13.VpbsArchiveDataSet3()
        Me.TransQueryBTableAdapterArc = New VPBS13.VpbsArchiveDataSet3TableAdapters.TransQueryBTableAdapter()
        Me.TransQueryATableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.TransQueryATableAdapter()
        CType(Me.VpbsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VpbsTestDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbstransBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox20.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        CType(Me.CustomersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        CType(Me.AnalysisBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox15.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox17.SuspendLayout()
        CType(Me.GLCodeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox18.SuspendLayout()
        Me.GroupBox19.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox21.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.GroupBox22.SuspendLayout()
        CType(Me.TransQueryBBindingSourceLive, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VPBSDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxCrystalReport1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridQueries, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridQueriesB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VpbsArchiveDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TransQueryBBindingSourceArc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VpbsArchiveDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VpbsDataSet
        '
        Me.VpbsDataSet.DataSetName = "VPBSDataSet"
        Me.VpbsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VpbsTestDataSet
        '
        Me.VpbsTestDataSet.DataSetName = "VPBSTestDataSet"
        Me.VpbsTestDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PbstransBindingSource
        '
        Me.PbstransBindingSource.DataMember = "pbstrans"
        Me.PbstransBindingSource.DataSource = Me.VpbsDataSet
        Me.PbstransBindingSource.Filter = "AccountNo ='99999999'"
        Me.PbstransBindingSource.Sort = "Date"
        '
        'PbstransTableAdapterTest
        '
        Me.PbstransTableAdapterTest.ClearBeforeFill = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.cmdOkRpt)
        Me.GroupBox1.Controls.Add(Me.GroupBox20)
        Me.GroupBox1.Controls.Add(Me.CmdReport)
        Me.GroupBox1.Controls.Add(Me.CmdClose)
        Me.GroupBox1.Controls.Add(Me.CmdCancel)
        Me.GroupBox1.Controls.Add(Me.CmdOk)
        Me.GroupBox1.Controls.Add(Me.CmdNew)
        Me.GroupBox1.Controls.Add(Me.CmdSave)
        Me.GroupBox1.Controls.Add(Me.CmdFilter)
        Me.GroupBox1.Controls.Add(Me.CmdOkProj)
        Me.GroupBox1.Controls.Add(Me.CmdOkFind)
        Me.GroupBox1.Controls.Add(Me.CmdOkReport)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 519)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(786, 66)
        Me.GroupBox1.TabIndex = 19
        Me.GroupBox1.TabStop = False
        '
        'cmdOkRpt
        '
        Me.cmdOkRpt.BackColor = System.Drawing.Color.LightGray
        Me.cmdOkRpt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdOkRpt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOkRpt.Location = New System.Drawing.Point(105, 19)
        Me.cmdOkRpt.Name = "cmdOkRpt"
        Me.cmdOkRpt.Size = New System.Drawing.Size(80, 35)
        Me.cmdOkRpt.TabIndex = 14
        Me.cmdOkRpt.Text = "&OkReport"
        Me.cmdOkRpt.UseVisualStyleBackColor = False
        Me.cmdOkRpt.Visible = False
        '
        'GroupBox20
        '
        Me.GroupBox20.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox20.Controls.Add(Me.rdoOptSelect1)
        Me.GroupBox20.Controls.Add(Me.rdoOptSelect0)
        Me.GroupBox20.Location = New System.Drawing.Point(294, 19)
        Me.GroupBox20.Name = "GroupBox20"
        Me.GroupBox20.Size = New System.Drawing.Size(88, 37)
        Me.GroupBox20.TabIndex = 13
        Me.GroupBox20.TabStop = False
        '
        'rdoOptSelect1
        '
        Me.rdoOptSelect1.Location = New System.Drawing.Point(0, 18)
        Me.rdoOptSelect1.Name = "rdoOptSelect1"
        Me.rdoOptSelect1.Size = New System.Drawing.Size(80, 17)
        Me.rdoOptSelect1.TabIndex = 0
        Me.rdoOptSelect1.TabStop = True
        Me.rdoOptSelect1.Text = "By Budget"
        Me.rdoOptSelect1.UseVisualStyleBackColor = True
        '
        'rdoOptSelect0
        '
        Me.rdoOptSelect0.Checked = True
        Me.rdoOptSelect0.Location = New System.Drawing.Point(0, 0)
        Me.rdoOptSelect0.Name = "rdoOptSelect0"
        Me.rdoOptSelect0.Size = New System.Drawing.Size(82, 17)
        Me.rdoOptSelect0.TabIndex = 0
        Me.rdoOptSelect0.TabStop = True
        Me.rdoOptSelect0.Text = "By Account"
        Me.rdoOptSelect0.UseVisualStyleBackColor = True
        '
        'CmdReport
        '
        Me.CmdReport.BackColor = System.Drawing.Color.LightGray
        Me.CmdReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdReport.Location = New System.Drawing.Point(19, 19)
        Me.CmdReport.Name = "CmdReport"
        Me.CmdReport.Size = New System.Drawing.Size(80, 35)
        Me.CmdReport.TabIndex = 11
        Me.CmdReport.Text = "&Report"
        Me.CmdReport.UseVisualStyleBackColor = False
        '
        'CmdClose
        '
        Me.CmdClose.BackColor = System.Drawing.Color.LightGray
        Me.CmdClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdClose.Location = New System.Drawing.Point(683, 19)
        Me.CmdClose.Name = "CmdClose"
        Me.CmdClose.Size = New System.Drawing.Size(80, 35)
        Me.CmdClose.TabIndex = 7
        Me.CmdClose.Text = "&Close"
        Me.CmdClose.UseVisualStyleBackColor = False
        '
        'CmdCancel
        '
        Me.CmdCancel.BackColor = System.Drawing.Color.LightGray
        Me.CmdCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdCancel.Location = New System.Drawing.Point(577, 19)
        Me.CmdCancel.Name = "CmdCancel"
        Me.CmdCancel.Size = New System.Drawing.Size(80, 35)
        Me.CmdCancel.TabIndex = 6
        Me.CmdCancel.Text = "&Cancel"
        Me.CmdCancel.UseVisualStyleBackColor = False
        '
        'CmdOk
        '
        Me.CmdOk.BackColor = System.Drawing.Color.LightGray
        Me.CmdOk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdOk.Location = New System.Drawing.Point(491, 19)
        Me.CmdOk.Name = "CmdOk"
        Me.CmdOk.Size = New System.Drawing.Size(80, 35)
        Me.CmdOk.TabIndex = 5
        Me.CmdOk.Text = "&Ok"
        Me.CmdOk.UseVisualStyleBackColor = False
        '
        'CmdNew
        '
        Me.CmdNew.BackColor = System.Drawing.Color.LightGray
        Me.CmdNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdNew.Location = New System.Drawing.Point(105, 19)
        Me.CmdNew.Name = "CmdNew"
        Me.CmdNew.Size = New System.Drawing.Size(80, 35)
        Me.CmdNew.TabIndex = 4
        Me.CmdNew.Text = "&New"
        Me.CmdNew.UseVisualStyleBackColor = False
        Me.CmdNew.Visible = False
        '
        'CmdSave
        '
        Me.CmdSave.BackColor = System.Drawing.Color.LightGray
        Me.CmdSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSave.Location = New System.Drawing.Point(191, 19)
        Me.CmdSave.Name = "CmdSave"
        Me.CmdSave.Size = New System.Drawing.Size(80, 35)
        Me.CmdSave.TabIndex = 1
        Me.CmdSave.Text = "&Save"
        Me.CmdSave.UseVisualStyleBackColor = False
        Me.CmdSave.Visible = False
        '
        'CmdFilter
        '
        Me.CmdFilter.BackColor = System.Drawing.Color.LightGray
        Me.CmdFilter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdFilter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdFilter.Location = New System.Drawing.Point(19, 19)
        Me.CmdFilter.Name = "CmdFilter"
        Me.CmdFilter.Size = New System.Drawing.Size(80, 35)
        Me.CmdFilter.TabIndex = 0
        Me.CmdFilter.Text = "&Filter"
        Me.CmdFilter.UseVisualStyleBackColor = False
        Me.CmdFilter.Visible = False
        '
        'CmdOkProj
        '
        Me.CmdOkProj.BackColor = System.Drawing.Color.LightGray
        Me.CmdOkProj.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdOkProj.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdOkProj.Location = New System.Drawing.Point(491, 19)
        Me.CmdOkProj.Name = "CmdOkProj"
        Me.CmdOkProj.Size = New System.Drawing.Size(80, 35)
        Me.CmdOkProj.TabIndex = 10
        Me.CmdOkProj.Text = "&OkProj"
        Me.CmdOkProj.UseVisualStyleBackColor = False
        Me.CmdOkProj.Visible = False
        '
        'CmdOkFind
        '
        Me.CmdOkFind.BackColor = System.Drawing.Color.LightGray
        Me.CmdOkFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdOkFind.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdOkFind.Location = New System.Drawing.Point(491, 19)
        Me.CmdOkFind.Name = "CmdOkFind"
        Me.CmdOkFind.Size = New System.Drawing.Size(80, 35)
        Me.CmdOkFind.TabIndex = 8
        Me.CmdOkFind.Text = "&OkFind"
        Me.CmdOkFind.UseVisualStyleBackColor = False
        Me.CmdOkFind.Visible = False
        '
        'CmdOkReport
        '
        Me.CmdOkReport.BackColor = System.Drawing.Color.LightGray
        Me.CmdOkReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdOkReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdOkReport.Location = New System.Drawing.Point(491, 19)
        Me.CmdOkReport.Name = "CmdOkReport"
        Me.CmdOkReport.Size = New System.Drawing.Size(80, 35)
        Me.CmdOkReport.TabIndex = 12
        Me.CmdOkReport.Text = "&OkReport"
        Me.CmdOkReport.UseVisualStyleBackColor = False
        Me.CmdOkReport.Visible = False
        '
        'lblAccountHeader
        '
        Me.lblAccountHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblAccountHeader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAccountHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccountHeader.Location = New System.Drawing.Point(12, 9)
        Me.lblAccountHeader.Name = "lblAccountHeader"
        Me.lblAccountHeader.Size = New System.Drawing.Size(786, 27)
        Me.lblAccountHeader.TabIndex = 20
        Me.lblAccountHeader.Text = "Select an Account Number to start..."
        Me.lblAccountHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblAccountHeader.UseMnemonic = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(12, 309)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(3, 3)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(786, 204)
        Me.TabControl1.TabIndex = 21
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Silver
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(778, 175)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Date Range       "
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox2.Controls.Add(Me.DateTimePicker0)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.GroupBox4)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(766, 165)
        Me.GroupBox2.TabIndex = 19
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Select Date Range"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(600, 86)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(137, 22)
        Me.DateTimePicker1.TabIndex = 7
        '
        'DateTimePicker0
        '
        Me.DateTimePicker0.Location = New System.Drawing.Point(238, 86)
        Me.DateTimePicker0.Name = "DateTimePicker0"
        Me.DateTimePicker0.Size = New System.Drawing.Size(137, 22)
        Me.DateTimePicker0.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(383, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(179, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "and/or Where date (optional)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Where date"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rdoDate5)
        Me.GroupBox3.Controls.Add(Me.rdoDate3)
        Me.GroupBox3.Controls.Add(Me.rdoDate4)
        Me.GroupBox3.Location = New System.Drawing.Point(386, 44)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        '
        'rdoDate5
        '
        Me.rdoDate5.AutoSize = True
        Me.rdoDate5.Location = New System.Drawing.Point(12, 66)
        Me.rdoDate5.Name = "rdoDate5"
        Me.rdoDate5.Size = New System.Drawing.Size(98, 20)
        Me.rdoDate5.TabIndex = 4
        Me.rdoDate5.TabStop = True
        Me.rdoDate5.Text = "Not equal to"
        Me.rdoDate5.UseVisualStyleBackColor = True
        '
        'rdoDate3
        '
        Me.rdoDate3.AutoSize = True
        Me.rdoDate3.Location = New System.Drawing.Point(12, 22)
        Me.rdoDate3.Name = "rdoDate3"
        Me.rdoDate3.Size = New System.Drawing.Size(83, 20)
        Me.rdoDate3.TabIndex = 3
        Me.rdoDate3.TabStop = True
        Me.rdoDate3.Text = "Less than"
        Me.rdoDate3.UseVisualStyleBackColor = True
        '
        'rdoDate4
        '
        Me.rdoDate4.AutoSize = True
        Me.rdoDate4.Location = New System.Drawing.Point(12, 44)
        Me.rdoDate4.Name = "rdoDate4"
        Me.rdoDate4.Size = New System.Drawing.Size(135, 20)
        Me.rdoDate4.TabIndex = 2
        Me.rdoDate4.TabStop = True
        Me.rdoDate4.Text = "Less than/equal to"
        Me.rdoDate4.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rdoDate2)
        Me.GroupBox4.Controls.Add(Me.rdoDate1)
        Me.GroupBox4.Controls.Add(Me.rdoDate0)
        Me.GroupBox4.Location = New System.Drawing.Point(23, 44)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        '
        'rdoDate2
        '
        Me.rdoDate2.AutoSize = True
        Me.rdoDate2.Location = New System.Drawing.Point(17, 66)
        Me.rdoDate2.Name = "rdoDate2"
        Me.rdoDate2.Size = New System.Drawing.Size(75, 20)
        Me.rdoDate2.TabIndex = 2
        Me.rdoDate2.TabStop = True
        Me.rdoDate2.Text = "Equal to"
        Me.rdoDate2.UseVisualStyleBackColor = True
        '
        'rdoDate1
        '
        Me.rdoDate1.AutoSize = True
        Me.rdoDate1.Location = New System.Drawing.Point(17, 44)
        Me.rdoDate1.Name = "rdoDate1"
        Me.rdoDate1.Size = New System.Drawing.Size(151, 20)
        Me.rdoDate1.TabIndex = 1
        Me.rdoDate1.TabStop = True
        Me.rdoDate1.Text = "Greater than/equal to"
        Me.rdoDate1.UseVisualStyleBackColor = True
        '
        'rdoDate0
        '
        Me.rdoDate0.AutoSize = True
        Me.rdoDate0.Location = New System.Drawing.Point(17, 22)
        Me.rdoDate0.Name = "rdoDate0"
        Me.rdoDate0.Size = New System.Drawing.Size(99, 20)
        Me.rdoDate0.TabIndex = 0
        Me.rdoDate0.TabStop = True
        Me.rdoDate0.Text = "Greater than"
        Me.rdoDate0.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Silver
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage2.Controls.Add(Me.GroupBox5)
        Me.TabPage2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(778, 175)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Reference        "
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox5.Controls.Add(Me.txtRef1)
        Me.GroupBox5.Controls.Add(Me.txtRef0)
        Me.GroupBox5.Controls.Add(Me.Label20)
        Me.GroupBox5.Controls.Add(Me.Label19)
        Me.GroupBox5.Controls.Add(Me.GroupBox7)
        Me.GroupBox5.Controls.Add(Me.GroupBox6)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(766, 165)
        Me.GroupBox5.TabIndex = 18
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Select Reference"
        '
        'txtRef1
        '
        Me.txtRef1.Location = New System.Drawing.Point(602, 86)
        Me.txtRef1.Name = "txtRef1"
        Me.txtRef1.Size = New System.Drawing.Size(122, 22)
        Me.txtRef1.TabIndex = 9
        '
        'txtRef0
        '
        Me.txtRef0.Location = New System.Drawing.Point(239, 86)
        Me.txtRef0.Name = "txtRef0"
        Me.txtRef0.Size = New System.Drawing.Size(122, 22)
        Me.txtRef0.TabIndex = 8
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(383, 30)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(209, 16)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = "and/or Where reference (optional)"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(26, 30)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(108, 16)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Where reference"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.rdoRef5)
        Me.GroupBox7.Controls.Add(Me.rdoRef3)
        Me.GroupBox7.Controls.Add(Me.rdoRef4)
        Me.GroupBox7.Location = New System.Drawing.Point(386, 44)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox7.TabIndex = 1
        Me.GroupBox7.TabStop = False
        '
        'rdoRef5
        '
        Me.rdoRef5.AutoSize = True
        Me.rdoRef5.Location = New System.Drawing.Point(12, 66)
        Me.rdoRef5.Name = "rdoRef5"
        Me.rdoRef5.Size = New System.Drawing.Size(98, 20)
        Me.rdoRef5.TabIndex = 4
        Me.rdoRef5.TabStop = True
        Me.rdoRef5.Text = "Not equal to"
        Me.rdoRef5.UseVisualStyleBackColor = True
        '
        'rdoRef3
        '
        Me.rdoRef3.AutoSize = True
        Me.rdoRef3.Location = New System.Drawing.Point(12, 22)
        Me.rdoRef3.Name = "rdoRef3"
        Me.rdoRef3.Size = New System.Drawing.Size(83, 20)
        Me.rdoRef3.TabIndex = 3
        Me.rdoRef3.TabStop = True
        Me.rdoRef3.Text = "Less than"
        Me.rdoRef3.UseVisualStyleBackColor = True
        '
        'rdoRef4
        '
        Me.rdoRef4.AutoSize = True
        Me.rdoRef4.Location = New System.Drawing.Point(12, 44)
        Me.rdoRef4.Name = "rdoRef4"
        Me.rdoRef4.Size = New System.Drawing.Size(135, 20)
        Me.rdoRef4.TabIndex = 2
        Me.rdoRef4.TabStop = True
        Me.rdoRef4.Text = "Less than/equal to"
        Me.rdoRef4.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.rdoRef2)
        Me.GroupBox6.Controls.Add(Me.rdoRef1)
        Me.GroupBox6.Controls.Add(Me.rdoRef0)
        Me.GroupBox6.Location = New System.Drawing.Point(23, 44)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox6.TabIndex = 0
        Me.GroupBox6.TabStop = False
        '
        'rdoRef2
        '
        Me.rdoRef2.AutoSize = True
        Me.rdoRef2.Location = New System.Drawing.Point(17, 66)
        Me.rdoRef2.Name = "rdoRef2"
        Me.rdoRef2.Size = New System.Drawing.Size(75, 20)
        Me.rdoRef2.TabIndex = 2
        Me.rdoRef2.TabStop = True
        Me.rdoRef2.Text = "Equal to"
        Me.rdoRef2.UseVisualStyleBackColor = True
        '
        'rdoRef1
        '
        Me.rdoRef1.AutoSize = True
        Me.rdoRef1.Location = New System.Drawing.Point(17, 44)
        Me.rdoRef1.Name = "rdoRef1"
        Me.rdoRef1.Size = New System.Drawing.Size(151, 20)
        Me.rdoRef1.TabIndex = 1
        Me.rdoRef1.TabStop = True
        Me.rdoRef1.Text = "Greater than/equal to"
        Me.rdoRef1.UseVisualStyleBackColor = True
        '
        'rdoRef0
        '
        Me.rdoRef0.AutoSize = True
        Me.rdoRef0.Location = New System.Drawing.Point(17, 22)
        Me.rdoRef0.Name = "rdoRef0"
        Me.rdoRef0.Size = New System.Drawing.Size(99, 20)
        Me.rdoRef0.TabIndex = 0
        Me.rdoRef0.TabStop = True
        Me.rdoRef0.Text = "Greater than"
        Me.rdoRef0.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Silver
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage3.Controls.Add(Me.GroupBox11)
        Me.TabPage3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(778, 175)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Customer          "
        '
        'GroupBox11
        '
        Me.GroupBox11.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox11.Controls.Add(Me.cboCust1)
        Me.GroupBox11.Controls.Add(Me.cboCust0)
        Me.GroupBox11.Controls.Add(Me.Label5)
        Me.GroupBox11.Controls.Add(Me.Label6)
        Me.GroupBox11.Controls.Add(Me.GroupBox12)
        Me.GroupBox11.Controls.Add(Me.GroupBox13)
        Me.GroupBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox11.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(766, 165)
        Me.GroupBox11.TabIndex = 20
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Select Customer"
        '
        'cboCust1
        '
        Me.cboCust1.DataSource = Me.CustomersBindingSource
        Me.cboCust1.DisplayMember = "ShortName"
        Me.cboCust1.FormattingEnabled = True
        Me.cboCust1.Location = New System.Drawing.Point(603, 84)
        Me.cboCust1.Name = "cboCust1"
        Me.cboCust1.Size = New System.Drawing.Size(131, 24)
        Me.cboCust1.TabIndex = 11
        '
        'CustomersBindingSource
        '
        Me.CustomersBindingSource.DataMember = "Customers"
        Me.CustomersBindingSource.DataSource = Me.VpbsDataSet
        Me.CustomersBindingSource.Sort = "ShortName"
        '
        'cboCust0
        '
        Me.cboCust0.DataSource = Me.CustomersBindingSource
        Me.cboCust0.DisplayMember = "ShortName"
        Me.cboCust0.FormattingEnabled = True
        Me.cboCust0.Location = New System.Drawing.Point(239, 84)
        Me.cboCust0.Name = "cboCust0"
        Me.cboCust0.Size = New System.Drawing.Size(131, 24)
        Me.cboCust0.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(383, 30)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(207, 16)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "and/or Where customer (optional)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(26, 30)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(106, 16)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Where customer"
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.rdoCust5)
        Me.GroupBox12.Controls.Add(Me.rdoCust3)
        Me.GroupBox12.Controls.Add(Me.rdoCust4)
        Me.GroupBox12.Location = New System.Drawing.Point(386, 44)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox12.TabIndex = 1
        Me.GroupBox12.TabStop = False
        '
        'rdoCust5
        '
        Me.rdoCust5.AutoSize = True
        Me.rdoCust5.Location = New System.Drawing.Point(12, 66)
        Me.rdoCust5.Name = "rdoCust5"
        Me.rdoCust5.Size = New System.Drawing.Size(98, 20)
        Me.rdoCust5.TabIndex = 4
        Me.rdoCust5.TabStop = True
        Me.rdoCust5.Text = "Not equal to"
        Me.rdoCust5.UseVisualStyleBackColor = True
        '
        'rdoCust3
        '
        Me.rdoCust3.AutoSize = True
        Me.rdoCust3.Location = New System.Drawing.Point(12, 22)
        Me.rdoCust3.Name = "rdoCust3"
        Me.rdoCust3.Size = New System.Drawing.Size(83, 20)
        Me.rdoCust3.TabIndex = 3
        Me.rdoCust3.TabStop = True
        Me.rdoCust3.Text = "Less than"
        Me.rdoCust3.UseVisualStyleBackColor = True
        '
        'rdoCust4
        '
        Me.rdoCust4.AutoSize = True
        Me.rdoCust4.Location = New System.Drawing.Point(12, 44)
        Me.rdoCust4.Name = "rdoCust4"
        Me.rdoCust4.Size = New System.Drawing.Size(135, 20)
        Me.rdoCust4.TabIndex = 2
        Me.rdoCust4.TabStop = True
        Me.rdoCust4.Text = "Less than/equal to"
        Me.rdoCust4.UseVisualStyleBackColor = True
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.rdoCust2)
        Me.GroupBox13.Controls.Add(Me.rdoCust1)
        Me.GroupBox13.Controls.Add(Me.rdoCust0)
        Me.GroupBox13.Location = New System.Drawing.Point(23, 44)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox13.TabIndex = 0
        Me.GroupBox13.TabStop = False
        '
        'rdoCust2
        '
        Me.rdoCust2.AutoSize = True
        Me.rdoCust2.Location = New System.Drawing.Point(17, 66)
        Me.rdoCust2.Name = "rdoCust2"
        Me.rdoCust2.Size = New System.Drawing.Size(75, 20)
        Me.rdoCust2.TabIndex = 2
        Me.rdoCust2.TabStop = True
        Me.rdoCust2.Text = "Equal to"
        Me.rdoCust2.UseVisualStyleBackColor = True
        '
        'rdoCust1
        '
        Me.rdoCust1.AutoSize = True
        Me.rdoCust1.Location = New System.Drawing.Point(17, 44)
        Me.rdoCust1.Name = "rdoCust1"
        Me.rdoCust1.Size = New System.Drawing.Size(151, 20)
        Me.rdoCust1.TabIndex = 1
        Me.rdoCust1.TabStop = True
        Me.rdoCust1.Text = "Greater than/equal to"
        Me.rdoCust1.UseVisualStyleBackColor = True
        '
        'rdoCust0
        '
        Me.rdoCust0.AutoSize = True
        Me.rdoCust0.Location = New System.Drawing.Point(17, 22)
        Me.rdoCust0.Name = "rdoCust0"
        Me.rdoCust0.Size = New System.Drawing.Size(99, 20)
        Me.rdoCust0.TabIndex = 0
        Me.rdoCust0.TabStop = True
        Me.rdoCust0.Text = "Greater than"
        Me.rdoCust0.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.Silver
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage4.Controls.Add(Me.GroupBox14)
        Me.TabPage4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(778, 175)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Analysis Code   "
        '
        'GroupBox14
        '
        Me.GroupBox14.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox14.Controls.Add(Me.cboAnalysis1)
        Me.GroupBox14.Controls.Add(Me.cboAnalysis0)
        Me.GroupBox14.Controls.Add(Me.Label7)
        Me.GroupBox14.Controls.Add(Me.Label8)
        Me.GroupBox14.Controls.Add(Me.GroupBox15)
        Me.GroupBox14.Controls.Add(Me.GroupBox16)
        Me.GroupBox14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox14.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(766, 165)
        Me.GroupBox14.TabIndex = 21
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Analysis code"
        '
        'cboAnalysis1
        '
        Me.cboAnalysis1.DataSource = Me.AnalysisBindingSource
        Me.cboAnalysis1.DisplayMember = "Code"
        Me.cboAnalysis1.FormattingEnabled = True
        Me.cboAnalysis1.Location = New System.Drawing.Point(603, 84)
        Me.cboAnalysis1.Name = "cboAnalysis1"
        Me.cboAnalysis1.Size = New System.Drawing.Size(131, 24)
        Me.cboAnalysis1.TabIndex = 11
        '
        'AnalysisBindingSource
        '
        Me.AnalysisBindingSource.DataMember = "Analysis"
        Me.AnalysisBindingSource.DataSource = Me.VpbsDataSet
        Me.AnalysisBindingSource.Sort = "Code"
        '
        'cboAnalysis0
        '
        Me.cboAnalysis0.DataSource = Me.AnalysisBindingSource
        Me.cboAnalysis0.DisplayMember = "Code"
        Me.cboAnalysis0.FormattingEnabled = True
        Me.cboAnalysis0.Location = New System.Drawing.Point(239, 84)
        Me.cboAnalysis0.Name = "cboAnalysis0"
        Me.cboAnalysis0.Size = New System.Drawing.Size(131, 24)
        Me.cboAnalysis0.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(383, 30)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(236, 16)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "and/or Where analysis code (optional)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(26, 30)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(135, 16)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Where analysis code"
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.rdoAnal5)
        Me.GroupBox15.Controls.Add(Me.rdoAnal3)
        Me.GroupBox15.Controls.Add(Me.rdoAnal4)
        Me.GroupBox15.Location = New System.Drawing.Point(386, 44)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox15.TabIndex = 1
        Me.GroupBox15.TabStop = False
        '
        'rdoAnal5
        '
        Me.rdoAnal5.AutoSize = True
        Me.rdoAnal5.Location = New System.Drawing.Point(12, 66)
        Me.rdoAnal5.Name = "rdoAnal5"
        Me.rdoAnal5.Size = New System.Drawing.Size(98, 20)
        Me.rdoAnal5.TabIndex = 4
        Me.rdoAnal5.TabStop = True
        Me.rdoAnal5.Text = "Not equal to"
        Me.rdoAnal5.UseVisualStyleBackColor = True
        '
        'rdoAnal3
        '
        Me.rdoAnal3.AutoSize = True
        Me.rdoAnal3.Location = New System.Drawing.Point(12, 22)
        Me.rdoAnal3.Name = "rdoAnal3"
        Me.rdoAnal3.Size = New System.Drawing.Size(83, 20)
        Me.rdoAnal3.TabIndex = 3
        Me.rdoAnal3.TabStop = True
        Me.rdoAnal3.Text = "Less than"
        Me.rdoAnal3.UseVisualStyleBackColor = True
        '
        'rdoAnal4
        '
        Me.rdoAnal4.AutoSize = True
        Me.rdoAnal4.Location = New System.Drawing.Point(12, 44)
        Me.rdoAnal4.Name = "rdoAnal4"
        Me.rdoAnal4.Size = New System.Drawing.Size(135, 20)
        Me.rdoAnal4.TabIndex = 2
        Me.rdoAnal4.TabStop = True
        Me.rdoAnal4.Text = "Less than/equal to"
        Me.rdoAnal4.UseVisualStyleBackColor = True
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.rdoAnal2)
        Me.GroupBox16.Controls.Add(Me.rdoAnal1)
        Me.GroupBox16.Controls.Add(Me.rdoAnal0)
        Me.GroupBox16.Location = New System.Drawing.Point(23, 44)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox16.TabIndex = 0
        Me.GroupBox16.TabStop = False
        '
        'rdoAnal2
        '
        Me.rdoAnal2.AutoSize = True
        Me.rdoAnal2.Location = New System.Drawing.Point(17, 66)
        Me.rdoAnal2.Name = "rdoAnal2"
        Me.rdoAnal2.Size = New System.Drawing.Size(75, 20)
        Me.rdoAnal2.TabIndex = 2
        Me.rdoAnal2.TabStop = True
        Me.rdoAnal2.Text = "Equal to"
        Me.rdoAnal2.UseVisualStyleBackColor = True
        '
        'rdoAnal1
        '
        Me.rdoAnal1.AutoSize = True
        Me.rdoAnal1.Location = New System.Drawing.Point(17, 44)
        Me.rdoAnal1.Name = "rdoAnal1"
        Me.rdoAnal1.Size = New System.Drawing.Size(151, 20)
        Me.rdoAnal1.TabIndex = 1
        Me.rdoAnal1.TabStop = True
        Me.rdoAnal1.Text = "Greater than/equal to"
        Me.rdoAnal1.UseVisualStyleBackColor = True
        '
        'rdoAnal0
        '
        Me.rdoAnal0.AutoSize = True
        Me.rdoAnal0.Location = New System.Drawing.Point(17, 22)
        Me.rdoAnal0.Name = "rdoAnal0"
        Me.rdoAnal0.Size = New System.Drawing.Size(99, 20)
        Me.rdoAnal0.TabIndex = 0
        Me.rdoAnal0.TabStop = True
        Me.rdoAnal0.Text = "Greater than"
        Me.rdoAnal0.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.Silver
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage5.Controls.Add(Me.GroupBox17)
        Me.TabPage5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(778, 175)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "GL Code           "
        '
        'GroupBox17
        '
        Me.GroupBox17.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox17.Controls.Add(Me.cboGLCode1)
        Me.GroupBox17.Controls.Add(Me.cboGLCode0)
        Me.GroupBox17.Controls.Add(Me.Label9)
        Me.GroupBox17.Controls.Add(Me.Label10)
        Me.GroupBox17.Controls.Add(Me.GroupBox18)
        Me.GroupBox17.Controls.Add(Me.GroupBox19)
        Me.GroupBox17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox17.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Size = New System.Drawing.Size(766, 165)
        Me.GroupBox17.TabIndex = 22
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "GL code"
        '
        'cboGLCode1
        '
        Me.cboGLCode1.DataSource = Me.GLCodeBindingSource
        Me.cboGLCode1.DisplayMember = "Code"
        Me.cboGLCode1.FormattingEnabled = True
        Me.cboGLCode1.Location = New System.Drawing.Point(603, 84)
        Me.cboGLCode1.Name = "cboGLCode1"
        Me.cboGLCode1.Size = New System.Drawing.Size(131, 24)
        Me.cboGLCode1.TabIndex = 11
        '
        'GLCodeBindingSource
        '
        Me.GLCodeBindingSource.DataMember = "GLCode"
        Me.GLCodeBindingSource.DataSource = Me.VpbsDataSet
        Me.GLCodeBindingSource.Sort = "Code"
        '
        'cboGLCode0
        '
        Me.cboGLCode0.DataSource = Me.GLCodeBindingSource
        Me.cboGLCode0.DisplayMember = "Code"
        Me.cboGLCode0.FormattingEnabled = True
        Me.cboGLCode0.Location = New System.Drawing.Point(239, 84)
        Me.cboGLCode0.Name = "cboGLCode0"
        Me.cboGLCode0.Size = New System.Drawing.Size(131, 24)
        Me.cboGLCode0.TabIndex = 10
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(383, 30)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(203, 16)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "and/or Where GL code (optional)"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(26, 30)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(102, 16)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Where GL code"
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.rdoGL5)
        Me.GroupBox18.Controls.Add(Me.rdoGL3)
        Me.GroupBox18.Controls.Add(Me.rdoGL4)
        Me.GroupBox18.Location = New System.Drawing.Point(386, 44)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox18.TabIndex = 1
        Me.GroupBox18.TabStop = False
        '
        'rdoGL5
        '
        Me.rdoGL5.AutoSize = True
        Me.rdoGL5.Location = New System.Drawing.Point(12, 66)
        Me.rdoGL5.Name = "rdoGL5"
        Me.rdoGL5.Size = New System.Drawing.Size(98, 20)
        Me.rdoGL5.TabIndex = 4
        Me.rdoGL5.TabStop = True
        Me.rdoGL5.Text = "Not equal to"
        Me.rdoGL5.UseVisualStyleBackColor = True
        '
        'rdoGL3
        '
        Me.rdoGL3.AutoSize = True
        Me.rdoGL3.Location = New System.Drawing.Point(12, 22)
        Me.rdoGL3.Name = "rdoGL3"
        Me.rdoGL3.Size = New System.Drawing.Size(83, 20)
        Me.rdoGL3.TabIndex = 3
        Me.rdoGL3.TabStop = True
        Me.rdoGL3.Text = "Less than"
        Me.rdoGL3.UseVisualStyleBackColor = True
        '
        'rdoGL4
        '
        Me.rdoGL4.AutoSize = True
        Me.rdoGL4.Location = New System.Drawing.Point(12, 44)
        Me.rdoGL4.Name = "rdoGL4"
        Me.rdoGL4.Size = New System.Drawing.Size(135, 20)
        Me.rdoGL4.TabIndex = 2
        Me.rdoGL4.TabStop = True
        Me.rdoGL4.Text = "Less than/equal to"
        Me.rdoGL4.UseVisualStyleBackColor = True
        '
        'GroupBox19
        '
        Me.GroupBox19.Controls.Add(Me.rdoGL2)
        Me.GroupBox19.Controls.Add(Me.rdoGL1)
        Me.GroupBox19.Controls.Add(Me.rdoGL0)
        Me.GroupBox19.Location = New System.Drawing.Point(23, 44)
        Me.GroupBox19.Name = "GroupBox19"
        Me.GroupBox19.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox19.TabIndex = 0
        Me.GroupBox19.TabStop = False
        '
        'rdoGL2
        '
        Me.rdoGL2.AutoSize = True
        Me.rdoGL2.Location = New System.Drawing.Point(17, 66)
        Me.rdoGL2.Name = "rdoGL2"
        Me.rdoGL2.Size = New System.Drawing.Size(75, 20)
        Me.rdoGL2.TabIndex = 2
        Me.rdoGL2.TabStop = True
        Me.rdoGL2.Text = "Equal to"
        Me.rdoGL2.UseVisualStyleBackColor = True
        '
        'rdoGL1
        '
        Me.rdoGL1.AutoSize = True
        Me.rdoGL1.Location = New System.Drawing.Point(17, 44)
        Me.rdoGL1.Name = "rdoGL1"
        Me.rdoGL1.Size = New System.Drawing.Size(151, 20)
        Me.rdoGL1.TabIndex = 1
        Me.rdoGL1.TabStop = True
        Me.rdoGL1.Text = "Greater than/equal to"
        Me.rdoGL1.UseVisualStyleBackColor = True
        '
        'rdoGL0
        '
        Me.rdoGL0.AutoSize = True
        Me.rdoGL0.Location = New System.Drawing.Point(17, 22)
        Me.rdoGL0.Name = "rdoGL0"
        Me.rdoGL0.Size = New System.Drawing.Size(99, 20)
        Me.rdoGL0.TabIndex = 0
        Me.rdoGL0.TabStop = True
        Me.rdoGL0.Text = "Greater than"
        Me.rdoGL0.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.Silver
        Me.TabPage6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage6.Controls.Add(Me.GroupBox8)
        Me.TabPage6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(778, 175)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Amount             "
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox8.Controls.Add(Me.txtAmount1)
        Me.GroupBox8.Controls.Add(Me.txtAmount0)
        Me.GroupBox8.Controls.Add(Me.Label3)
        Me.GroupBox8.Controls.Add(Me.Label4)
        Me.GroupBox8.Controls.Add(Me.GroupBox9)
        Me.GroupBox8.Controls.Add(Me.GroupBox10)
        Me.GroupBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(766, 165)
        Me.GroupBox8.TabIndex = 19
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Select Amount"
        '
        'txtAmount1
        '
        Me.txtAmount1.Location = New System.Drawing.Point(602, 86)
        Me.txtAmount1.Name = "txtAmount1"
        Me.txtAmount1.Size = New System.Drawing.Size(122, 22)
        Me.txtAmount1.TabIndex = 9
        '
        'txtAmount0
        '
        Me.txtAmount0.Location = New System.Drawing.Point(239, 86)
        Me.txtAmount0.Name = "txtAmount0"
        Me.txtAmount0.Size = New System.Drawing.Size(122, 22)
        Me.txtAmount0.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(383, 30)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(196, 16)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "and/or Where amount (optional)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 30)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Where amount"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.rdoAmt5)
        Me.GroupBox9.Controls.Add(Me.rdoAmt3)
        Me.GroupBox9.Controls.Add(Me.rdoAmt4)
        Me.GroupBox9.Location = New System.Drawing.Point(386, 44)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox9.TabIndex = 1
        Me.GroupBox9.TabStop = False
        '
        'rdoAmt5
        '
        Me.rdoAmt5.AutoSize = True
        Me.rdoAmt5.Location = New System.Drawing.Point(12, 66)
        Me.rdoAmt5.Name = "rdoAmt5"
        Me.rdoAmt5.Size = New System.Drawing.Size(98, 20)
        Me.rdoAmt5.TabIndex = 4
        Me.rdoAmt5.TabStop = True
        Me.rdoAmt5.Text = "Not equal to"
        Me.rdoAmt5.UseVisualStyleBackColor = True
        '
        'rdoAmt3
        '
        Me.rdoAmt3.AutoSize = True
        Me.rdoAmt3.Location = New System.Drawing.Point(12, 22)
        Me.rdoAmt3.Name = "rdoAmt3"
        Me.rdoAmt3.Size = New System.Drawing.Size(83, 20)
        Me.rdoAmt3.TabIndex = 3
        Me.rdoAmt3.TabStop = True
        Me.rdoAmt3.Text = "Less than"
        Me.rdoAmt3.UseVisualStyleBackColor = True
        '
        'rdoAmt4
        '
        Me.rdoAmt4.AutoSize = True
        Me.rdoAmt4.Location = New System.Drawing.Point(12, 44)
        Me.rdoAmt4.Name = "rdoAmt4"
        Me.rdoAmt4.Size = New System.Drawing.Size(135, 20)
        Me.rdoAmt4.TabIndex = 2
        Me.rdoAmt4.TabStop = True
        Me.rdoAmt4.Text = "Less than/equal to"
        Me.rdoAmt4.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.rdoAmt2)
        Me.GroupBox10.Controls.Add(Me.rdoAmt1)
        Me.GroupBox10.Controls.Add(Me.rdoAmt0)
        Me.GroupBox10.Location = New System.Drawing.Point(23, 44)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(200, 95)
        Me.GroupBox10.TabIndex = 0
        Me.GroupBox10.TabStop = False
        '
        'rdoAmt2
        '
        Me.rdoAmt2.AutoSize = True
        Me.rdoAmt2.Location = New System.Drawing.Point(17, 66)
        Me.rdoAmt2.Name = "rdoAmt2"
        Me.rdoAmt2.Size = New System.Drawing.Size(75, 20)
        Me.rdoAmt2.TabIndex = 2
        Me.rdoAmt2.TabStop = True
        Me.rdoAmt2.Text = "Equal to"
        Me.rdoAmt2.UseVisualStyleBackColor = True
        '
        'rdoAmt1
        '
        Me.rdoAmt1.AutoSize = True
        Me.rdoAmt1.Location = New System.Drawing.Point(17, 44)
        Me.rdoAmt1.Name = "rdoAmt1"
        Me.rdoAmt1.Size = New System.Drawing.Size(151, 20)
        Me.rdoAmt1.TabIndex = 1
        Me.rdoAmt1.TabStop = True
        Me.rdoAmt1.Text = "Greater than/equal to"
        Me.rdoAmt1.UseVisualStyleBackColor = True
        '
        'rdoAmt0
        '
        Me.rdoAmt0.AutoSize = True
        Me.rdoAmt0.Location = New System.Drawing.Point(17, 22)
        Me.rdoAmt0.Name = "rdoAmt0"
        Me.rdoAmt0.Size = New System.Drawing.Size(99, 20)
        Me.rdoAmt0.TabIndex = 0
        Me.rdoAmt0.TabStop = True
        Me.rdoAmt0.Text = "Greater than"
        Me.rdoAmt0.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.Silver
        Me.TabPage7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage7.Controls.Add(Me.GroupBox21)
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(778, 175)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Report Grouping  "
        '
        'GroupBox21
        '
        Me.GroupBox21.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox21.Controls.Add(Me.txtReportGroup0)
        Me.GroupBox21.Controls.Add(Me.Label11)
        Me.GroupBox21.Controls.Add(Me.cboReportGroup0)
        Me.GroupBox21.Controls.Add(Me.Label12)
        Me.GroupBox21.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox21.Name = "GroupBox21"
        Me.GroupBox21.Size = New System.Drawing.Size(771, 168)
        Me.GroupBox21.TabIndex = 0
        Me.GroupBox21.TabStop = False
        Me.GroupBox21.Text = "Report Grouping Section"
        '
        'txtReportGroup0
        '
        Me.txtReportGroup0.Location = New System.Drawing.Point(185, 139)
        Me.txtReportGroup0.Name = "txtReportGroup0"
        Me.txtReportGroup0.Size = New System.Drawing.Size(100, 22)
        Me.txtReportGroup0.TabIndex = 9
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Silver
        Me.Label11.Location = New System.Drawing.Point(19, 109)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(144, 24)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Group and Total by:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboReportGroup0
        '
        Me.cboReportGroup0.FormattingEnabled = True
        Me.cboReportGroup0.Location = New System.Drawing.Point(185, 109)
        Me.cboReportGroup0.Name = "cboReportGroup0"
        Me.cboReportGroup0.Size = New System.Drawing.Size(185, 24)
        Me.cboReportGroup0.TabIndex = 4
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Silver
        Me.Label12.Location = New System.Drawing.Point(185, 44)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(383, 24)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Defines grouping, sort order and sub-totals to maintain"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.Silver
        Me.TabPage8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage8.Controls.Add(Me.GroupBox22)
        Me.TabPage8.Location = New System.Drawing.Point(4, 25)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(778, 175)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Report Details   "
        '
        'GroupBox22
        '
        Me.GroupBox22.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox22.Controls.Add(Me.txtGroup4)
        Me.GroupBox22.Controls.Add(Me.txtGroup3)
        Me.GroupBox22.Controls.Add(Me.txtGroup2)
        Me.GroupBox22.Controls.Add(Me.txtGroup1)
        Me.GroupBox22.Controls.Add(Me.cboGroup4)
        Me.GroupBox22.Controls.Add(Me.cboGroup3)
        Me.GroupBox22.Controls.Add(Me.cboGroup2)
        Me.GroupBox22.Controls.Add(Me.cboGroup1)
        Me.GroupBox22.Controls.Add(Me.TextBox6)
        Me.GroupBox22.Controls.Add(Me.TextBox5)
        Me.GroupBox22.Controls.Add(Me.Label14)
        Me.GroupBox22.Controls.Add(Me.Label13)
        Me.GroupBox22.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox22.Name = "GroupBox22"
        Me.GroupBox22.Size = New System.Drawing.Size(771, 168)
        Me.GroupBox22.TabIndex = 0
        Me.GroupBox22.TabStop = False
        Me.GroupBox22.Text = "Report Details Section"
        '
        'txtGroup4
        '
        Me.txtGroup4.Location = New System.Drawing.Point(542, 139)
        Me.txtGroup4.Name = "txtGroup4"
        Me.txtGroup4.Size = New System.Drawing.Size(100, 22)
        Me.txtGroup4.TabIndex = 12
        '
        'txtGroup3
        '
        Me.txtGroup3.Location = New System.Drawing.Point(399, 139)
        Me.txtGroup3.Name = "txtGroup3"
        Me.txtGroup3.Size = New System.Drawing.Size(100, 22)
        Me.txtGroup3.TabIndex = 11
        '
        'txtGroup2
        '
        Me.txtGroup2.Location = New System.Drawing.Point(255, 139)
        Me.txtGroup2.Name = "txtGroup2"
        Me.txtGroup2.Size = New System.Drawing.Size(100, 22)
        Me.txtGroup2.TabIndex = 10
        '
        'txtGroup1
        '
        Me.txtGroup1.Location = New System.Drawing.Point(113, 140)
        Me.txtGroup1.Name = "txtGroup1"
        Me.txtGroup1.Size = New System.Drawing.Size(100, 22)
        Me.txtGroup1.TabIndex = 9
        '
        'cboGroup4
        '
        Me.cboGroup4.FormattingEnabled = True
        Me.cboGroup4.Location = New System.Drawing.Point(542, 109)
        Me.cboGroup4.Name = "cboGroup4"
        Me.cboGroup4.Size = New System.Drawing.Size(121, 24)
        Me.cboGroup4.TabIndex = 7
        Me.cboGroup4.Text = "cboGroup"
        '
        'cboGroup3
        '
        Me.cboGroup3.FormattingEnabled = True
        Me.cboGroup3.Location = New System.Drawing.Point(399, 109)
        Me.cboGroup3.Name = "cboGroup3"
        Me.cboGroup3.Size = New System.Drawing.Size(121, 24)
        Me.cboGroup3.TabIndex = 6
        Me.cboGroup3.Text = "cboGroup"
        '
        'cboGroup2
        '
        Me.cboGroup2.FormattingEnabled = True
        Me.cboGroup2.Location = New System.Drawing.Point(255, 109)
        Me.cboGroup2.Name = "cboGroup2"
        Me.cboGroup2.Size = New System.Drawing.Size(121, 24)
        Me.cboGroup2.TabIndex = 5
        Me.cboGroup2.Text = "cboGroup"
        '
        'cboGroup1
        '
        Me.cboGroup1.FormattingEnabled = True
        Me.cboGroup1.Location = New System.Drawing.Point(113, 109)
        Me.cboGroup1.Name = "cboGroup1"
        Me.cboGroup1.Size = New System.Drawing.Size(121, 24)
        Me.cboGroup1.TabIndex = 4
        Me.cboGroup1.Text = "cboGroup"
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(677, 109)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(80, 22)
        Me.TextBox6.TabIndex = 3
        Me.TextBox6.Text = "Amount"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(13, 109)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(80, 22)
        Me.TextBox5.TabIndex = 2
        Me.TextBox5.Text = "Date"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Silver
        Me.Label14.Location = New System.Drawing.Point(237, 53)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(349, 23)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "decide which fields you want to include in report.      "
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Silver
        Me.Label13.Location = New System.Drawing.Point(237, 30)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(349, 23)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Includes repeating records in main body of report - "
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CustomersTableAdapterTest
        '
        Me.CustomersTableAdapterTest.ClearBeforeFill = True
        '
        'GLCodeTableAdapterTest
        '
        Me.GLCodeTableAdapterTest.ClearBeforeFill = True
        '
        'AnalysisTableAdapterTest
        '
        Me.AnalysisTableAdapterTest.ClearBeforeFill = True
        '
        'PbstransTableAdapterLive
        '
        Me.PbstransTableAdapterLive.ClearBeforeFill = True
        '
        'AnalysisTableAdapterLive
        '
        Me.AnalysisTableAdapterLive.ClearBeforeFill = True
        '
        'GLCodeTableAdapterLive
        '
        Me.GLCodeTableAdapterLive.ClearBeforeFill = True
        '
        'CustomersTableAdapterLive
        '
        Me.CustomersTableAdapterLive.ClearBeforeFill = True
        '
        'TransQueryBBindingSourceLive
        '
        Me.TransQueryBBindingSourceLive.DataMember = "TransQueryB"
        Me.TransQueryBBindingSourceLive.DataSource = Me.VPBSDataSet1
        Me.TransQueryBBindingSourceLive.Sort = "Date"
        '
        'VPBSDataSet1
        '
        Me.VPBSDataSet1.DataSetName = "VPBSDataSet1"
        Me.VPBSDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AxCrystalReport1
        '
        Me.AxCrystalReport1.Enabled = True
        Me.AxCrystalReport1.Location = New System.Drawing.Point(12, 5)
        Me.AxCrystalReport1.Name = "AxCrystalReport1"
        Me.AxCrystalReport1.OcxState = CType(resources.GetObject("AxCrystalReport1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxCrystalReport1.Size = New System.Drawing.Size(28, 28)
        Me.AxCrystalReport1.TabIndex = 22
        '
        'DataGridQueries
        '
        Me.DataGridQueries.AllowUserToAddRows = False
        Me.DataGridQueries.AllowUserToDeleteRows = False
        Me.DataGridQueries.AllowUserToResizeRows = False
        Me.DataGridQueries.AutoGenerateColumns = False
        Me.DataGridQueries.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridQueries.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridQueries.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridQueries.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle21
        Me.DataGridQueries.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridQueries.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DateDataGridViewTextBoxColumn, Me.ReferenceDataGridViewTextBoxColumn, Me.CustomerDataGridViewTextBoxColumn, Me.DetailsDataGridViewTextBoxColumn, Me.AmountDataGridViewTextBoxColumn, Me.AnalysisDataGridViewTextBoxColumn, Me.AccountDataGridViewTextBoxColumn, Me.GlcodeDataGridViewTextBoxColumn, Me.FolioDataGridViewTextBoxColumn, Me.ReconciledDataGridViewTextBoxColumn, Me.VATDataGridViewTextBoxColumn, Me.BalanceDataGridViewTextBoxColumn, Me.DebitCreditDataGridViewTextBoxColumn, Me.TimeKeyDataGridViewTextBoxColumn, Me.AccountNoDataGridViewTextBoxColumn, Me.TransferDataGridViewTextBoxColumn, Me.TransferIDDataGridViewTextBoxColumn, Me.PaymentDataGridViewTextBoxColumn, Me.ReceiptDataGridViewTextBoxColumn})
        Me.DataGridQueries.DataSource = Me.PbstransBindingSource
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle25.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridQueries.DefaultCellStyle = DataGridViewCellStyle25
        Me.DataGridQueries.Location = New System.Drawing.Point(12, 43)
        Me.DataGridQueries.MultiSelect = False
        Me.DataGridQueries.Name = "DataGridQueries"
        Me.DataGridQueries.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridQueries.Size = New System.Drawing.Size(786, 260)
        Me.DataGridQueries.TabIndex = 0
        '
        'DateDataGridViewTextBoxColumn
        '
        Me.DateDataGridViewTextBoxColumn.DataPropertyName = "Date"
        Me.DateDataGridViewTextBoxColumn.HeaderText = "Date"
        Me.DateDataGridViewTextBoxColumn.Name = "DateDataGridViewTextBoxColumn"
        '
        'ReferenceDataGridViewTextBoxColumn
        '
        Me.ReferenceDataGridViewTextBoxColumn.DataPropertyName = "Reference"
        Me.ReferenceDataGridViewTextBoxColumn.HeaderText = "Reference"
        Me.ReferenceDataGridViewTextBoxColumn.Name = "ReferenceDataGridViewTextBoxColumn"
        '
        'CustomerDataGridViewTextBoxColumn
        '
        Me.CustomerDataGridViewTextBoxColumn.DataPropertyName = "Customer"
        Me.CustomerDataGridViewTextBoxColumn.HeaderText = "Customer"
        Me.CustomerDataGridViewTextBoxColumn.Name = "CustomerDataGridViewTextBoxColumn"
        '
        'DetailsDataGridViewTextBoxColumn
        '
        Me.DetailsDataGridViewTextBoxColumn.DataPropertyName = "Details"
        Me.DetailsDataGridViewTextBoxColumn.HeaderText = "Details"
        Me.DetailsDataGridViewTextBoxColumn.Name = "DetailsDataGridViewTextBoxColumn"
        '
        'AmountDataGridViewTextBoxColumn
        '
        Me.AmountDataGridViewTextBoxColumn.DataPropertyName = "Amount"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle22.Format = "N2"
        DataGridViewCellStyle22.NullValue = Nothing
        Me.AmountDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle22
        Me.AmountDataGridViewTextBoxColumn.HeaderText = "Amount"
        Me.AmountDataGridViewTextBoxColumn.Name = "AmountDataGridViewTextBoxColumn"
        '
        'AnalysisDataGridViewTextBoxColumn
        '
        Me.AnalysisDataGridViewTextBoxColumn.DataPropertyName = "Analysis"
        Me.AnalysisDataGridViewTextBoxColumn.HeaderText = "Analysis"
        Me.AnalysisDataGridViewTextBoxColumn.Name = "AnalysisDataGridViewTextBoxColumn"
        '
        'AccountDataGridViewTextBoxColumn
        '
        Me.AccountDataGridViewTextBoxColumn.DataPropertyName = "Account"
        Me.AccountDataGridViewTextBoxColumn.HeaderText = "Account"
        Me.AccountDataGridViewTextBoxColumn.Name = "AccountDataGridViewTextBoxColumn"
        Me.AccountDataGridViewTextBoxColumn.Visible = False
        '
        'GlcodeDataGridViewTextBoxColumn
        '
        Me.GlcodeDataGridViewTextBoxColumn.DataPropertyName = "Glcode"
        Me.GlcodeDataGridViewTextBoxColumn.HeaderText = "Glcode"
        Me.GlcodeDataGridViewTextBoxColumn.Name = "GlcodeDataGridViewTextBoxColumn"
        '
        'FolioDataGridViewTextBoxColumn
        '
        Me.FolioDataGridViewTextBoxColumn.DataPropertyName = "Folio"
        Me.FolioDataGridViewTextBoxColumn.HeaderText = "Folio"
        Me.FolioDataGridViewTextBoxColumn.Name = "FolioDataGridViewTextBoxColumn"
        Me.FolioDataGridViewTextBoxColumn.Visible = False
        '
        'ReconciledDataGridViewTextBoxColumn
        '
        Me.ReconciledDataGridViewTextBoxColumn.DataPropertyName = "Reconciled"
        Me.ReconciledDataGridViewTextBoxColumn.HeaderText = "Reconciled"
        Me.ReconciledDataGridViewTextBoxColumn.Name = "ReconciledDataGridViewTextBoxColumn"
        Me.ReconciledDataGridViewTextBoxColumn.Visible = False
        '
        'VATDataGridViewTextBoxColumn
        '
        Me.VATDataGridViewTextBoxColumn.DataPropertyName = "VAT"
        Me.VATDataGridViewTextBoxColumn.HeaderText = "VAT"
        Me.VATDataGridViewTextBoxColumn.Name = "VATDataGridViewTextBoxColumn"
        Me.VATDataGridViewTextBoxColumn.Visible = False
        '
        'BalanceDataGridViewTextBoxColumn
        '
        Me.BalanceDataGridViewTextBoxColumn.DataPropertyName = "Balance"
        Me.BalanceDataGridViewTextBoxColumn.HeaderText = "Balance"
        Me.BalanceDataGridViewTextBoxColumn.Name = "BalanceDataGridViewTextBoxColumn"
        Me.BalanceDataGridViewTextBoxColumn.Visible = False
        '
        'DebitCreditDataGridViewTextBoxColumn
        '
        Me.DebitCreditDataGridViewTextBoxColumn.DataPropertyName = "DebitCredit"
        Me.DebitCreditDataGridViewTextBoxColumn.HeaderText = "DebitCredit"
        Me.DebitCreditDataGridViewTextBoxColumn.Name = "DebitCreditDataGridViewTextBoxColumn"
        Me.DebitCreditDataGridViewTextBoxColumn.Visible = False
        '
        'TimeKeyDataGridViewTextBoxColumn
        '
        Me.TimeKeyDataGridViewTextBoxColumn.DataPropertyName = "TimeKey"
        Me.TimeKeyDataGridViewTextBoxColumn.HeaderText = "TimeKey"
        Me.TimeKeyDataGridViewTextBoxColumn.Name = "TimeKeyDataGridViewTextBoxColumn"
        Me.TimeKeyDataGridViewTextBoxColumn.Visible = False
        '
        'AccountNoDataGridViewTextBoxColumn
        '
        Me.AccountNoDataGridViewTextBoxColumn.DataPropertyName = "AccountNo"
        Me.AccountNoDataGridViewTextBoxColumn.HeaderText = "AccountNo"
        Me.AccountNoDataGridViewTextBoxColumn.Name = "AccountNoDataGridViewTextBoxColumn"
        '
        'TransferDataGridViewTextBoxColumn
        '
        Me.TransferDataGridViewTextBoxColumn.DataPropertyName = "Transfer"
        Me.TransferDataGridViewTextBoxColumn.HeaderText = "Transfer"
        Me.TransferDataGridViewTextBoxColumn.Name = "TransferDataGridViewTextBoxColumn"
        '
        'TransferIDDataGridViewTextBoxColumn
        '
        Me.TransferIDDataGridViewTextBoxColumn.DataPropertyName = "TransferID"
        Me.TransferIDDataGridViewTextBoxColumn.HeaderText = "TransferID"
        Me.TransferIDDataGridViewTextBoxColumn.Name = "TransferIDDataGridViewTextBoxColumn"
        '
        'PaymentDataGridViewTextBoxColumn
        '
        Me.PaymentDataGridViewTextBoxColumn.DataPropertyName = "Payment"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.PaymentDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle23
        Me.PaymentDataGridViewTextBoxColumn.HeaderText = "Payment"
        Me.PaymentDataGridViewTextBoxColumn.Name = "PaymentDataGridViewTextBoxColumn"
        '
        'ReceiptDataGridViewTextBoxColumn
        '
        Me.ReceiptDataGridViewTextBoxColumn.DataPropertyName = "Receipt"
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle24.Format = "N2"
        DataGridViewCellStyle24.NullValue = Nothing
        Me.ReceiptDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle24
        Me.ReceiptDataGridViewTextBoxColumn.HeaderText = "Receipt"
        Me.ReceiptDataGridViewTextBoxColumn.Name = "ReceiptDataGridViewTextBoxColumn"
        '
        'TransQueryATableAdapterTest
        '
        Me.TransQueryATableAdapterTest.ClearBeforeFill = True
        '
        'TransQueryBTableAdapterTest
        '
        Me.TransQueryBTableAdapterTest.ClearBeforeFill = True
        '
        'DataGridQueriesB
        '
        Me.DataGridQueriesB.AllowUserToAddRows = False
        Me.DataGridQueriesB.AllowUserToDeleteRows = False
        Me.DataGridQueriesB.AllowUserToResizeRows = False
        Me.DataGridQueriesB.AutoGenerateColumns = False
        Me.DataGridQueriesB.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridQueriesB.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridQueriesB.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle26
        Me.DataGridQueriesB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridQueriesB.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DateDataGridViewTextBoxColumn1, Me.ReferenceDataGridViewTextBoxColumn1, Me.CustomerDataGridViewTextBoxColumn3, Me.DetailsDataGridViewTextBoxColumn2, Me.AmountDataGridViewTextBoxColumn1, Me.DebitCreditDataGridViewTextBoxColumn1, Me.VATDataGridViewTextBoxColumn1, Me.AnalysisDataGridViewTextBoxColumn1, Me.AccountDataGridViewTextBoxColumn1, Me.GlCodeDataGridViewTextBoxColumn1, Me.FolioDataGridViewTextBoxColumn1, Me.ReconciledDataGridViewTextBoxColumn1, Me.BalanceDataGridViewTextBoxColumn1, Me.TimeKeyDataGridViewTextBoxColumn1, Me.AccountNoDataGridViewTextBoxColumn1, Me.TransferDataGridViewTextBoxColumn2, Me.TransferIDDataGridViewTextBoxColumn2, Me.PaymentDataGridViewTextBoxColumn2, Me.ReceiptDataGridViewTextBoxColumn2})
        Me.DataGridQueriesB.DataSource = Me.TransQueryBBindingSourceLive
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle30.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridQueriesB.DefaultCellStyle = DataGridViewCellStyle30
        Me.DataGridQueriesB.Location = New System.Drawing.Point(12, 43)
        Me.DataGridQueriesB.MultiSelect = False
        Me.DataGridQueriesB.Name = "DataGridQueriesB"
        Me.DataGridQueriesB.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridQueriesB.Size = New System.Drawing.Size(786, 260)
        Me.DataGridQueriesB.TabIndex = 23
        '
        'DateDataGridViewTextBoxColumn1
        '
        Me.DateDataGridViewTextBoxColumn1.DataPropertyName = "Date"
        Me.DateDataGridViewTextBoxColumn1.HeaderText = "Date"
        Me.DateDataGridViewTextBoxColumn1.Name = "DateDataGridViewTextBoxColumn1"
        '
        'ReferenceDataGridViewTextBoxColumn1
        '
        Me.ReferenceDataGridViewTextBoxColumn1.DataPropertyName = "Reference"
        Me.ReferenceDataGridViewTextBoxColumn1.HeaderText = "Reference"
        Me.ReferenceDataGridViewTextBoxColumn1.Name = "ReferenceDataGridViewTextBoxColumn1"
        '
        'CustomerDataGridViewTextBoxColumn3
        '
        Me.CustomerDataGridViewTextBoxColumn3.DataPropertyName = "Customer"
        Me.CustomerDataGridViewTextBoxColumn3.HeaderText = "Customer"
        Me.CustomerDataGridViewTextBoxColumn3.Name = "CustomerDataGridViewTextBoxColumn3"
        '
        'DetailsDataGridViewTextBoxColumn2
        '
        Me.DetailsDataGridViewTextBoxColumn2.DataPropertyName = "Details"
        Me.DetailsDataGridViewTextBoxColumn2.HeaderText = "Details"
        Me.DetailsDataGridViewTextBoxColumn2.Name = "DetailsDataGridViewTextBoxColumn2"
        '
        'AmountDataGridViewTextBoxColumn1
        '
        Me.AmountDataGridViewTextBoxColumn1.DataPropertyName = "Amount"
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle27.Format = "N2"
        DataGridViewCellStyle27.NullValue = Nothing
        Me.AmountDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle27
        Me.AmountDataGridViewTextBoxColumn1.HeaderText = "Amount"
        Me.AmountDataGridViewTextBoxColumn1.Name = "AmountDataGridViewTextBoxColumn1"
        '
        'DebitCreditDataGridViewTextBoxColumn1
        '
        Me.DebitCreditDataGridViewTextBoxColumn1.DataPropertyName = "DebitCredit"
        Me.DebitCreditDataGridViewTextBoxColumn1.HeaderText = "DebitCredit"
        Me.DebitCreditDataGridViewTextBoxColumn1.Name = "DebitCreditDataGridViewTextBoxColumn1"
        Me.DebitCreditDataGridViewTextBoxColumn1.Visible = False
        '
        'VATDataGridViewTextBoxColumn1
        '
        Me.VATDataGridViewTextBoxColumn1.DataPropertyName = "VAT"
        Me.VATDataGridViewTextBoxColumn1.HeaderText = "VAT"
        Me.VATDataGridViewTextBoxColumn1.Name = "VATDataGridViewTextBoxColumn1"
        Me.VATDataGridViewTextBoxColumn1.Visible = False
        '
        'AnalysisDataGridViewTextBoxColumn1
        '
        Me.AnalysisDataGridViewTextBoxColumn1.DataPropertyName = "Analysis"
        Me.AnalysisDataGridViewTextBoxColumn1.HeaderText = "Analysis"
        Me.AnalysisDataGridViewTextBoxColumn1.Name = "AnalysisDataGridViewTextBoxColumn1"
        '
        'AccountDataGridViewTextBoxColumn1
        '
        Me.AccountDataGridViewTextBoxColumn1.DataPropertyName = "Account"
        Me.AccountDataGridViewTextBoxColumn1.HeaderText = "Account"
        Me.AccountDataGridViewTextBoxColumn1.Name = "AccountDataGridViewTextBoxColumn1"
        Me.AccountDataGridViewTextBoxColumn1.Visible = False
        '
        'GlCodeDataGridViewTextBoxColumn1
        '
        Me.GlCodeDataGridViewTextBoxColumn1.DataPropertyName = "GlCode"
        Me.GlCodeDataGridViewTextBoxColumn1.HeaderText = "GlCode"
        Me.GlCodeDataGridViewTextBoxColumn1.Name = "GlCodeDataGridViewTextBoxColumn1"
        '
        'FolioDataGridViewTextBoxColumn1
        '
        Me.FolioDataGridViewTextBoxColumn1.DataPropertyName = "Folio"
        Me.FolioDataGridViewTextBoxColumn1.HeaderText = "Folio"
        Me.FolioDataGridViewTextBoxColumn1.Name = "FolioDataGridViewTextBoxColumn1"
        Me.FolioDataGridViewTextBoxColumn1.Visible = False
        '
        'ReconciledDataGridViewTextBoxColumn1
        '
        Me.ReconciledDataGridViewTextBoxColumn1.DataPropertyName = "Reconciled"
        Me.ReconciledDataGridViewTextBoxColumn1.HeaderText = "Reconciled"
        Me.ReconciledDataGridViewTextBoxColumn1.Name = "ReconciledDataGridViewTextBoxColumn1"
        Me.ReconciledDataGridViewTextBoxColumn1.Visible = False
        '
        'BalanceDataGridViewTextBoxColumn1
        '
        Me.BalanceDataGridViewTextBoxColumn1.DataPropertyName = "Balance"
        Me.BalanceDataGridViewTextBoxColumn1.HeaderText = "Balance"
        Me.BalanceDataGridViewTextBoxColumn1.Name = "BalanceDataGridViewTextBoxColumn1"
        Me.BalanceDataGridViewTextBoxColumn1.Visible = False
        '
        'TimeKeyDataGridViewTextBoxColumn1
        '
        Me.TimeKeyDataGridViewTextBoxColumn1.DataPropertyName = "TimeKey"
        Me.TimeKeyDataGridViewTextBoxColumn1.HeaderText = "TimeKey"
        Me.TimeKeyDataGridViewTextBoxColumn1.Name = "TimeKeyDataGridViewTextBoxColumn1"
        Me.TimeKeyDataGridViewTextBoxColumn1.Visible = False
        '
        'AccountNoDataGridViewTextBoxColumn1
        '
        Me.AccountNoDataGridViewTextBoxColumn1.DataPropertyName = "AccountNo"
        Me.AccountNoDataGridViewTextBoxColumn1.HeaderText = "AccountNo"
        Me.AccountNoDataGridViewTextBoxColumn1.Name = "AccountNoDataGridViewTextBoxColumn1"
        '
        'TransferDataGridViewTextBoxColumn2
        '
        Me.TransferDataGridViewTextBoxColumn2.DataPropertyName = "Transfer"
        Me.TransferDataGridViewTextBoxColumn2.HeaderText = "Transfer"
        Me.TransferDataGridViewTextBoxColumn2.Name = "TransferDataGridViewTextBoxColumn2"
        '
        'TransferIDDataGridViewTextBoxColumn2
        '
        Me.TransferIDDataGridViewTextBoxColumn2.DataPropertyName = "TransferID"
        Me.TransferIDDataGridViewTextBoxColumn2.HeaderText = "TransferID"
        Me.TransferIDDataGridViewTextBoxColumn2.Name = "TransferIDDataGridViewTextBoxColumn2"
        '
        'PaymentDataGridViewTextBoxColumn2
        '
        Me.PaymentDataGridViewTextBoxColumn2.DataPropertyName = "Payment"
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle28.Format = "N2"
        DataGridViewCellStyle28.NullValue = Nothing
        Me.PaymentDataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle28
        Me.PaymentDataGridViewTextBoxColumn2.HeaderText = "Payment"
        Me.PaymentDataGridViewTextBoxColumn2.Name = "PaymentDataGridViewTextBoxColumn2"
        '
        'ReceiptDataGridViewTextBoxColumn2
        '
        Me.ReceiptDataGridViewTextBoxColumn2.DataPropertyName = "Receipt"
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle29.Format = "N2"
        DataGridViewCellStyle29.NullValue = Nothing
        Me.ReceiptDataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle29
        Me.ReceiptDataGridViewTextBoxColumn2.HeaderText = "Receipt"
        Me.ReceiptDataGridViewTextBoxColumn2.Name = "ReceiptDataGridViewTextBoxColumn2"
        '
        'PbstransTableAdapterArc
        '
        Me.PbstransTableAdapterArc.ClearBeforeFill = True
        '
        'AnalysisTableAdapterArc
        '
        Me.AnalysisTableAdapterArc.ClearBeforeFill = True
        '
        'GLCodeTableAdapterArc
        '
        Me.GLCodeTableAdapterArc.ClearBeforeFill = True
        '
        'CustomersTableAdapterArc
        '
        Me.CustomersTableAdapterArc.ClearBeforeFill = True
        '
        'TransQueryATableAdapterLive
        '
        Me.TransQueryATableAdapterLive.ClearBeforeFill = True
        '
        'TransQueryBTableAdapterLive
        '
        Me.TransQueryBTableAdapterLive.ClearBeforeFill = True
        '
        'VpbsArchiveDataSet
        '
        Me.VpbsArchiveDataSet.DataSetName = "VpbsArchiveDataSet"
        Me.VpbsArchiveDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TransQueryBBindingSourceArc
        '
        Me.TransQueryBBindingSourceArc.DataMember = "TransQueryB"
        Me.TransQueryBBindingSourceArc.DataSource = Me.VpbsArchiveDataSet3
        Me.TransQueryBBindingSourceArc.Sort = "Date"
        '
        'VpbsArchiveDataSet3
        '
        Me.VpbsArchiveDataSet3.DataSetName = "VpbsArchiveDataSet3"
        Me.VpbsArchiveDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TransQueryBTableAdapterArc
        '
        Me.TransQueryBTableAdapterArc.ClearBeforeFill = True
        '
        'TransQueryATableAdapterArc
        '
        Me.TransQueryATableAdapterArc.ClearBeforeFill = True
        '
        'frmQueries
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ClientSize = New System.Drawing.Size(810, 597)
        Me.ControlBox = False
        Me.Controls.Add(Me.AxCrystalReport1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.lblAccountHeader)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DataGridQueries)
        Me.Controls.Add(Me.DataGridQueriesB)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmQueries"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "VPBS - Queries"
        CType(Me.VpbsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VpbsTestDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbstransBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox20.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        CType(Me.CustomersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        CType(Me.AnalysisBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox16.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox17.ResumeLayout(False)
        Me.GroupBox17.PerformLayout()
        CType(Me.GLCodeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox18.PerformLayout()
        Me.GroupBox19.ResumeLayout(False)
        Me.GroupBox19.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.GroupBox21.ResumeLayout(False)
        Me.GroupBox21.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.GroupBox22.ResumeLayout(False)
        Me.GroupBox22.PerformLayout()
        CType(Me.TransQueryBBindingSourceLive, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VPBSDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxCrystalReport1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridQueries, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridQueriesB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VpbsArchiveDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TransQueryBBindingSourceArc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VpbsArchiveDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents VpbsDataSet As VPBS13.VPBSDataSet
    Friend WithEvents VpbsTestDataSet As VPBS13.VPBSTestDataSet
    Friend WithEvents PbstransBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PbstransTableAdapterTest As VPBS13.VPBSTestDataSetTableAdapters.pbstransTableAdapter
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CmdReport As System.Windows.Forms.Button
    Friend WithEvents CmdClose As System.Windows.Forms.Button
    Friend WithEvents CmdCancel As System.Windows.Forms.Button
    Friend WithEvents CmdOk As System.Windows.Forms.Button
    Friend WithEvents CmdNew As System.Windows.Forms.Button
    Friend WithEvents CmdSave As System.Windows.Forms.Button
    Friend WithEvents CmdFilter As System.Windows.Forms.Button
    Friend WithEvents CmdOkProj As System.Windows.Forms.Button
    Friend WithEvents CmdOkFind As System.Windows.Forms.Button
    Friend WithEvents CmdOkReport As System.Windows.Forms.Button
    Friend WithEvents lblAccountHeader As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoRef5 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoRef3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoRef4 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoRef2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoRef1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoRef0 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker0 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoDate5 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoDate3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoDate4 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoDate2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoDate1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoDate0 As System.Windows.Forms.RadioButton
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents txtRef1 As System.Windows.Forms.TextBox
    Friend WithEvents txtRef0 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents cboCust1 As System.Windows.Forms.ComboBox
    Friend WithEvents cboCust0 As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoCust5 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoCust3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoCust4 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoCust2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoCust1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoCust0 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents cboAnalysis1 As System.Windows.Forms.ComboBox
    Friend WithEvents cboAnalysis0 As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox15 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoAnal5 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAnal3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAnal4 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox16 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoAnal2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAnal1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAnal0 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox17 As System.Windows.Forms.GroupBox
    Friend WithEvents cboGLCode1 As System.Windows.Forms.ComboBox
    Friend WithEvents cboGLCode0 As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBox18 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoGL5 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoGL3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoGL4 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox19 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoGL2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoGL1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoGL0 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAmount1 As System.Windows.Forms.TextBox
    Friend WithEvents txtAmount0 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoAmt5 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAmt3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAmt4 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoAmt2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAmt1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAmt0 As System.Windows.Forms.RadioButton
    Friend WithEvents CustomersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CustomersTableAdapterTest As VPBS13.VPBSTestDataSetTableAdapters.CustomersTableAdapter
    Friend WithEvents GLCodeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GLCodeTableAdapterTest As VPBS13.VPBSTestDataSetTableAdapters.GLCodeTableAdapter
    Friend WithEvents AnalysisBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AnalysisTableAdapterTest As VPBS13.VPBSTestDataSetTableAdapters.AnalysisTableAdapter
    Friend WithEvents GroupBox20 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoOptSelect1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoOptSelect0 As System.Windows.Forms.RadioButton
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox21 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cboReportGroup0 As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents GroupBox22 As System.Windows.Forms.GroupBox
    Friend WithEvents cboGroup4 As System.Windows.Forms.ComboBox
    Friend WithEvents cboGroup3 As System.Windows.Forms.ComboBox
    Friend WithEvents cboGroup2 As System.Windows.Forms.ComboBox
    Friend WithEvents cboGroup1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cmdOkRpt As System.Windows.Forms.Button
    Friend WithEvents txtGroup3 As System.Windows.Forms.TextBox
    Friend WithEvents txtGroup2 As System.Windows.Forms.TextBox
    Friend WithEvents txtGroup1 As System.Windows.Forms.TextBox
    Friend WithEvents txtReportGroup0 As System.Windows.Forms.TextBox
    Friend WithEvents txtGroup4 As System.Windows.Forms.TextBox
    Friend WithEvents PbstransTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.pbstransTableAdapter
    Friend WithEvents AnalysisTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.AnalysisTableAdapter
    Friend WithEvents GLCodeTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.GLCodeTableAdapter
    Friend WithEvents CustomersTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.CustomersTableAdapter
    Friend WithEvents TransQueryBBindingSourceLive As System.Windows.Forms.BindingSource
    Friend WithEvents AxCrystalReport1 As AxCrystal.AxCrystalReport
    Friend WithEvents DataGridQueries As System.Windows.Forms.DataGridView
    Friend WithEvents TransQueryATableAdapterTest As VPBS13.VPBSTestDataSetTableAdapters.TransQueryATableAdapter
    Friend WithEvents TransQueryBTableAdapterTest As VPBS13.VPBSTestDataSetTableAdapters.TransQueryBTableAdapter
    Friend WithEvents DataGridQueriesB As System.Windows.Forms.DataGridView
    Friend WithEvents CustomerDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DetailsDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TransferDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TransferidDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PaymentDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReceiptDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PbstransTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.pbstransTableAdapter
    Friend WithEvents AnalysisTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.AnalysisTableAdapter
    Friend WithEvents GLCodeTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.GLCodeTableAdapter
    Friend WithEvents CustomersTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.CustomersTableAdapter
    Friend WithEvents CustomerDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TransQueryATableAdapterLive As VPBS13.VPBSDataSetTableAdapters.TransQueryATableAdapter
    Friend WithEvents VPBSDataSet1 As VPBS13.VPBSDataSet1
    Friend WithEvents TransQueryBTableAdapterLive As VPBS13.VPBSDataSet1TableAdapters.TransQueryBTableAdapter
    Friend WithEvents VpbsArchiveDataSet As VPBS13.VpbsArchiveDataSet
    Friend WithEvents TransQueryBBindingSourceArc As System.Windows.Forms.BindingSource
    Friend WithEvents VpbsArchiveDataSet3 As VPBS13.VpbsArchiveDataSet3
    Friend WithEvents TransQueryBTableAdapterArc As VPBS13.VpbsArchiveDataSet3TableAdapters.TransQueryBTableAdapter
    Friend WithEvents TransQueryATableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.TransQueryATableAdapter
    Friend WithEvents DateDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReferenceDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustomerDataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DetailsDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AmountDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DebitCreditDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VATDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AnalysisDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccountDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GlCodeDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FolioDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReconciledDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BalanceDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TimeKeyDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccountNoDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TransferDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TransferIDDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PaymentDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReceiptDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReferenceDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustomerDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DetailsDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AmountDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AnalysisDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccountDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GlcodeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FolioDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReconciledDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VATDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BalanceDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DebitCreditDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TimeKeyDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccountNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TransferDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TransferIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PaymentDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReceiptDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
