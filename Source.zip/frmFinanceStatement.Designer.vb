﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmFinanceStatement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFinanceStatement))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.grpBankAccounts = New System.Windows.Forms.GroupBox()
        Me.txtCcyX = New System.Windows.Forms.TextBox()
        Me.txtRateX = New System.Windows.Forms.TextBox()
        Me.txtZeropcEndX = New System.Windows.Forms.TextBox()
        Me.txtDueDateX = New System.Windows.Forms.TextBox()
        Me.txtMinPymtX = New System.Windows.Forms.TextBox()
        Me.txtBalanceX = New System.Windows.Forms.TextBox()
        Me.txtNameX = New System.Windows.Forms.TextBox()
        Me.txtAcctNoX = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.txtCcy0 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTotal0 = New System.Windows.Forms.TextBox()
        Me.txtBalance8 = New System.Windows.Forms.TextBox()
        Me.txtName8 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo8 = New System.Windows.Forms.TextBox()
        Me.txtBalance7 = New System.Windows.Forms.TextBox()
        Me.txtName7 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo7 = New System.Windows.Forms.TextBox()
        Me.txtBalance6 = New System.Windows.Forms.TextBox()
        Me.txtName6 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo6 = New System.Windows.Forms.TextBox()
        Me.txtBalance5 = New System.Windows.Forms.TextBox()
        Me.txtName5 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo5 = New System.Windows.Forms.TextBox()
        Me.txtBalance4 = New System.Windows.Forms.TextBox()
        Me.txtName4 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo4 = New System.Windows.Forms.TextBox()
        Me.txtBalance3 = New System.Windows.Forms.TextBox()
        Me.txtName3 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo3 = New System.Windows.Forms.TextBox()
        Me.txtBalance2 = New System.Windows.Forms.TextBox()
        Me.txtName2 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo2 = New System.Windows.Forms.TextBox()
        Me.txtBalance1 = New System.Windows.Forms.TextBox()
        Me.txtName1 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.grpCreditCards = New System.Windows.Forms.GroupBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.TextBox62 = New System.Windows.Forms.TextBox()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.TextBox65 = New System.Windows.Forms.TextBox()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        Me.TextBox67 = New System.Windows.Forms.TextBox()
        Me.TextBox68 = New System.Windows.Forms.TextBox()
        Me.TextBox69 = New System.Windows.Forms.TextBox()
        Me.TextBox70 = New System.Windows.Forms.TextBox()
        Me.TextBox71 = New System.Windows.Forms.TextBox()
        Me.TextBox72 = New System.Windows.Forms.TextBox()
        Me.TextBox73 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.txtCcy1 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtTotal2 = New System.Windows.Forms.TextBox()
        Me.txtTotal1 = New System.Windows.Forms.TextBox()
        Me.txtRate16 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd16 = New System.Windows.Forms.TextBox()
        Me.txtDueDate16 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt16 = New System.Windows.Forms.TextBox()
        Me.txtBalance16 = New System.Windows.Forms.TextBox()
        Me.txtName16 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo16 = New System.Windows.Forms.TextBox()
        Me.txtRate15 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd15 = New System.Windows.Forms.TextBox()
        Me.txtDueDate15 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt15 = New System.Windows.Forms.TextBox()
        Me.txtBalance15 = New System.Windows.Forms.TextBox()
        Me.txtName15 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo15 = New System.Windows.Forms.TextBox()
        Me.txtRate14 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd14 = New System.Windows.Forms.TextBox()
        Me.txtDueDate14 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt14 = New System.Windows.Forms.TextBox()
        Me.txtBalance14 = New System.Windows.Forms.TextBox()
        Me.txtName14 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo14 = New System.Windows.Forms.TextBox()
        Me.txtRate13 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd13 = New System.Windows.Forms.TextBox()
        Me.txtDueDate13 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt13 = New System.Windows.Forms.TextBox()
        Me.txtBalance13 = New System.Windows.Forms.TextBox()
        Me.txtName13 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo13 = New System.Windows.Forms.TextBox()
        Me.txtRate12 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd12 = New System.Windows.Forms.TextBox()
        Me.txtDueDate12 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt12 = New System.Windows.Forms.TextBox()
        Me.txtBalance12 = New System.Windows.Forms.TextBox()
        Me.txtName12 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo12 = New System.Windows.Forms.TextBox()
        Me.txtRate11 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd11 = New System.Windows.Forms.TextBox()
        Me.txtDueDate11 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt11 = New System.Windows.Forms.TextBox()
        Me.txtBalance11 = New System.Windows.Forms.TextBox()
        Me.txtName11 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo11 = New System.Windows.Forms.TextBox()
        Me.txtRate10 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd10 = New System.Windows.Forms.TextBox()
        Me.txtDueDate10 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt10 = New System.Windows.Forms.TextBox()
        Me.txtBalance10 = New System.Windows.Forms.TextBox()
        Me.txtName10 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo10 = New System.Windows.Forms.TextBox()
        Me.txtRate9 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd9 = New System.Windows.Forms.TextBox()
        Me.txtDueDate9 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt9 = New System.Windows.Forms.TextBox()
        Me.txtBalance9 = New System.Windows.Forms.TextBox()
        Me.txtName9 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo9 = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.grpToPayToCome = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtDueDate22 = New System.Windows.Forms.TextBox()
        Me.txtBalance22 = New System.Windows.Forms.TextBox()
        Me.txtName22 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo22 = New System.Windows.Forms.TextBox()
        Me.txtDueDate21 = New System.Windows.Forms.TextBox()
        Me.txtBalance21 = New System.Windows.Forms.TextBox()
        Me.txtName21 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo21 = New System.Windows.Forms.TextBox()
        Me.txtDueDate20 = New System.Windows.Forms.TextBox()
        Me.txtBalance20 = New System.Windows.Forms.TextBox()
        Me.txtName20 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo20 = New System.Windows.Forms.TextBox()
        Me.txtDueDate19 = New System.Windows.Forms.TextBox()
        Me.txtBalance19 = New System.Windows.Forms.TextBox()
        Me.txtName19 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo19 = New System.Windows.Forms.TextBox()
        Me.txtDueDate18 = New System.Windows.Forms.TextBox()
        Me.txtBalance18 = New System.Windows.Forms.TextBox()
        Me.txtName18 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo18 = New System.Windows.Forms.TextBox()
        Me.txtDueDate17 = New System.Windows.Forms.TextBox()
        Me.txtBalance17 = New System.Windows.Forms.TextBox()
        Me.txtName17 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo17 = New System.Windows.Forms.TextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.grpAquavista = New System.Windows.Forms.GroupBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtDueDate37 = New System.Windows.Forms.TextBox()
        Me.txtBalance37 = New System.Windows.Forms.TextBox()
        Me.txtName37 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo37 = New System.Windows.Forms.TextBox()
        Me.txtDueDate36 = New System.Windows.Forms.TextBox()
        Me.txtBalance36 = New System.Windows.Forms.TextBox()
        Me.txtName36 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo36 = New System.Windows.Forms.TextBox()
        Me.txtDueDate35 = New System.Windows.Forms.TextBox()
        Me.txtBalance35 = New System.Windows.Forms.TextBox()
        Me.txtName35 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo35 = New System.Windows.Forms.TextBox()
        Me.txtDueDate34 = New System.Windows.Forms.TextBox()
        Me.txtBalance34 = New System.Windows.Forms.TextBox()
        Me.txtName34 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo34 = New System.Windows.Forms.TextBox()
        Me.txtDueDate33 = New System.Windows.Forms.TextBox()
        Me.txtBalance33 = New System.Windows.Forms.TextBox()
        Me.txtName33 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo33 = New System.Windows.Forms.TextBox()
        Me.txtDueDate32 = New System.Windows.Forms.TextBox()
        Me.txtBalance32 = New System.Windows.Forms.TextBox()
        Me.txtName32 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo32 = New System.Windows.Forms.TextBox()
        Me.txtCcy4 = New System.Windows.Forms.TextBox()
        Me.txtBalance31 = New System.Windows.Forms.TextBox()
        Me.txtName31 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo31 = New System.Windows.Forms.TextBox()
        Me.txtCcy3 = New System.Windows.Forms.TextBox()
        Me.txtBalance30 = New System.Windows.Forms.TextBox()
        Me.txtName30 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo30 = New System.Windows.Forms.TextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.grpMortgages = New System.Windows.Forms.GroupBox()
        Me.txtRate43 = New System.Windows.Forms.TextBox()
        Me.txtRate42 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd43 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd42 = New System.Windows.Forms.TextBox()
        Me.txtDueDate43 = New System.Windows.Forms.TextBox()
        Me.txtDueDate42 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt43 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt42 = New System.Windows.Forms.TextBox()
        Me.txtBalance43 = New System.Windows.Forms.TextBox()
        Me.txtBalance42 = New System.Windows.Forms.TextBox()
        Me.txtName43 = New System.Windows.Forms.TextBox()
        Me.txtName42 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo43 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo42 = New System.Windows.Forms.TextBox()
        Me.txtRate41 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd41 = New System.Windows.Forms.TextBox()
        Me.txtDueDate41 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt41 = New System.Windows.Forms.TextBox()
        Me.txtBalance41 = New System.Windows.Forms.TextBox()
        Me.txtName41 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo41 = New System.Windows.Forms.TextBox()
        Me.txtRate40 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd40 = New System.Windows.Forms.TextBox()
        Me.txtDueDate40 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt40 = New System.Windows.Forms.TextBox()
        Me.txtBalance40 = New System.Windows.Forms.TextBox()
        Me.txtName40 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo40 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTotal4 = New System.Windows.Forms.TextBox()
        Me.txtTotal3 = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtRate39 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd39 = New System.Windows.Forms.TextBox()
        Me.txtDueDate39 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt39 = New System.Windows.Forms.TextBox()
        Me.txtRate38 = New System.Windows.Forms.TextBox()
        Me.txtZeropcEnd38 = New System.Windows.Forms.TextBox()
        Me.txtDueDate38 = New System.Windows.Forms.TextBox()
        Me.txtMinPymt38 = New System.Windows.Forms.TextBox()
        Me.txtCcy5 = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtBalance39 = New System.Windows.Forms.TextBox()
        Me.txtName39 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo39 = New System.Windows.Forms.TextBox()
        Me.txtBalance38 = New System.Windows.Forms.TextBox()
        Me.txtName38 = New System.Windows.Forms.TextBox()
        Me.txtAcctNo38 = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblDeleteRow = New System.Windows.Forms.Label()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdOk = New System.Windows.Forms.Button()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.cmdReport = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.lblAccountHeader = New System.Windows.Forms.Label()
        Me.AxCrystalReport2 = New AxCrystal.AxCrystalReport()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.grpBankAccounts.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.grpCreditCards.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.grpToPayToCome.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.grpAquavista.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.grpMortgages.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.AxCrystalReport2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Location = New System.Drawing.Point(11, 39)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(716, 474)
        Me.TabControl1.TabIndex = 10
        '
        'TabPage1
        '
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage1.Controls.Add(Me.grpBankAccounts)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(708, 445)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Harebell 1          "
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'grpBankAccounts
        '
        Me.grpBankAccounts.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.grpBankAccounts.Controls.Add(Me.txtCcyX)
        Me.grpBankAccounts.Controls.Add(Me.txtRateX)
        Me.grpBankAccounts.Controls.Add(Me.txtZeropcEndX)
        Me.grpBankAccounts.Controls.Add(Me.txtDueDateX)
        Me.grpBankAccounts.Controls.Add(Me.txtMinPymtX)
        Me.grpBankAccounts.Controls.Add(Me.txtBalanceX)
        Me.grpBankAccounts.Controls.Add(Me.txtNameX)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNoX)
        Me.grpBankAccounts.Controls.Add(Me.TextBox28)
        Me.grpBankAccounts.Controls.Add(Me.TextBox27)
        Me.grpBankAccounts.Controls.Add(Me.TextBox26)
        Me.grpBankAccounts.Controls.Add(Me.TextBox21)
        Me.grpBankAccounts.Controls.Add(Me.TextBox20)
        Me.grpBankAccounts.Controls.Add(Me.TextBox19)
        Me.grpBankAccounts.Controls.Add(Me.TextBox14)
        Me.grpBankAccounts.Controls.Add(Me.TextBox13)
        Me.grpBankAccounts.Controls.Add(Me.TextBox12)
        Me.grpBankAccounts.Controls.Add(Me.TextBox3)
        Me.grpBankAccounts.Controls.Add(Me.TextBox2)
        Me.grpBankAccounts.Controls.Add(Me.TextBox1)
        Me.grpBankAccounts.Controls.Add(Me.txtCcy0)
        Me.grpBankAccounts.Controls.Add(Me.Label7)
        Me.grpBankAccounts.Controls.Add(Me.Label2)
        Me.grpBankAccounts.Controls.Add(Me.Label1)
        Me.grpBankAccounts.Controls.Add(Me.txtTotal0)
        Me.grpBankAccounts.Controls.Add(Me.txtBalance8)
        Me.grpBankAccounts.Controls.Add(Me.txtName8)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNo8)
        Me.grpBankAccounts.Controls.Add(Me.txtBalance7)
        Me.grpBankAccounts.Controls.Add(Me.txtName7)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNo7)
        Me.grpBankAccounts.Controls.Add(Me.txtBalance6)
        Me.grpBankAccounts.Controls.Add(Me.txtName6)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNo6)
        Me.grpBankAccounts.Controls.Add(Me.txtBalance5)
        Me.grpBankAccounts.Controls.Add(Me.txtName5)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNo5)
        Me.grpBankAccounts.Controls.Add(Me.txtBalance4)
        Me.grpBankAccounts.Controls.Add(Me.txtName4)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNo4)
        Me.grpBankAccounts.Controls.Add(Me.txtBalance3)
        Me.grpBankAccounts.Controls.Add(Me.txtName3)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNo3)
        Me.grpBankAccounts.Controls.Add(Me.txtBalance2)
        Me.grpBankAccounts.Controls.Add(Me.txtName2)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNo2)
        Me.grpBankAccounts.Controls.Add(Me.txtBalance1)
        Me.grpBankAccounts.Controls.Add(Me.txtName1)
        Me.grpBankAccounts.Controls.Add(Me.txtAcctNo1)
        Me.grpBankAccounts.Location = New System.Drawing.Point(5, 6)
        Me.grpBankAccounts.Name = "grpBankAccounts"
        Me.grpBankAccounts.Size = New System.Drawing.Size(699, 433)
        Me.grpBankAccounts.TabIndex = 1
        Me.grpBankAccounts.TabStop = False
        '
        'txtCcyX
        '
        Me.txtCcyX.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCcyX.Location = New System.Drawing.Point(207, 16)
        Me.txtCcyX.Name = "txtCcyX"
        Me.txtCcyX.Size = New System.Drawing.Size(62, 22)
        Me.txtCcyX.TabIndex = 113
        Me.txtCcyX.Visible = False
        '
        'txtRateX
        '
        Me.txtRateX.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRateX.Location = New System.Drawing.Point(623, 380)
        Me.txtRateX.Name = "txtRateX"
        Me.txtRateX.Size = New System.Drawing.Size(65, 22)
        Me.txtRateX.TabIndex = 112
        Me.txtRateX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtRateX.Visible = False
        '
        'txtZeropcEndX
        '
        Me.txtZeropcEndX.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEndX.Location = New System.Drawing.Point(538, 380)
        Me.txtZeropcEndX.Name = "txtZeropcEndX"
        Me.txtZeropcEndX.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEndX.TabIndex = 111
        Me.txtZeropcEndX.Visible = False
        '
        'txtDueDateX
        '
        Me.txtDueDateX.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDateX.Location = New System.Drawing.Point(452, 380)
        Me.txtDueDateX.Name = "txtDueDateX"
        Me.txtDueDateX.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDateX.TabIndex = 110
        Me.txtDueDateX.Visible = False
        '
        'txtMinPymtX
        '
        Me.txtMinPymtX.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymtX.Location = New System.Drawing.Point(384, 380)
        Me.txtMinPymtX.Name = "txtMinPymtX"
        Me.txtMinPymtX.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymtX.TabIndex = 109
        Me.txtMinPymtX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtMinPymtX.Visible = False
        '
        'txtBalanceX
        '
        Me.txtBalanceX.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalanceX.Location = New System.Drawing.Point(274, 380)
        Me.txtBalanceX.Name = "txtBalanceX"
        Me.txtBalanceX.Size = New System.Drawing.Size(89, 22)
        Me.txtBalanceX.TabIndex = 86
        Me.txtBalanceX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtBalanceX.Visible = False
        '
        'txtNameX
        '
        Me.txtNameX.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNameX.Location = New System.Drawing.Point(122, 380)
        Me.txtNameX.Name = "txtNameX"
        Me.txtNameX.Size = New System.Drawing.Size(147, 22)
        Me.txtNameX.TabIndex = 85
        Me.txtNameX.Visible = False
        '
        'txtAcctNoX
        '
        Me.txtAcctNoX.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNoX.Location = New System.Drawing.Point(5, 380)
        Me.txtAcctNoX.Name = "txtAcctNoX"
        Me.txtAcctNoX.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNoX.TabIndex = 84
        Me.txtAcctNoX.Visible = False
        '
        'TextBox28
        '
        Me.TextBox28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox28.Location = New System.Drawing.Point(274, 352)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(89, 22)
        Me.TextBox28.TabIndex = 83
        Me.TextBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox28.Visible = False
        '
        'TextBox27
        '
        Me.TextBox27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox27.Location = New System.Drawing.Point(274, 324)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(89, 22)
        Me.TextBox27.TabIndex = 82
        Me.TextBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox27.Visible = False
        '
        'TextBox26
        '
        Me.TextBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox26.Location = New System.Drawing.Point(274, 296)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(89, 22)
        Me.TextBox26.TabIndex = 81
        Me.TextBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox26.Visible = False
        '
        'TextBox21
        '
        Me.TextBox21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox21.Location = New System.Drawing.Point(274, 268)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(89, 22)
        Me.TextBox21.TabIndex = 80
        Me.TextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox21.Visible = False
        '
        'TextBox20
        '
        Me.TextBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.Location = New System.Drawing.Point(122, 352)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(147, 22)
        Me.TextBox20.TabIndex = 79
        Me.TextBox20.Visible = False
        '
        'TextBox19
        '
        Me.TextBox19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.Location = New System.Drawing.Point(122, 324)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(147, 22)
        Me.TextBox19.TabIndex = 78
        Me.TextBox19.Visible = False
        '
        'TextBox14
        '
        Me.TextBox14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox14.Location = New System.Drawing.Point(122, 296)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(147, 22)
        Me.TextBox14.TabIndex = 77
        Me.TextBox14.Visible = False
        '
        'TextBox13
        '
        Me.TextBox13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox13.Location = New System.Drawing.Point(122, 268)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(147, 22)
        Me.TextBox13.TabIndex = 76
        Me.TextBox13.Visible = False
        '
        'TextBox12
        '
        Me.TextBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(5, 352)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(112, 22)
        Me.TextBox12.TabIndex = 75
        Me.TextBox12.Visible = False
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(5, 324)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(112, 22)
        Me.TextBox3.TabIndex = 74
        Me.TextBox3.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(5, 296)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(112, 22)
        Me.TextBox2.TabIndex = 73
        Me.TextBox2.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(5, 268)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(112, 22)
        Me.TextBox1.TabIndex = 72
        Me.TextBox1.Visible = False
        '
        'txtCcy0
        '
        Me.txtCcy0.Enabled = False
        Me.txtCcy0.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCcy0.Location = New System.Drawing.Point(122, 16)
        Me.txtCcy0.Name = "txtCcy0"
        Me.txtCcy0.Size = New System.Drawing.Size(80, 22)
        Me.txtCcy0.TabIndex = 71
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(3, 400)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(114, 24)
        Me.Label7.TabIndex = 70
        Me.Label7.Text = "Total:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(271, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 24)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "Balance"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(3, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 24)
        Me.Label1.TabIndex = 64
        Me.Label1.Text = "Bank Accounts:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTotal0
        '
        Me.txtTotal0.Enabled = False
        Me.txtTotal0.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal0.Location = New System.Drawing.Point(273, 400)
        Me.txtTotal0.Name = "txtTotal0"
        Me.txtTotal0.Size = New System.Drawing.Size(89, 22)
        Me.txtTotal0.TabIndex = 62
        Me.txtTotal0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance8
        '
        Me.txtBalance8.Enabled = False
        Me.txtBalance8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance8.Location = New System.Drawing.Point(274, 240)
        Me.txtBalance8.Name = "txtBalance8"
        Me.txtBalance8.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance8.TabIndex = 57
        Me.txtBalance8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName8
        '
        Me.txtName8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName8.Location = New System.Drawing.Point(122, 240)
        Me.txtName8.Name = "txtName8"
        Me.txtName8.Size = New System.Drawing.Size(147, 22)
        Me.txtName8.TabIndex = 56
        '
        'txtAcctNo8
        '
        Me.txtAcctNo8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo8.Location = New System.Drawing.Point(5, 240)
        Me.txtAcctNo8.Name = "txtAcctNo8"
        Me.txtAcctNo8.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo8.TabIndex = 55
        '
        'txtBalance7
        '
        Me.txtBalance7.Enabled = False
        Me.txtBalance7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance7.Location = New System.Drawing.Point(274, 212)
        Me.txtBalance7.Name = "txtBalance7"
        Me.txtBalance7.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance7.TabIndex = 50
        Me.txtBalance7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName7
        '
        Me.txtName7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName7.Location = New System.Drawing.Point(122, 212)
        Me.txtName7.Name = "txtName7"
        Me.txtName7.Size = New System.Drawing.Size(147, 22)
        Me.txtName7.TabIndex = 49
        '
        'txtAcctNo7
        '
        Me.txtAcctNo7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo7.Location = New System.Drawing.Point(5, 212)
        Me.txtAcctNo7.Name = "txtAcctNo7"
        Me.txtAcctNo7.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo7.TabIndex = 48
        '
        'txtBalance6
        '
        Me.txtBalance6.Enabled = False
        Me.txtBalance6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance6.Location = New System.Drawing.Point(274, 184)
        Me.txtBalance6.Name = "txtBalance6"
        Me.txtBalance6.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance6.TabIndex = 43
        Me.txtBalance6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName6
        '
        Me.txtName6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName6.Location = New System.Drawing.Point(122, 184)
        Me.txtName6.Name = "txtName6"
        Me.txtName6.Size = New System.Drawing.Size(147, 22)
        Me.txtName6.TabIndex = 42
        '
        'txtAcctNo6
        '
        Me.txtAcctNo6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo6.Location = New System.Drawing.Point(5, 184)
        Me.txtAcctNo6.Name = "txtAcctNo6"
        Me.txtAcctNo6.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo6.TabIndex = 41
        '
        'txtBalance5
        '
        Me.txtBalance5.Enabled = False
        Me.txtBalance5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance5.Location = New System.Drawing.Point(274, 156)
        Me.txtBalance5.Name = "txtBalance5"
        Me.txtBalance5.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance5.TabIndex = 36
        Me.txtBalance5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName5
        '
        Me.txtName5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName5.Location = New System.Drawing.Point(122, 156)
        Me.txtName5.Name = "txtName5"
        Me.txtName5.Size = New System.Drawing.Size(147, 22)
        Me.txtName5.TabIndex = 35
        '
        'txtAcctNo5
        '
        Me.txtAcctNo5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo5.Location = New System.Drawing.Point(5, 156)
        Me.txtAcctNo5.Name = "txtAcctNo5"
        Me.txtAcctNo5.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo5.TabIndex = 34
        '
        'txtBalance4
        '
        Me.txtBalance4.Enabled = False
        Me.txtBalance4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance4.Location = New System.Drawing.Point(274, 128)
        Me.txtBalance4.Name = "txtBalance4"
        Me.txtBalance4.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance4.TabIndex = 29
        Me.txtBalance4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName4
        '
        Me.txtName4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName4.Location = New System.Drawing.Point(122, 128)
        Me.txtName4.Name = "txtName4"
        Me.txtName4.Size = New System.Drawing.Size(147, 22)
        Me.txtName4.TabIndex = 28
        '
        'txtAcctNo4
        '
        Me.txtAcctNo4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo4.Location = New System.Drawing.Point(5, 128)
        Me.txtAcctNo4.Name = "txtAcctNo4"
        Me.txtAcctNo4.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo4.TabIndex = 27
        '
        'txtBalance3
        '
        Me.txtBalance3.Enabled = False
        Me.txtBalance3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance3.Location = New System.Drawing.Point(274, 100)
        Me.txtBalance3.Name = "txtBalance3"
        Me.txtBalance3.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance3.TabIndex = 22
        Me.txtBalance3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName3
        '
        Me.txtName3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName3.Location = New System.Drawing.Point(122, 100)
        Me.txtName3.Name = "txtName3"
        Me.txtName3.Size = New System.Drawing.Size(147, 22)
        Me.txtName3.TabIndex = 21
        '
        'txtAcctNo3
        '
        Me.txtAcctNo3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo3.Location = New System.Drawing.Point(5, 100)
        Me.txtAcctNo3.Name = "txtAcctNo3"
        Me.txtAcctNo3.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo3.TabIndex = 20
        '
        'txtBalance2
        '
        Me.txtBalance2.Enabled = False
        Me.txtBalance2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance2.Location = New System.Drawing.Point(274, 72)
        Me.txtBalance2.Name = "txtBalance2"
        Me.txtBalance2.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance2.TabIndex = 15
        Me.txtBalance2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName2
        '
        Me.txtName2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName2.Location = New System.Drawing.Point(122, 72)
        Me.txtName2.Name = "txtName2"
        Me.txtName2.Size = New System.Drawing.Size(147, 22)
        Me.txtName2.TabIndex = 14
        '
        'txtAcctNo2
        '
        Me.txtAcctNo2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo2.Location = New System.Drawing.Point(5, 72)
        Me.txtAcctNo2.Name = "txtAcctNo2"
        Me.txtAcctNo2.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo2.TabIndex = 13
        '
        'txtBalance1
        '
        Me.txtBalance1.Enabled = False
        Me.txtBalance1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance1.Location = New System.Drawing.Point(274, 44)
        Me.txtBalance1.Name = "txtBalance1"
        Me.txtBalance1.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance1.TabIndex = 2
        Me.txtBalance1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName1
        '
        Me.txtName1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName1.Location = New System.Drawing.Point(122, 44)
        Me.txtName1.Name = "txtName1"
        Me.txtName1.Size = New System.Drawing.Size(147, 22)
        Me.txtName1.TabIndex = 1
        '
        'txtAcctNo1
        '
        Me.txtAcctNo1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo1.Location = New System.Drawing.Point(5, 44)
        Me.txtAcctNo1.Name = "txtAcctNo1"
        Me.txtAcctNo1.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage2.Controls.Add(Me.grpCreditCards)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(708, 445)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Harebell 2          "
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'grpCreditCards
        '
        Me.grpCreditCards.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.grpCreditCards.Controls.Add(Me.TextBox57)
        Me.grpCreditCards.Controls.Add(Me.TextBox59)
        Me.grpCreditCards.Controls.Add(Me.TextBox60)
        Me.grpCreditCards.Controls.Add(Me.TextBox61)
        Me.grpCreditCards.Controls.Add(Me.TextBox62)
        Me.grpCreditCards.Controls.Add(Me.TextBox63)
        Me.grpCreditCards.Controls.Add(Me.TextBox64)
        Me.grpCreditCards.Controls.Add(Me.TextBox65)
        Me.grpCreditCards.Controls.Add(Me.TextBox66)
        Me.grpCreditCards.Controls.Add(Me.TextBox67)
        Me.grpCreditCards.Controls.Add(Me.TextBox68)
        Me.grpCreditCards.Controls.Add(Me.TextBox69)
        Me.grpCreditCards.Controls.Add(Me.TextBox70)
        Me.grpCreditCards.Controls.Add(Me.TextBox71)
        Me.grpCreditCards.Controls.Add(Me.TextBox72)
        Me.grpCreditCards.Controls.Add(Me.TextBox73)
        Me.grpCreditCards.Controls.Add(Me.TextBox33)
        Me.grpCreditCards.Controls.Add(Me.TextBox34)
        Me.grpCreditCards.Controls.Add(Me.TextBox35)
        Me.grpCreditCards.Controls.Add(Me.TextBox40)
        Me.grpCreditCards.Controls.Add(Me.TextBox41)
        Me.grpCreditCards.Controls.Add(Me.TextBox42)
        Me.grpCreditCards.Controls.Add(Me.TextBox47)
        Me.grpCreditCards.Controls.Add(Me.TextBox48)
        Me.grpCreditCards.Controls.Add(Me.TextBox49)
        Me.grpCreditCards.Controls.Add(Me.TextBox54)
        Me.grpCreditCards.Controls.Add(Me.TextBox55)
        Me.grpCreditCards.Controls.Add(Me.TextBox56)
        Me.grpCreditCards.Controls.Add(Me.txtCcy1)
        Me.grpCreditCards.Controls.Add(Me.Label8)
        Me.grpCreditCards.Controls.Add(Me.Label9)
        Me.grpCreditCards.Controls.Add(Me.Label10)
        Me.grpCreditCards.Controls.Add(Me.Label11)
        Me.grpCreditCards.Controls.Add(Me.Label12)
        Me.grpCreditCards.Controls.Add(Me.Label13)
        Me.grpCreditCards.Controls.Add(Me.Label14)
        Me.grpCreditCards.Controls.Add(Me.txtTotal2)
        Me.grpCreditCards.Controls.Add(Me.txtTotal1)
        Me.grpCreditCards.Controls.Add(Me.txtRate16)
        Me.grpCreditCards.Controls.Add(Me.txtZeropcEnd16)
        Me.grpCreditCards.Controls.Add(Me.txtDueDate16)
        Me.grpCreditCards.Controls.Add(Me.txtMinPymt16)
        Me.grpCreditCards.Controls.Add(Me.txtBalance16)
        Me.grpCreditCards.Controls.Add(Me.txtName16)
        Me.grpCreditCards.Controls.Add(Me.txtAcctNo16)
        Me.grpCreditCards.Controls.Add(Me.txtRate15)
        Me.grpCreditCards.Controls.Add(Me.txtZeropcEnd15)
        Me.grpCreditCards.Controls.Add(Me.txtDueDate15)
        Me.grpCreditCards.Controls.Add(Me.txtMinPymt15)
        Me.grpCreditCards.Controls.Add(Me.txtBalance15)
        Me.grpCreditCards.Controls.Add(Me.txtName15)
        Me.grpCreditCards.Controls.Add(Me.txtAcctNo15)
        Me.grpCreditCards.Controls.Add(Me.txtRate14)
        Me.grpCreditCards.Controls.Add(Me.txtZeropcEnd14)
        Me.grpCreditCards.Controls.Add(Me.txtDueDate14)
        Me.grpCreditCards.Controls.Add(Me.txtMinPymt14)
        Me.grpCreditCards.Controls.Add(Me.txtBalance14)
        Me.grpCreditCards.Controls.Add(Me.txtName14)
        Me.grpCreditCards.Controls.Add(Me.txtAcctNo14)
        Me.grpCreditCards.Controls.Add(Me.txtRate13)
        Me.grpCreditCards.Controls.Add(Me.txtZeropcEnd13)
        Me.grpCreditCards.Controls.Add(Me.txtDueDate13)
        Me.grpCreditCards.Controls.Add(Me.txtMinPymt13)
        Me.grpCreditCards.Controls.Add(Me.txtBalance13)
        Me.grpCreditCards.Controls.Add(Me.txtName13)
        Me.grpCreditCards.Controls.Add(Me.txtAcctNo13)
        Me.grpCreditCards.Controls.Add(Me.txtRate12)
        Me.grpCreditCards.Controls.Add(Me.txtZeropcEnd12)
        Me.grpCreditCards.Controls.Add(Me.txtDueDate12)
        Me.grpCreditCards.Controls.Add(Me.txtMinPymt12)
        Me.grpCreditCards.Controls.Add(Me.txtBalance12)
        Me.grpCreditCards.Controls.Add(Me.txtName12)
        Me.grpCreditCards.Controls.Add(Me.txtAcctNo12)
        Me.grpCreditCards.Controls.Add(Me.txtRate11)
        Me.grpCreditCards.Controls.Add(Me.txtZeropcEnd11)
        Me.grpCreditCards.Controls.Add(Me.txtDueDate11)
        Me.grpCreditCards.Controls.Add(Me.txtMinPymt11)
        Me.grpCreditCards.Controls.Add(Me.txtBalance11)
        Me.grpCreditCards.Controls.Add(Me.txtName11)
        Me.grpCreditCards.Controls.Add(Me.txtAcctNo11)
        Me.grpCreditCards.Controls.Add(Me.txtRate10)
        Me.grpCreditCards.Controls.Add(Me.txtZeropcEnd10)
        Me.grpCreditCards.Controls.Add(Me.txtDueDate10)
        Me.grpCreditCards.Controls.Add(Me.txtMinPymt10)
        Me.grpCreditCards.Controls.Add(Me.txtBalance10)
        Me.grpCreditCards.Controls.Add(Me.txtName10)
        Me.grpCreditCards.Controls.Add(Me.txtAcctNo10)
        Me.grpCreditCards.Controls.Add(Me.txtRate9)
        Me.grpCreditCards.Controls.Add(Me.txtZeropcEnd9)
        Me.grpCreditCards.Controls.Add(Me.txtDueDate9)
        Me.grpCreditCards.Controls.Add(Me.txtMinPymt9)
        Me.grpCreditCards.Controls.Add(Me.txtBalance9)
        Me.grpCreditCards.Controls.Add(Me.txtName9)
        Me.grpCreditCards.Controls.Add(Me.txtAcctNo9)
        Me.grpCreditCards.Location = New System.Drawing.Point(5, 6)
        Me.grpCreditCards.Name = "grpCreditCards"
        Me.grpCreditCards.Size = New System.Drawing.Size(699, 433)
        Me.grpCreditCards.TabIndex = 2
        Me.grpCreditCards.TabStop = False
        '
        'TextBox57
        '
        Me.TextBox57.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox57.Location = New System.Drawing.Point(623, 352)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(65, 22)
        Me.TextBox57.TabIndex = 111
        Me.TextBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox57.Visible = False
        '
        'TextBox59
        '
        Me.TextBox59.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox59.Location = New System.Drawing.Point(538, 352)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(80, 22)
        Me.TextBox59.TabIndex = 110
        Me.TextBox59.Visible = False
        '
        'TextBox60
        '
        Me.TextBox60.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox60.Location = New System.Drawing.Point(452, 352)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(80, 22)
        Me.TextBox60.TabIndex = 109
        Me.TextBox60.Visible = False
        '
        'TextBox61
        '
        Me.TextBox61.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox61.Location = New System.Drawing.Point(385, 352)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(63, 22)
        Me.TextBox61.TabIndex = 108
        Me.TextBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox61.Visible = False
        '
        'TextBox62
        '
        Me.TextBox62.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox62.Location = New System.Drawing.Point(623, 324)
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Size = New System.Drawing.Size(65, 22)
        Me.TextBox62.TabIndex = 107
        Me.TextBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox62.Visible = False
        '
        'TextBox63
        '
        Me.TextBox63.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox63.Location = New System.Drawing.Point(538, 324)
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Size = New System.Drawing.Size(80, 22)
        Me.TextBox63.TabIndex = 106
        Me.TextBox63.Visible = False
        '
        'TextBox64
        '
        Me.TextBox64.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox64.Location = New System.Drawing.Point(452, 324)
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Size = New System.Drawing.Size(80, 22)
        Me.TextBox64.TabIndex = 105
        Me.TextBox64.Visible = False
        '
        'TextBox65
        '
        Me.TextBox65.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox65.Location = New System.Drawing.Point(385, 324)
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Size = New System.Drawing.Size(63, 22)
        Me.TextBox65.TabIndex = 104
        Me.TextBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox65.Visible = False
        '
        'TextBox66
        '
        Me.TextBox66.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox66.Location = New System.Drawing.Point(623, 296)
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(65, 22)
        Me.TextBox66.TabIndex = 103
        Me.TextBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox66.Visible = False
        '
        'TextBox67
        '
        Me.TextBox67.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox67.Location = New System.Drawing.Point(538, 296)
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(80, 22)
        Me.TextBox67.TabIndex = 102
        Me.TextBox67.Visible = False
        '
        'TextBox68
        '
        Me.TextBox68.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox68.Location = New System.Drawing.Point(452, 296)
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(80, 22)
        Me.TextBox68.TabIndex = 101
        Me.TextBox68.Visible = False
        '
        'TextBox69
        '
        Me.TextBox69.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox69.Location = New System.Drawing.Point(385, 296)
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.Size = New System.Drawing.Size(63, 22)
        Me.TextBox69.TabIndex = 100
        Me.TextBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox69.Visible = False
        '
        'TextBox70
        '
        Me.TextBox70.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox70.Location = New System.Drawing.Point(623, 268)
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.Size = New System.Drawing.Size(65, 22)
        Me.TextBox70.TabIndex = 99
        Me.TextBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox70.Visible = False
        '
        'TextBox71
        '
        Me.TextBox71.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox71.Location = New System.Drawing.Point(538, 268)
        Me.TextBox71.Name = "TextBox71"
        Me.TextBox71.Size = New System.Drawing.Size(80, 22)
        Me.TextBox71.TabIndex = 98
        Me.TextBox71.Visible = False
        '
        'TextBox72
        '
        Me.TextBox72.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox72.Location = New System.Drawing.Point(452, 268)
        Me.TextBox72.Name = "TextBox72"
        Me.TextBox72.Size = New System.Drawing.Size(80, 22)
        Me.TextBox72.TabIndex = 97
        Me.TextBox72.Visible = False
        '
        'TextBox73
        '
        Me.TextBox73.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox73.Location = New System.Drawing.Point(385, 268)
        Me.TextBox73.Name = "TextBox73"
        Me.TextBox73.Size = New System.Drawing.Size(63, 22)
        Me.TextBox73.TabIndex = 96
        Me.TextBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox73.Visible = False
        '
        'TextBox33
        '
        Me.TextBox33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox33.Location = New System.Drawing.Point(290, 352)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(89, 22)
        Me.TextBox33.TabIndex = 95
        Me.TextBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox33.Visible = False
        '
        'TextBox34
        '
        Me.TextBox34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox34.Location = New System.Drawing.Point(291, 324)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(89, 22)
        Me.TextBox34.TabIndex = 94
        Me.TextBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox34.Visible = False
        '
        'TextBox35
        '
        Me.TextBox35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox35.Location = New System.Drawing.Point(291, 296)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(89, 22)
        Me.TextBox35.TabIndex = 93
        Me.TextBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox35.Visible = False
        '
        'TextBox40
        '
        Me.TextBox40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox40.Location = New System.Drawing.Point(291, 268)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(89, 22)
        Me.TextBox40.TabIndex = 92
        Me.TextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBox40.Visible = False
        '
        'TextBox41
        '
        Me.TextBox41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox41.Location = New System.Drawing.Point(139, 352)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(147, 22)
        Me.TextBox41.TabIndex = 91
        Me.TextBox41.Visible = False
        '
        'TextBox42
        '
        Me.TextBox42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox42.Location = New System.Drawing.Point(139, 324)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(147, 22)
        Me.TextBox42.TabIndex = 90
        Me.TextBox42.Visible = False
        '
        'TextBox47
        '
        Me.TextBox47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox47.Location = New System.Drawing.Point(139, 296)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(147, 22)
        Me.TextBox47.TabIndex = 89
        Me.TextBox47.Visible = False
        '
        'TextBox48
        '
        Me.TextBox48.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox48.Location = New System.Drawing.Point(139, 268)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(147, 22)
        Me.TextBox48.TabIndex = 88
        Me.TextBox48.Visible = False
        '
        'TextBox49
        '
        Me.TextBox49.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox49.Location = New System.Drawing.Point(5, 352)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(128, 22)
        Me.TextBox49.TabIndex = 87
        Me.TextBox49.Visible = False
        '
        'TextBox54
        '
        Me.TextBox54.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox54.Location = New System.Drawing.Point(5, 324)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(128, 22)
        Me.TextBox54.TabIndex = 86
        Me.TextBox54.Visible = False
        '
        'TextBox55
        '
        Me.TextBox55.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox55.Location = New System.Drawing.Point(5, 296)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(128, 22)
        Me.TextBox55.TabIndex = 85
        Me.TextBox55.Visible = False
        '
        'TextBox56
        '
        Me.TextBox56.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox56.Location = New System.Drawing.Point(5, 268)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(128, 22)
        Me.TextBox56.TabIndex = 84
        Me.TextBox56.Visible = False
        '
        'txtCcy1
        '
        Me.txtCcy1.Enabled = False
        Me.txtCcy1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCcy1.Location = New System.Drawing.Point(139, 16)
        Me.txtCcy1.Name = "txtCcy1"
        Me.txtCcy1.Size = New System.Drawing.Size(80, 22)
        Me.txtCcy1.TabIndex = 71
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(3, 400)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(114, 24)
        Me.Label8.TabIndex = 70
        Me.Label8.Text = "Total:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(629, 14)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 24)
        Me.Label9.TabIndex = 69
        Me.Label9.Text = "Rate"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(535, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(83, 24)
        Me.Label10.TabIndex = 68
        Me.Label10.Text = "0% End"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(450, 15)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 24)
        Me.Label11.TabIndex = 67
        Me.Label11.Text = "Due Date"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(364, 15)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(83, 24)
        Me.Label12.TabIndex = 66
        Me.Label12.Text = "Min Pymt"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(288, 15)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(92, 24)
        Me.Label13.TabIndex = 65
        Me.Label13.Text = "Balance"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(3, 15)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(114, 24)
        Me.Label14.TabIndex = 64
        Me.Label14.Text = "Credit Cards:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTotal2
        '
        Me.txtTotal2.Enabled = False
        Me.txtTotal2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal2.Location = New System.Drawing.Point(385, 400)
        Me.txtTotal2.Name = "txtTotal2"
        Me.txtTotal2.Size = New System.Drawing.Size(63, 22)
        Me.txtTotal2.TabIndex = 63
        Me.txtTotal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotal1
        '
        Me.txtTotal1.Enabled = False
        Me.txtTotal1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal1.Location = New System.Drawing.Point(291, 400)
        Me.txtTotal1.Name = "txtTotal1"
        Me.txtTotal1.Size = New System.Drawing.Size(89, 22)
        Me.txtTotal1.TabIndex = 62
        Me.txtTotal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtRate16
        '
        Me.txtRate16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate16.Location = New System.Drawing.Point(623, 240)
        Me.txtRate16.Name = "txtRate16"
        Me.txtRate16.Size = New System.Drawing.Size(65, 22)
        Me.txtRate16.TabIndex = 61
        Me.txtRate16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd16
        '
        Me.txtZeropcEnd16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd16.Location = New System.Drawing.Point(538, 240)
        Me.txtZeropcEnd16.Name = "txtZeropcEnd16"
        Me.txtZeropcEnd16.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd16.TabIndex = 60
        '
        'txtDueDate16
        '
        Me.txtDueDate16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate16.Location = New System.Drawing.Point(452, 240)
        Me.txtDueDate16.Name = "txtDueDate16"
        Me.txtDueDate16.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate16.TabIndex = 59
        '
        'txtMinPymt16
        '
        Me.txtMinPymt16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt16.Location = New System.Drawing.Point(385, 240)
        Me.txtMinPymt16.Name = "txtMinPymt16"
        Me.txtMinPymt16.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt16.TabIndex = 58
        Me.txtMinPymt16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance16
        '
        Me.txtBalance16.Enabled = False
        Me.txtBalance16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance16.Location = New System.Drawing.Point(291, 240)
        Me.txtBalance16.Name = "txtBalance16"
        Me.txtBalance16.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance16.TabIndex = 57
        Me.txtBalance16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName16
        '
        Me.txtName16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName16.Location = New System.Drawing.Point(139, 240)
        Me.txtName16.Name = "txtName16"
        Me.txtName16.Size = New System.Drawing.Size(147, 22)
        Me.txtName16.TabIndex = 56
        '
        'txtAcctNo16
        '
        Me.txtAcctNo16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo16.Location = New System.Drawing.Point(5, 240)
        Me.txtAcctNo16.Name = "txtAcctNo16"
        Me.txtAcctNo16.Size = New System.Drawing.Size(128, 22)
        Me.txtAcctNo16.TabIndex = 55
        '
        'txtRate15
        '
        Me.txtRate15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate15.Location = New System.Drawing.Point(623, 212)
        Me.txtRate15.Name = "txtRate15"
        Me.txtRate15.Size = New System.Drawing.Size(65, 22)
        Me.txtRate15.TabIndex = 54
        Me.txtRate15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd15
        '
        Me.txtZeropcEnd15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd15.Location = New System.Drawing.Point(538, 212)
        Me.txtZeropcEnd15.Name = "txtZeropcEnd15"
        Me.txtZeropcEnd15.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd15.TabIndex = 53
        '
        'txtDueDate15
        '
        Me.txtDueDate15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate15.Location = New System.Drawing.Point(452, 212)
        Me.txtDueDate15.Name = "txtDueDate15"
        Me.txtDueDate15.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate15.TabIndex = 52
        '
        'txtMinPymt15
        '
        Me.txtMinPymt15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt15.Location = New System.Drawing.Point(385, 212)
        Me.txtMinPymt15.Name = "txtMinPymt15"
        Me.txtMinPymt15.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt15.TabIndex = 51
        Me.txtMinPymt15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance15
        '
        Me.txtBalance15.Enabled = False
        Me.txtBalance15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance15.Location = New System.Drawing.Point(291, 212)
        Me.txtBalance15.Name = "txtBalance15"
        Me.txtBalance15.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance15.TabIndex = 50
        Me.txtBalance15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName15
        '
        Me.txtName15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName15.Location = New System.Drawing.Point(139, 212)
        Me.txtName15.Name = "txtName15"
        Me.txtName15.Size = New System.Drawing.Size(147, 22)
        Me.txtName15.TabIndex = 49
        '
        'txtAcctNo15
        '
        Me.txtAcctNo15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo15.Location = New System.Drawing.Point(5, 212)
        Me.txtAcctNo15.Name = "txtAcctNo15"
        Me.txtAcctNo15.Size = New System.Drawing.Size(128, 22)
        Me.txtAcctNo15.TabIndex = 48
        '
        'txtRate14
        '
        Me.txtRate14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate14.Location = New System.Drawing.Point(623, 184)
        Me.txtRate14.Name = "txtRate14"
        Me.txtRate14.Size = New System.Drawing.Size(65, 22)
        Me.txtRate14.TabIndex = 47
        Me.txtRate14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd14
        '
        Me.txtZeropcEnd14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd14.Location = New System.Drawing.Point(538, 184)
        Me.txtZeropcEnd14.Name = "txtZeropcEnd14"
        Me.txtZeropcEnd14.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd14.TabIndex = 46
        '
        'txtDueDate14
        '
        Me.txtDueDate14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate14.Location = New System.Drawing.Point(452, 184)
        Me.txtDueDate14.Name = "txtDueDate14"
        Me.txtDueDate14.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate14.TabIndex = 45
        '
        'txtMinPymt14
        '
        Me.txtMinPymt14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt14.Location = New System.Drawing.Point(385, 184)
        Me.txtMinPymt14.Name = "txtMinPymt14"
        Me.txtMinPymt14.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt14.TabIndex = 44
        Me.txtMinPymt14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance14
        '
        Me.txtBalance14.Enabled = False
        Me.txtBalance14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance14.Location = New System.Drawing.Point(291, 184)
        Me.txtBalance14.Name = "txtBalance14"
        Me.txtBalance14.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance14.TabIndex = 43
        Me.txtBalance14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName14
        '
        Me.txtName14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName14.Location = New System.Drawing.Point(139, 184)
        Me.txtName14.Name = "txtName14"
        Me.txtName14.Size = New System.Drawing.Size(147, 22)
        Me.txtName14.TabIndex = 42
        '
        'txtAcctNo14
        '
        Me.txtAcctNo14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo14.Location = New System.Drawing.Point(5, 184)
        Me.txtAcctNo14.Name = "txtAcctNo14"
        Me.txtAcctNo14.Size = New System.Drawing.Size(128, 22)
        Me.txtAcctNo14.TabIndex = 41
        '
        'txtRate13
        '
        Me.txtRate13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate13.Location = New System.Drawing.Point(623, 156)
        Me.txtRate13.Name = "txtRate13"
        Me.txtRate13.Size = New System.Drawing.Size(65, 22)
        Me.txtRate13.TabIndex = 40
        Me.txtRate13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd13
        '
        Me.txtZeropcEnd13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd13.Location = New System.Drawing.Point(538, 156)
        Me.txtZeropcEnd13.Name = "txtZeropcEnd13"
        Me.txtZeropcEnd13.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd13.TabIndex = 39
        '
        'txtDueDate13
        '
        Me.txtDueDate13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate13.Location = New System.Drawing.Point(452, 156)
        Me.txtDueDate13.Name = "txtDueDate13"
        Me.txtDueDate13.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate13.TabIndex = 38
        '
        'txtMinPymt13
        '
        Me.txtMinPymt13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt13.Location = New System.Drawing.Point(385, 156)
        Me.txtMinPymt13.Name = "txtMinPymt13"
        Me.txtMinPymt13.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt13.TabIndex = 37
        Me.txtMinPymt13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance13
        '
        Me.txtBalance13.Enabled = False
        Me.txtBalance13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance13.Location = New System.Drawing.Point(291, 156)
        Me.txtBalance13.Name = "txtBalance13"
        Me.txtBalance13.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance13.TabIndex = 36
        Me.txtBalance13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName13
        '
        Me.txtName13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName13.Location = New System.Drawing.Point(139, 156)
        Me.txtName13.Name = "txtName13"
        Me.txtName13.Size = New System.Drawing.Size(147, 22)
        Me.txtName13.TabIndex = 35
        '
        'txtAcctNo13
        '
        Me.txtAcctNo13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo13.Location = New System.Drawing.Point(5, 156)
        Me.txtAcctNo13.Name = "txtAcctNo13"
        Me.txtAcctNo13.Size = New System.Drawing.Size(128, 22)
        Me.txtAcctNo13.TabIndex = 34
        '
        'txtRate12
        '
        Me.txtRate12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate12.Location = New System.Drawing.Point(623, 128)
        Me.txtRate12.Name = "txtRate12"
        Me.txtRate12.Size = New System.Drawing.Size(65, 22)
        Me.txtRate12.TabIndex = 33
        Me.txtRate12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd12
        '
        Me.txtZeropcEnd12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd12.Location = New System.Drawing.Point(538, 128)
        Me.txtZeropcEnd12.Name = "txtZeropcEnd12"
        Me.txtZeropcEnd12.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd12.TabIndex = 32
        '
        'txtDueDate12
        '
        Me.txtDueDate12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate12.Location = New System.Drawing.Point(452, 128)
        Me.txtDueDate12.Name = "txtDueDate12"
        Me.txtDueDate12.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate12.TabIndex = 31
        '
        'txtMinPymt12
        '
        Me.txtMinPymt12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt12.Location = New System.Drawing.Point(385, 128)
        Me.txtMinPymt12.Name = "txtMinPymt12"
        Me.txtMinPymt12.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt12.TabIndex = 30
        Me.txtMinPymt12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance12
        '
        Me.txtBalance12.Enabled = False
        Me.txtBalance12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance12.Location = New System.Drawing.Point(291, 128)
        Me.txtBalance12.Name = "txtBalance12"
        Me.txtBalance12.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance12.TabIndex = 29
        Me.txtBalance12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName12
        '
        Me.txtName12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName12.Location = New System.Drawing.Point(139, 128)
        Me.txtName12.Name = "txtName12"
        Me.txtName12.Size = New System.Drawing.Size(147, 22)
        Me.txtName12.TabIndex = 28
        '
        'txtAcctNo12
        '
        Me.txtAcctNo12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo12.Location = New System.Drawing.Point(5, 128)
        Me.txtAcctNo12.Name = "txtAcctNo12"
        Me.txtAcctNo12.Size = New System.Drawing.Size(128, 22)
        Me.txtAcctNo12.TabIndex = 27
        '
        'txtRate11
        '
        Me.txtRate11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate11.Location = New System.Drawing.Point(623, 100)
        Me.txtRate11.Name = "txtRate11"
        Me.txtRate11.Size = New System.Drawing.Size(65, 22)
        Me.txtRate11.TabIndex = 26
        Me.txtRate11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd11
        '
        Me.txtZeropcEnd11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd11.Location = New System.Drawing.Point(538, 100)
        Me.txtZeropcEnd11.Name = "txtZeropcEnd11"
        Me.txtZeropcEnd11.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd11.TabIndex = 25
        '
        'txtDueDate11
        '
        Me.txtDueDate11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate11.Location = New System.Drawing.Point(452, 100)
        Me.txtDueDate11.Name = "txtDueDate11"
        Me.txtDueDate11.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate11.TabIndex = 24
        '
        'txtMinPymt11
        '
        Me.txtMinPymt11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt11.Location = New System.Drawing.Point(385, 100)
        Me.txtMinPymt11.Name = "txtMinPymt11"
        Me.txtMinPymt11.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt11.TabIndex = 23
        Me.txtMinPymt11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance11
        '
        Me.txtBalance11.Enabled = False
        Me.txtBalance11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance11.Location = New System.Drawing.Point(291, 100)
        Me.txtBalance11.Name = "txtBalance11"
        Me.txtBalance11.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance11.TabIndex = 22
        Me.txtBalance11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName11
        '
        Me.txtName11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName11.Location = New System.Drawing.Point(139, 100)
        Me.txtName11.Name = "txtName11"
        Me.txtName11.Size = New System.Drawing.Size(147, 22)
        Me.txtName11.TabIndex = 21
        '
        'txtAcctNo11
        '
        Me.txtAcctNo11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo11.Location = New System.Drawing.Point(5, 100)
        Me.txtAcctNo11.Name = "txtAcctNo11"
        Me.txtAcctNo11.Size = New System.Drawing.Size(128, 22)
        Me.txtAcctNo11.TabIndex = 20
        '
        'txtRate10
        '
        Me.txtRate10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate10.Location = New System.Drawing.Point(623, 72)
        Me.txtRate10.Name = "txtRate10"
        Me.txtRate10.Size = New System.Drawing.Size(65, 22)
        Me.txtRate10.TabIndex = 19
        Me.txtRate10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd10
        '
        Me.txtZeropcEnd10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd10.Location = New System.Drawing.Point(538, 72)
        Me.txtZeropcEnd10.Name = "txtZeropcEnd10"
        Me.txtZeropcEnd10.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd10.TabIndex = 18
        '
        'txtDueDate10
        '
        Me.txtDueDate10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate10.Location = New System.Drawing.Point(452, 72)
        Me.txtDueDate10.Name = "txtDueDate10"
        Me.txtDueDate10.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate10.TabIndex = 17
        '
        'txtMinPymt10
        '
        Me.txtMinPymt10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt10.Location = New System.Drawing.Point(385, 72)
        Me.txtMinPymt10.Name = "txtMinPymt10"
        Me.txtMinPymt10.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt10.TabIndex = 16
        Me.txtMinPymt10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance10
        '
        Me.txtBalance10.Enabled = False
        Me.txtBalance10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance10.Location = New System.Drawing.Point(291, 72)
        Me.txtBalance10.Name = "txtBalance10"
        Me.txtBalance10.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance10.TabIndex = 15
        Me.txtBalance10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName10
        '
        Me.txtName10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName10.Location = New System.Drawing.Point(139, 72)
        Me.txtName10.Name = "txtName10"
        Me.txtName10.Size = New System.Drawing.Size(147, 22)
        Me.txtName10.TabIndex = 14
        '
        'txtAcctNo10
        '
        Me.txtAcctNo10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo10.Location = New System.Drawing.Point(5, 72)
        Me.txtAcctNo10.Name = "txtAcctNo10"
        Me.txtAcctNo10.Size = New System.Drawing.Size(128, 22)
        Me.txtAcctNo10.TabIndex = 13
        '
        'txtRate9
        '
        Me.txtRate9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate9.Location = New System.Drawing.Point(623, 44)
        Me.txtRate9.Name = "txtRate9"
        Me.txtRate9.Size = New System.Drawing.Size(65, 22)
        Me.txtRate9.TabIndex = 12
        Me.txtRate9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd9
        '
        Me.txtZeropcEnd9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd9.Location = New System.Drawing.Point(538, 44)
        Me.txtZeropcEnd9.Name = "txtZeropcEnd9"
        Me.txtZeropcEnd9.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd9.TabIndex = 5
        '
        'txtDueDate9
        '
        Me.txtDueDate9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate9.Location = New System.Drawing.Point(452, 44)
        Me.txtDueDate9.Name = "txtDueDate9"
        Me.txtDueDate9.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate9.TabIndex = 4
        '
        'txtMinPymt9
        '
        Me.txtMinPymt9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt9.Location = New System.Drawing.Point(385, 44)
        Me.txtMinPymt9.Name = "txtMinPymt9"
        Me.txtMinPymt9.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt9.TabIndex = 3
        Me.txtMinPymt9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance9
        '
        Me.txtBalance9.Enabled = False
        Me.txtBalance9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance9.Location = New System.Drawing.Point(291, 44)
        Me.txtBalance9.Name = "txtBalance9"
        Me.txtBalance9.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance9.TabIndex = 2
        Me.txtBalance9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName9
        '
        Me.txtName9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName9.Location = New System.Drawing.Point(139, 44)
        Me.txtName9.Name = "txtName9"
        Me.txtName9.Size = New System.Drawing.Size(147, 22)
        Me.txtName9.TabIndex = 1
        '
        'txtAcctNo9
        '
        Me.txtAcctNo9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo9.Location = New System.Drawing.Point(5, 44)
        Me.txtAcctNo9.Name = "txtAcctNo9"
        Me.txtAcctNo9.Size = New System.Drawing.Size(128, 22)
        Me.txtAcctNo9.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage3.Controls.Add(Me.grpToPayToCome)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(708, 445)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Harebell 3          "
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'grpToPayToCome
        '
        Me.grpToPayToCome.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.grpToPayToCome.Controls.Add(Me.Label15)
        Me.grpToPayToCome.Controls.Add(Me.Label23)
        Me.grpToPayToCome.Controls.Add(Me.Label24)
        Me.grpToPayToCome.Controls.Add(Me.Label25)
        Me.grpToPayToCome.Controls.Add(Me.txtDueDate22)
        Me.grpToPayToCome.Controls.Add(Me.txtBalance22)
        Me.grpToPayToCome.Controls.Add(Me.txtName22)
        Me.grpToPayToCome.Controls.Add(Me.txtAcctNo22)
        Me.grpToPayToCome.Controls.Add(Me.txtDueDate21)
        Me.grpToPayToCome.Controls.Add(Me.txtBalance21)
        Me.grpToPayToCome.Controls.Add(Me.txtName21)
        Me.grpToPayToCome.Controls.Add(Me.txtAcctNo21)
        Me.grpToPayToCome.Controls.Add(Me.txtDueDate20)
        Me.grpToPayToCome.Controls.Add(Me.txtBalance20)
        Me.grpToPayToCome.Controls.Add(Me.txtName20)
        Me.grpToPayToCome.Controls.Add(Me.txtAcctNo20)
        Me.grpToPayToCome.Controls.Add(Me.txtDueDate19)
        Me.grpToPayToCome.Controls.Add(Me.txtBalance19)
        Me.grpToPayToCome.Controls.Add(Me.txtName19)
        Me.grpToPayToCome.Controls.Add(Me.txtAcctNo19)
        Me.grpToPayToCome.Controls.Add(Me.txtDueDate18)
        Me.grpToPayToCome.Controls.Add(Me.txtBalance18)
        Me.grpToPayToCome.Controls.Add(Me.txtName18)
        Me.grpToPayToCome.Controls.Add(Me.txtAcctNo18)
        Me.grpToPayToCome.Controls.Add(Me.txtDueDate17)
        Me.grpToPayToCome.Controls.Add(Me.txtBalance17)
        Me.grpToPayToCome.Controls.Add(Me.txtName17)
        Me.grpToPayToCome.Controls.Add(Me.txtAcctNo17)
        Me.grpToPayToCome.Location = New System.Drawing.Point(5, 6)
        Me.grpToPayToCome.Name = "grpToPayToCome"
        Me.grpToPayToCome.Size = New System.Drawing.Size(704, 439)
        Me.grpToPayToCome.TabIndex = 0
        Me.grpToPayToCome.TabStop = False
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(5, 240)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(114, 24)
        Me.Label15.TabIndex = 142
        Me.Label15.Tag = "Bank "
        Me.Label15.Text = "To Come:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(382, 129)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(65, 24)
        Me.Label23.TabIndex = 141
        Me.Label23.Text = "Due Date"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(271, 129)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(92, 24)
        Me.Label24.TabIndex = 140
        Me.Label24.Text = "Amount"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(5, 129)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(114, 24)
        Me.Label25.TabIndex = 139
        Me.Label25.Tag = "Bank "
        Me.Label25.Text = "To Pay:"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtDueDate22
        '
        Me.txtDueDate22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate22.Location = New System.Drawing.Point(385, 324)
        Me.txtDueDate22.Name = "txtDueDate22"
        Me.txtDueDate22.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate22.TabIndex = 138
        Me.txtDueDate22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance22
        '
        Me.txtBalance22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance22.Location = New System.Drawing.Point(274, 324)
        Me.txtBalance22.Name = "txtBalance22"
        Me.txtBalance22.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance22.TabIndex = 137
        Me.txtBalance22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName22
        '
        Me.txtName22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName22.Location = New System.Drawing.Point(122, 324)
        Me.txtName22.Name = "txtName22"
        Me.txtName22.Size = New System.Drawing.Size(147, 22)
        Me.txtName22.TabIndex = 136
        '
        'txtAcctNo22
        '
        Me.txtAcctNo22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo22.Location = New System.Drawing.Point(5, 324)
        Me.txtAcctNo22.Name = "txtAcctNo22"
        Me.txtAcctNo22.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo22.TabIndex = 135
        Me.txtAcctNo22.Visible = False
        '
        'txtDueDate21
        '
        Me.txtDueDate21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate21.Location = New System.Drawing.Point(385, 295)
        Me.txtDueDate21.Name = "txtDueDate21"
        Me.txtDueDate21.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate21.TabIndex = 134
        Me.txtDueDate21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance21
        '
        Me.txtBalance21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance21.Location = New System.Drawing.Point(274, 295)
        Me.txtBalance21.Name = "txtBalance21"
        Me.txtBalance21.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance21.TabIndex = 133
        Me.txtBalance21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName21
        '
        Me.txtName21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName21.Location = New System.Drawing.Point(122, 296)
        Me.txtName21.Name = "txtName21"
        Me.txtName21.Size = New System.Drawing.Size(147, 22)
        Me.txtName21.TabIndex = 132
        '
        'txtAcctNo21
        '
        Me.txtAcctNo21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo21.Location = New System.Drawing.Point(5, 296)
        Me.txtAcctNo21.Name = "txtAcctNo21"
        Me.txtAcctNo21.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo21.TabIndex = 131
        Me.txtAcctNo21.Visible = False
        '
        'txtDueDate20
        '
        Me.txtDueDate20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate20.Location = New System.Drawing.Point(385, 268)
        Me.txtDueDate20.Name = "txtDueDate20"
        Me.txtDueDate20.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate20.TabIndex = 130
        Me.txtDueDate20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance20
        '
        Me.txtBalance20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance20.Location = New System.Drawing.Point(274, 268)
        Me.txtBalance20.Name = "txtBalance20"
        Me.txtBalance20.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance20.TabIndex = 129
        Me.txtBalance20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName20
        '
        Me.txtName20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName20.Location = New System.Drawing.Point(122, 268)
        Me.txtName20.Name = "txtName20"
        Me.txtName20.Size = New System.Drawing.Size(147, 22)
        Me.txtName20.TabIndex = 128
        '
        'txtAcctNo20
        '
        Me.txtAcctNo20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo20.Location = New System.Drawing.Point(5, 268)
        Me.txtAcctNo20.Name = "txtAcctNo20"
        Me.txtAcctNo20.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo20.TabIndex = 127
        Me.txtAcctNo20.Visible = False
        '
        'txtDueDate19
        '
        Me.txtDueDate19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate19.Location = New System.Drawing.Point(385, 212)
        Me.txtDueDate19.Name = "txtDueDate19"
        Me.txtDueDate19.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate19.TabIndex = 126
        Me.txtDueDate19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance19
        '
        Me.txtBalance19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance19.Location = New System.Drawing.Point(274, 212)
        Me.txtBalance19.Name = "txtBalance19"
        Me.txtBalance19.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance19.TabIndex = 125
        Me.txtBalance19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName19
        '
        Me.txtName19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName19.Location = New System.Drawing.Point(122, 212)
        Me.txtName19.Name = "txtName19"
        Me.txtName19.Size = New System.Drawing.Size(147, 22)
        Me.txtName19.TabIndex = 124
        '
        'txtAcctNo19
        '
        Me.txtAcctNo19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo19.Location = New System.Drawing.Point(5, 212)
        Me.txtAcctNo19.Name = "txtAcctNo19"
        Me.txtAcctNo19.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo19.TabIndex = 123
        Me.txtAcctNo19.Visible = False
        '
        'txtDueDate18
        '
        Me.txtDueDate18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate18.Location = New System.Drawing.Point(385, 184)
        Me.txtDueDate18.Name = "txtDueDate18"
        Me.txtDueDate18.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate18.TabIndex = 122
        Me.txtDueDate18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance18
        '
        Me.txtBalance18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance18.Location = New System.Drawing.Point(274, 184)
        Me.txtBalance18.Name = "txtBalance18"
        Me.txtBalance18.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance18.TabIndex = 121
        Me.txtBalance18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName18
        '
        Me.txtName18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName18.Location = New System.Drawing.Point(122, 184)
        Me.txtName18.Name = "txtName18"
        Me.txtName18.Size = New System.Drawing.Size(147, 22)
        Me.txtName18.TabIndex = 120
        '
        'txtAcctNo18
        '
        Me.txtAcctNo18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo18.Location = New System.Drawing.Point(4, 184)
        Me.txtAcctNo18.Name = "txtAcctNo18"
        Me.txtAcctNo18.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo18.TabIndex = 119
        Me.txtAcctNo18.Visible = False
        '
        'txtDueDate17
        '
        Me.txtDueDate17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate17.Location = New System.Drawing.Point(385, 156)
        Me.txtDueDate17.Name = "txtDueDate17"
        Me.txtDueDate17.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate17.TabIndex = 118
        Me.txtDueDate17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance17
        '
        Me.txtBalance17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance17.Location = New System.Drawing.Point(274, 156)
        Me.txtBalance17.Name = "txtBalance17"
        Me.txtBalance17.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance17.TabIndex = 117
        Me.txtBalance17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName17
        '
        Me.txtName17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName17.Location = New System.Drawing.Point(122, 156)
        Me.txtName17.Name = "txtName17"
        Me.txtName17.Size = New System.Drawing.Size(147, 22)
        Me.txtName17.TabIndex = 116
        '
        'txtAcctNo17
        '
        Me.txtAcctNo17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo17.Location = New System.Drawing.Point(5, 156)
        Me.txtAcctNo17.Name = "txtAcctNo17"
        Me.txtAcctNo17.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo17.TabIndex = 115
        Me.txtAcctNo17.Visible = False
        '
        'TabPage4
        '
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage4.Controls.Add(Me.grpAquavista)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(708, 445)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Aquavista          "
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'grpAquavista
        '
        Me.grpAquavista.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.grpAquavista.Controls.Add(Me.Label22)
        Me.grpAquavista.Controls.Add(Me.Label21)
        Me.grpAquavista.Controls.Add(Me.Label20)
        Me.grpAquavista.Controls.Add(Me.Label19)
        Me.grpAquavista.Controls.Add(Me.Label16)
        Me.grpAquavista.Controls.Add(Me.Label17)
        Me.grpAquavista.Controls.Add(Me.Label18)
        Me.grpAquavista.Controls.Add(Me.txtDueDate37)
        Me.grpAquavista.Controls.Add(Me.txtBalance37)
        Me.grpAquavista.Controls.Add(Me.txtName37)
        Me.grpAquavista.Controls.Add(Me.txtAcctNo37)
        Me.grpAquavista.Controls.Add(Me.txtDueDate36)
        Me.grpAquavista.Controls.Add(Me.txtBalance36)
        Me.grpAquavista.Controls.Add(Me.txtName36)
        Me.grpAquavista.Controls.Add(Me.txtAcctNo36)
        Me.grpAquavista.Controls.Add(Me.txtDueDate35)
        Me.grpAquavista.Controls.Add(Me.txtBalance35)
        Me.grpAquavista.Controls.Add(Me.txtName35)
        Me.grpAquavista.Controls.Add(Me.txtAcctNo35)
        Me.grpAquavista.Controls.Add(Me.txtDueDate34)
        Me.grpAquavista.Controls.Add(Me.txtBalance34)
        Me.grpAquavista.Controls.Add(Me.txtName34)
        Me.grpAquavista.Controls.Add(Me.txtAcctNo34)
        Me.grpAquavista.Controls.Add(Me.txtDueDate33)
        Me.grpAquavista.Controls.Add(Me.txtBalance33)
        Me.grpAquavista.Controls.Add(Me.txtName33)
        Me.grpAquavista.Controls.Add(Me.txtAcctNo33)
        Me.grpAquavista.Controls.Add(Me.txtDueDate32)
        Me.grpAquavista.Controls.Add(Me.txtBalance32)
        Me.grpAquavista.Controls.Add(Me.txtName32)
        Me.grpAquavista.Controls.Add(Me.txtAcctNo32)
        Me.grpAquavista.Controls.Add(Me.txtCcy4)
        Me.grpAquavista.Controls.Add(Me.txtBalance31)
        Me.grpAquavista.Controls.Add(Me.txtName31)
        Me.grpAquavista.Controls.Add(Me.txtAcctNo31)
        Me.grpAquavista.Controls.Add(Me.txtCcy3)
        Me.grpAquavista.Controls.Add(Me.txtBalance30)
        Me.grpAquavista.Controls.Add(Me.txtName30)
        Me.grpAquavista.Controls.Add(Me.txtAcctNo30)
        Me.grpAquavista.Location = New System.Drawing.Point(5, 6)
        Me.grpAquavista.Name = "grpAquavista"
        Me.grpAquavista.Size = New System.Drawing.Size(704, 435)
        Me.grpAquavista.TabIndex = 0
        Me.grpAquavista.TabStop = False
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(382, 129)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(65, 24)
        Me.Label22.TabIndex = 114
        Me.Label22.Text = "Due Date"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(271, 129)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(92, 24)
        Me.Label21.TabIndex = 113
        Me.Label21.Text = "Amount"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(5, 241)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(114, 24)
        Me.Label20.TabIndex = 112
        Me.Label20.Tag = "Bank "
        Me.Label20.Text = "To Come:"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(5, 129)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(114, 24)
        Me.Label19.TabIndex = 111
        Me.Label19.Tag = "Bank "
        Me.Label19.Text = "To Pay:"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(364, 15)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(83, 24)
        Me.Label16.TabIndex = 108
        Me.Label16.Text = "Currency"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(271, 15)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(92, 24)
        Me.Label17.TabIndex = 107
        Me.Label17.Text = "Balance"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(3, 15)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(114, 24)
        Me.Label18.TabIndex = 106
        Me.Label18.Tag = "Bank "
        Me.Label18.Text = "Bank Accounts:"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtDueDate37
        '
        Me.txtDueDate37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate37.Location = New System.Drawing.Point(385, 324)
        Me.txtDueDate37.Name = "txtDueDate37"
        Me.txtDueDate37.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate37.TabIndex = 103
        Me.txtDueDate37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance37
        '
        Me.txtBalance37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance37.Location = New System.Drawing.Point(274, 324)
        Me.txtBalance37.Name = "txtBalance37"
        Me.txtBalance37.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance37.TabIndex = 102
        Me.txtBalance37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName37
        '
        Me.txtName37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName37.Location = New System.Drawing.Point(122, 324)
        Me.txtName37.Name = "txtName37"
        Me.txtName37.Size = New System.Drawing.Size(147, 22)
        Me.txtName37.TabIndex = 101
        '
        'txtAcctNo37
        '
        Me.txtAcctNo37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo37.Location = New System.Drawing.Point(5, 324)
        Me.txtAcctNo37.Name = "txtAcctNo37"
        Me.txtAcctNo37.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo37.TabIndex = 100
        Me.txtAcctNo37.Visible = False
        '
        'txtDueDate36
        '
        Me.txtDueDate36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate36.Location = New System.Drawing.Point(385, 296)
        Me.txtDueDate36.Name = "txtDueDate36"
        Me.txtDueDate36.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate36.TabIndex = 99
        Me.txtDueDate36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance36
        '
        Me.txtBalance36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance36.Location = New System.Drawing.Point(274, 296)
        Me.txtBalance36.Name = "txtBalance36"
        Me.txtBalance36.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance36.TabIndex = 98
        Me.txtBalance36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName36
        '
        Me.txtName36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName36.Location = New System.Drawing.Point(122, 296)
        Me.txtName36.Name = "txtName36"
        Me.txtName36.Size = New System.Drawing.Size(147, 22)
        Me.txtName36.TabIndex = 97
        '
        'txtAcctNo36
        '
        Me.txtAcctNo36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo36.Location = New System.Drawing.Point(5, 296)
        Me.txtAcctNo36.Name = "txtAcctNo36"
        Me.txtAcctNo36.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo36.TabIndex = 96
        Me.txtAcctNo36.Visible = False
        '
        'txtDueDate35
        '
        Me.txtDueDate35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate35.Location = New System.Drawing.Point(385, 268)
        Me.txtDueDate35.Name = "txtDueDate35"
        Me.txtDueDate35.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate35.TabIndex = 95
        Me.txtDueDate35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance35
        '
        Me.txtBalance35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance35.Location = New System.Drawing.Point(274, 268)
        Me.txtBalance35.Name = "txtBalance35"
        Me.txtBalance35.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance35.TabIndex = 94
        Me.txtBalance35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName35
        '
        Me.txtName35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName35.Location = New System.Drawing.Point(122, 268)
        Me.txtName35.Name = "txtName35"
        Me.txtName35.Size = New System.Drawing.Size(147, 22)
        Me.txtName35.TabIndex = 93
        '
        'txtAcctNo35
        '
        Me.txtAcctNo35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo35.Location = New System.Drawing.Point(5, 268)
        Me.txtAcctNo35.Name = "txtAcctNo35"
        Me.txtAcctNo35.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo35.TabIndex = 92
        Me.txtAcctNo35.Visible = False
        '
        'txtDueDate34
        '
        Me.txtDueDate34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate34.Location = New System.Drawing.Point(385, 212)
        Me.txtDueDate34.Name = "txtDueDate34"
        Me.txtDueDate34.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate34.TabIndex = 91
        Me.txtDueDate34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance34
        '
        Me.txtBalance34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance34.Location = New System.Drawing.Point(274, 212)
        Me.txtBalance34.Name = "txtBalance34"
        Me.txtBalance34.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance34.TabIndex = 90
        Me.txtBalance34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName34
        '
        Me.txtName34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName34.Location = New System.Drawing.Point(122, 212)
        Me.txtName34.Name = "txtName34"
        Me.txtName34.Size = New System.Drawing.Size(147, 22)
        Me.txtName34.TabIndex = 89
        '
        'txtAcctNo34
        '
        Me.txtAcctNo34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo34.Location = New System.Drawing.Point(5, 212)
        Me.txtAcctNo34.Name = "txtAcctNo34"
        Me.txtAcctNo34.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo34.TabIndex = 88
        Me.txtAcctNo34.Visible = False
        '
        'txtDueDate33
        '
        Me.txtDueDate33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate33.Location = New System.Drawing.Point(385, 184)
        Me.txtDueDate33.Name = "txtDueDate33"
        Me.txtDueDate33.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate33.TabIndex = 87
        Me.txtDueDate33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance33
        '
        Me.txtBalance33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance33.Location = New System.Drawing.Point(274, 184)
        Me.txtBalance33.Name = "txtBalance33"
        Me.txtBalance33.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance33.TabIndex = 86
        Me.txtBalance33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName33
        '
        Me.txtName33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName33.Location = New System.Drawing.Point(122, 184)
        Me.txtName33.Name = "txtName33"
        Me.txtName33.Size = New System.Drawing.Size(147, 22)
        Me.txtName33.TabIndex = 85
        '
        'txtAcctNo33
        '
        Me.txtAcctNo33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo33.Location = New System.Drawing.Point(5, 184)
        Me.txtAcctNo33.Name = "txtAcctNo33"
        Me.txtAcctNo33.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo33.TabIndex = 84
        Me.txtAcctNo33.Visible = False
        '
        'txtDueDate32
        '
        Me.txtDueDate32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate32.Location = New System.Drawing.Point(385, 156)
        Me.txtDueDate32.Name = "txtDueDate32"
        Me.txtDueDate32.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate32.TabIndex = 83
        Me.txtDueDate32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance32
        '
        Me.txtBalance32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance32.Location = New System.Drawing.Point(274, 156)
        Me.txtBalance32.Name = "txtBalance32"
        Me.txtBalance32.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance32.TabIndex = 82
        Me.txtBalance32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName32
        '
        Me.txtName32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName32.Location = New System.Drawing.Point(122, 156)
        Me.txtName32.Name = "txtName32"
        Me.txtName32.Size = New System.Drawing.Size(147, 22)
        Me.txtName32.TabIndex = 81
        '
        'txtAcctNo32
        '
        Me.txtAcctNo32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo32.Location = New System.Drawing.Point(5, 156)
        Me.txtAcctNo32.Name = "txtAcctNo32"
        Me.txtAcctNo32.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo32.TabIndex = 80
        Me.txtAcctNo32.Visible = False
        '
        'txtCcy4
        '
        Me.txtCcy4.Enabled = False
        Me.txtCcy4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCcy4.Location = New System.Drawing.Point(385, 72)
        Me.txtCcy4.Name = "txtCcy4"
        Me.txtCcy4.Size = New System.Drawing.Size(63, 22)
        Me.txtCcy4.TabIndex = 79
        Me.txtCcy4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance31
        '
        Me.txtBalance31.Enabled = False
        Me.txtBalance31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance31.Location = New System.Drawing.Point(274, 72)
        Me.txtBalance31.Name = "txtBalance31"
        Me.txtBalance31.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance31.TabIndex = 78
        Me.txtBalance31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName31
        '
        Me.txtName31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName31.Location = New System.Drawing.Point(122, 72)
        Me.txtName31.Name = "txtName31"
        Me.txtName31.Size = New System.Drawing.Size(147, 22)
        Me.txtName31.TabIndex = 77
        '
        'txtAcctNo31
        '
        Me.txtAcctNo31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo31.Location = New System.Drawing.Point(5, 72)
        Me.txtAcctNo31.Name = "txtAcctNo31"
        Me.txtAcctNo31.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo31.TabIndex = 76
        '
        'txtCcy3
        '
        Me.txtCcy3.Enabled = False
        Me.txtCcy3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCcy3.Location = New System.Drawing.Point(385, 44)
        Me.txtCcy3.Name = "txtCcy3"
        Me.txtCcy3.Size = New System.Drawing.Size(63, 22)
        Me.txtCcy3.TabIndex = 75
        Me.txtCcy3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance30
        '
        Me.txtBalance30.Enabled = False
        Me.txtBalance30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance30.Location = New System.Drawing.Point(274, 44)
        Me.txtBalance30.Name = "txtBalance30"
        Me.txtBalance30.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance30.TabIndex = 74
        Me.txtBalance30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName30
        '
        Me.txtName30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName30.Location = New System.Drawing.Point(122, 44)
        Me.txtName30.Name = "txtName30"
        Me.txtName30.Size = New System.Drawing.Size(147, 22)
        Me.txtName30.TabIndex = 73
        '
        'txtAcctNo30
        '
        Me.txtAcctNo30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo30.Location = New System.Drawing.Point(5, 44)
        Me.txtAcctNo30.Name = "txtAcctNo30"
        Me.txtAcctNo30.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo30.TabIndex = 72
        '
        'TabPage5
        '
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage5.Controls.Add(Me.grpMortgages)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(708, 445)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Mortgages       "
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'grpMortgages
        '
        Me.grpMortgages.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.grpMortgages.Controls.Add(Me.txtRate43)
        Me.grpMortgages.Controls.Add(Me.txtRate42)
        Me.grpMortgages.Controls.Add(Me.txtZeropcEnd43)
        Me.grpMortgages.Controls.Add(Me.txtZeropcEnd42)
        Me.grpMortgages.Controls.Add(Me.txtDueDate43)
        Me.grpMortgages.Controls.Add(Me.txtDueDate42)
        Me.grpMortgages.Controls.Add(Me.txtMinPymt43)
        Me.grpMortgages.Controls.Add(Me.txtMinPymt42)
        Me.grpMortgages.Controls.Add(Me.txtBalance43)
        Me.grpMortgages.Controls.Add(Me.txtBalance42)
        Me.grpMortgages.Controls.Add(Me.txtName43)
        Me.grpMortgages.Controls.Add(Me.txtName42)
        Me.grpMortgages.Controls.Add(Me.txtAcctNo43)
        Me.grpMortgages.Controls.Add(Me.txtAcctNo42)
        Me.grpMortgages.Controls.Add(Me.txtRate41)
        Me.grpMortgages.Controls.Add(Me.txtZeropcEnd41)
        Me.grpMortgages.Controls.Add(Me.txtDueDate41)
        Me.grpMortgages.Controls.Add(Me.txtMinPymt41)
        Me.grpMortgages.Controls.Add(Me.txtBalance41)
        Me.grpMortgages.Controls.Add(Me.txtName41)
        Me.grpMortgages.Controls.Add(Me.txtAcctNo41)
        Me.grpMortgages.Controls.Add(Me.txtRate40)
        Me.grpMortgages.Controls.Add(Me.txtZeropcEnd40)
        Me.grpMortgages.Controls.Add(Me.txtDueDate40)
        Me.grpMortgages.Controls.Add(Me.txtMinPymt40)
        Me.grpMortgages.Controls.Add(Me.txtBalance40)
        Me.grpMortgages.Controls.Add(Me.txtName40)
        Me.grpMortgages.Controls.Add(Me.txtAcctNo40)
        Me.grpMortgages.Controls.Add(Me.Label3)
        Me.grpMortgages.Controls.Add(Me.txtTotal4)
        Me.grpMortgages.Controls.Add(Me.txtTotal3)
        Me.grpMortgages.Controls.Add(Me.Label26)
        Me.grpMortgages.Controls.Add(Me.Label29)
        Me.grpMortgages.Controls.Add(Me.Label30)
        Me.grpMortgages.Controls.Add(Me.Label31)
        Me.grpMortgages.Controls.Add(Me.txtRate39)
        Me.grpMortgages.Controls.Add(Me.txtZeropcEnd39)
        Me.grpMortgages.Controls.Add(Me.txtDueDate39)
        Me.grpMortgages.Controls.Add(Me.txtMinPymt39)
        Me.grpMortgages.Controls.Add(Me.txtRate38)
        Me.grpMortgages.Controls.Add(Me.txtZeropcEnd38)
        Me.grpMortgages.Controls.Add(Me.txtDueDate38)
        Me.grpMortgages.Controls.Add(Me.txtMinPymt38)
        Me.grpMortgages.Controls.Add(Me.txtCcy5)
        Me.grpMortgages.Controls.Add(Me.Label27)
        Me.grpMortgages.Controls.Add(Me.Label28)
        Me.grpMortgages.Controls.Add(Me.txtBalance39)
        Me.grpMortgages.Controls.Add(Me.txtName39)
        Me.grpMortgages.Controls.Add(Me.txtAcctNo39)
        Me.grpMortgages.Controls.Add(Me.txtBalance38)
        Me.grpMortgages.Controls.Add(Me.txtName38)
        Me.grpMortgages.Controls.Add(Me.txtAcctNo38)
        Me.grpMortgages.Location = New System.Drawing.Point(3, 6)
        Me.grpMortgages.Name = "grpMortgages"
        Me.grpMortgages.Size = New System.Drawing.Size(706, 435)
        Me.grpMortgages.TabIndex = 1
        Me.grpMortgages.TabStop = False
        '
        'txtRate43
        '
        Me.txtRate43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate43.Location = New System.Drawing.Point(623, 184)
        Me.txtRate43.Name = "txtRate43"
        Me.txtRate43.Size = New System.Drawing.Size(65, 22)
        Me.txtRate43.TabIndex = 165
        Me.txtRate43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtRate42
        '
        Me.txtRate42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate42.Location = New System.Drawing.Point(623, 156)
        Me.txtRate42.Name = "txtRate42"
        Me.txtRate42.Size = New System.Drawing.Size(65, 22)
        Me.txtRate42.TabIndex = 164
        Me.txtRate42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd43
        '
        Me.txtZeropcEnd43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd43.Location = New System.Drawing.Point(538, 184)
        Me.txtZeropcEnd43.Name = "txtZeropcEnd43"
        Me.txtZeropcEnd43.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd43.TabIndex = 163
        '
        'txtZeropcEnd42
        '
        Me.txtZeropcEnd42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd42.Location = New System.Drawing.Point(538, 156)
        Me.txtZeropcEnd42.Name = "txtZeropcEnd42"
        Me.txtZeropcEnd42.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd42.TabIndex = 162
        '
        'txtDueDate43
        '
        Me.txtDueDate43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate43.Location = New System.Drawing.Point(452, 184)
        Me.txtDueDate43.Name = "txtDueDate43"
        Me.txtDueDate43.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate43.TabIndex = 161
        '
        'txtDueDate42
        '
        Me.txtDueDate42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate42.Location = New System.Drawing.Point(452, 156)
        Me.txtDueDate42.Name = "txtDueDate42"
        Me.txtDueDate42.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate42.TabIndex = 160
        '
        'txtMinPymt43
        '
        Me.txtMinPymt43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt43.Location = New System.Drawing.Point(385, 184)
        Me.txtMinPymt43.Name = "txtMinPymt43"
        Me.txtMinPymt43.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt43.TabIndex = 159
        Me.txtMinPymt43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtMinPymt42
        '
        Me.txtMinPymt42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt42.Location = New System.Drawing.Point(385, 156)
        Me.txtMinPymt42.Name = "txtMinPymt42"
        Me.txtMinPymt42.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt42.TabIndex = 158
        Me.txtMinPymt42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance43
        '
        Me.txtBalance43.Enabled = False
        Me.txtBalance43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance43.Location = New System.Drawing.Point(274, 184)
        Me.txtBalance43.Name = "txtBalance43"
        Me.txtBalance43.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance43.TabIndex = 157
        Me.txtBalance43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance42
        '
        Me.txtBalance42.Enabled = False
        Me.txtBalance42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance42.Location = New System.Drawing.Point(274, 156)
        Me.txtBalance42.Name = "txtBalance42"
        Me.txtBalance42.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance42.TabIndex = 156
        Me.txtBalance42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName43
        '
        Me.txtName43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName43.Location = New System.Drawing.Point(122, 184)
        Me.txtName43.Name = "txtName43"
        Me.txtName43.Size = New System.Drawing.Size(147, 22)
        Me.txtName43.TabIndex = 155
        '
        'txtName42
        '
        Me.txtName42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName42.Location = New System.Drawing.Point(122, 156)
        Me.txtName42.Name = "txtName42"
        Me.txtName42.Size = New System.Drawing.Size(147, 22)
        Me.txtName42.TabIndex = 154
        '
        'txtAcctNo43
        '
        Me.txtAcctNo43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo43.Location = New System.Drawing.Point(5, 184)
        Me.txtAcctNo43.Name = "txtAcctNo43"
        Me.txtAcctNo43.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo43.TabIndex = 153
        '
        'txtAcctNo42
        '
        Me.txtAcctNo42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo42.Location = New System.Drawing.Point(5, 156)
        Me.txtAcctNo42.Name = "txtAcctNo42"
        Me.txtAcctNo42.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo42.TabIndex = 152
        '
        'txtRate41
        '
        Me.txtRate41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate41.Location = New System.Drawing.Point(623, 128)
        Me.txtRate41.Name = "txtRate41"
        Me.txtRate41.Size = New System.Drawing.Size(65, 22)
        Me.txtRate41.TabIndex = 151
        Me.txtRate41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd41
        '
        Me.txtZeropcEnd41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd41.Location = New System.Drawing.Point(538, 128)
        Me.txtZeropcEnd41.Name = "txtZeropcEnd41"
        Me.txtZeropcEnd41.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd41.TabIndex = 150
        '
        'txtDueDate41
        '
        Me.txtDueDate41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate41.Location = New System.Drawing.Point(452, 128)
        Me.txtDueDate41.Name = "txtDueDate41"
        Me.txtDueDate41.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate41.TabIndex = 149
        '
        'txtMinPymt41
        '
        Me.txtMinPymt41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt41.Location = New System.Drawing.Point(385, 128)
        Me.txtMinPymt41.Name = "txtMinPymt41"
        Me.txtMinPymt41.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt41.TabIndex = 148
        Me.txtMinPymt41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance41
        '
        Me.txtBalance41.Enabled = False
        Me.txtBalance41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance41.Location = New System.Drawing.Point(274, 128)
        Me.txtBalance41.Name = "txtBalance41"
        Me.txtBalance41.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance41.TabIndex = 147
        Me.txtBalance41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName41
        '
        Me.txtName41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName41.Location = New System.Drawing.Point(122, 128)
        Me.txtName41.Name = "txtName41"
        Me.txtName41.Size = New System.Drawing.Size(147, 22)
        Me.txtName41.TabIndex = 146
        '
        'txtAcctNo41
        '
        Me.txtAcctNo41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo41.Location = New System.Drawing.Point(5, 128)
        Me.txtAcctNo41.Name = "txtAcctNo41"
        Me.txtAcctNo41.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo41.TabIndex = 145
        '
        'txtRate40
        '
        Me.txtRate40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate40.Location = New System.Drawing.Point(623, 100)
        Me.txtRate40.Name = "txtRate40"
        Me.txtRate40.Size = New System.Drawing.Size(65, 22)
        Me.txtRate40.TabIndex = 144
        Me.txtRate40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd40
        '
        Me.txtZeropcEnd40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd40.Location = New System.Drawing.Point(538, 100)
        Me.txtZeropcEnd40.Name = "txtZeropcEnd40"
        Me.txtZeropcEnd40.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd40.TabIndex = 143
        '
        'txtDueDate40
        '
        Me.txtDueDate40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate40.Location = New System.Drawing.Point(452, 100)
        Me.txtDueDate40.Name = "txtDueDate40"
        Me.txtDueDate40.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate40.TabIndex = 142
        '
        'txtMinPymt40
        '
        Me.txtMinPymt40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt40.Location = New System.Drawing.Point(385, 100)
        Me.txtMinPymt40.Name = "txtMinPymt40"
        Me.txtMinPymt40.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt40.TabIndex = 141
        Me.txtMinPymt40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBalance40
        '
        Me.txtBalance40.Enabled = False
        Me.txtBalance40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance40.Location = New System.Drawing.Point(274, 100)
        Me.txtBalance40.Name = "txtBalance40"
        Me.txtBalance40.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance40.TabIndex = 140
        Me.txtBalance40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName40
        '
        Me.txtName40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName40.Location = New System.Drawing.Point(122, 100)
        Me.txtName40.Name = "txtName40"
        Me.txtName40.Size = New System.Drawing.Size(147, 22)
        Me.txtName40.TabIndex = 139
        '
        'txtAcctNo40
        '
        Me.txtAcctNo40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo40.Location = New System.Drawing.Point(5, 100)
        Me.txtAcctNo40.Name = "txtAcctNo40"
        Me.txtAcctNo40.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo40.TabIndex = 138
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(3, 400)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(114, 24)
        Me.Label3.TabIndex = 137
        Me.Label3.Text = "Total:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTotal4
        '
        Me.txtTotal4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal4.Location = New System.Drawing.Point(385, 400)
        Me.txtTotal4.Name = "txtTotal4"
        Me.txtTotal4.Size = New System.Drawing.Size(63, 22)
        Me.txtTotal4.TabIndex = 136
        Me.txtTotal4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotal3
        '
        Me.txtTotal3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal3.Location = New System.Drawing.Point(274, 400)
        Me.txtTotal3.Name = "txtTotal3"
        Me.txtTotal3.Size = New System.Drawing.Size(89, 22)
        Me.txtTotal3.TabIndex = 135
        Me.txtTotal3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(623, 15)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(65, 24)
        Me.Label26.TabIndex = 134
        Me.Label26.Text = "Rate"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label29
        '
        Me.Label29.Location = New System.Drawing.Point(535, 15)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(89, 24)
        Me.Label29.TabIndex = 133
        Me.Label29.Text = "Fix Rate End"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label30
        '
        Me.Label30.Location = New System.Drawing.Point(450, 15)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(83, 24)
        Me.Label30.TabIndex = 132
        Me.Label30.Text = "Repay Date"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label31
        '
        Me.Label31.Location = New System.Drawing.Point(364, 15)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(83, 24)
        Me.Label31.TabIndex = 131
        Me.Label31.Text = "Mth Pymt"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtRate39
        '
        Me.txtRate39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate39.Location = New System.Drawing.Point(623, 72)
        Me.txtRate39.Name = "txtRate39"
        Me.txtRate39.Size = New System.Drawing.Size(65, 22)
        Me.txtRate39.TabIndex = 130
        Me.txtRate39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd39
        '
        Me.txtZeropcEnd39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd39.Location = New System.Drawing.Point(538, 72)
        Me.txtZeropcEnd39.Name = "txtZeropcEnd39"
        Me.txtZeropcEnd39.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd39.TabIndex = 129
        '
        'txtDueDate39
        '
        Me.txtDueDate39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate39.Location = New System.Drawing.Point(452, 72)
        Me.txtDueDate39.Name = "txtDueDate39"
        Me.txtDueDate39.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate39.TabIndex = 128
        '
        'txtMinPymt39
        '
        Me.txtMinPymt39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt39.Location = New System.Drawing.Point(385, 72)
        Me.txtMinPymt39.Name = "txtMinPymt39"
        Me.txtMinPymt39.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt39.TabIndex = 127
        Me.txtMinPymt39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtRate38
        '
        Me.txtRate38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRate38.Location = New System.Drawing.Point(623, 44)
        Me.txtRate38.Name = "txtRate38"
        Me.txtRate38.Size = New System.Drawing.Size(65, 22)
        Me.txtRate38.TabIndex = 126
        Me.txtRate38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtZeropcEnd38
        '
        Me.txtZeropcEnd38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZeropcEnd38.Location = New System.Drawing.Point(538, 44)
        Me.txtZeropcEnd38.Name = "txtZeropcEnd38"
        Me.txtZeropcEnd38.Size = New System.Drawing.Size(80, 22)
        Me.txtZeropcEnd38.TabIndex = 125
        '
        'txtDueDate38
        '
        Me.txtDueDate38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDate38.Location = New System.Drawing.Point(452, 44)
        Me.txtDueDate38.Name = "txtDueDate38"
        Me.txtDueDate38.Size = New System.Drawing.Size(80, 22)
        Me.txtDueDate38.TabIndex = 124
        '
        'txtMinPymt38
        '
        Me.txtMinPymt38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMinPymt38.Location = New System.Drawing.Point(385, 44)
        Me.txtMinPymt38.Name = "txtMinPymt38"
        Me.txtMinPymt38.Size = New System.Drawing.Size(63, 22)
        Me.txtMinPymt38.TabIndex = 123
        Me.txtMinPymt38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtCcy5
        '
        Me.txtCcy5.Enabled = False
        Me.txtCcy5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCcy5.Location = New System.Drawing.Point(122, 15)
        Me.txtCcy5.Name = "txtCcy5"
        Me.txtCcy5.Size = New System.Drawing.Size(80, 22)
        Me.txtCcy5.TabIndex = 122
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(271, 15)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(92, 24)
        Me.Label27.TabIndex = 120
        Me.Label27.Text = "Balance"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label28
        '
        Me.Label28.Location = New System.Drawing.Point(3, 15)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(123, 24)
        Me.Label28.TabIndex = 119
        Me.Label28.Tag = "Bank "
        Me.Label28.Text = "Mortgages/Loans:"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtBalance39
        '
        Me.txtBalance39.Enabled = False
        Me.txtBalance39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance39.Location = New System.Drawing.Point(274, 72)
        Me.txtBalance39.Name = "txtBalance39"
        Me.txtBalance39.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance39.TabIndex = 117
        Me.txtBalance39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName39
        '
        Me.txtName39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName39.Location = New System.Drawing.Point(122, 72)
        Me.txtName39.Name = "txtName39"
        Me.txtName39.Size = New System.Drawing.Size(147, 22)
        Me.txtName39.TabIndex = 116
        '
        'txtAcctNo39
        '
        Me.txtAcctNo39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo39.Location = New System.Drawing.Point(5, 72)
        Me.txtAcctNo39.Name = "txtAcctNo39"
        Me.txtAcctNo39.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo39.TabIndex = 115
        '
        'txtBalance38
        '
        Me.txtBalance38.Enabled = False
        Me.txtBalance38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance38.Location = New System.Drawing.Point(274, 44)
        Me.txtBalance38.Name = "txtBalance38"
        Me.txtBalance38.Size = New System.Drawing.Size(89, 22)
        Me.txtBalance38.TabIndex = 113
        Me.txtBalance38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtName38
        '
        Me.txtName38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName38.Location = New System.Drawing.Point(122, 44)
        Me.txtName38.Name = "txtName38"
        Me.txtName38.Size = New System.Drawing.Size(147, 22)
        Me.txtName38.TabIndex = 112
        '
        'txtAcctNo38
        '
        Me.txtAcctNo38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcctNo38.Location = New System.Drawing.Point(5, 44)
        Me.txtAcctNo38.Name = "txtAcctNo38"
        Me.txtAcctNo38.Size = New System.Drawing.Size(112, 22)
        Me.txtAcctNo38.TabIndex = 111
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblDeleteRow)
        Me.GroupBox2.Controls.Add(Me.cmdClose)
        Me.GroupBox2.Controls.Add(Me.cmdCancel)
        Me.GroupBox2.Controls.Add(Me.cmdOk)
        Me.GroupBox2.Controls.Add(Me.cmdAdd)
        Me.GroupBox2.Controls.Add(Me.cmdReport)
        Me.GroupBox2.Controls.Add(Me.cmdEdit)
        Me.GroupBox2.Location = New System.Drawing.Point(11, 519)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(716, 66)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        '
        'lblDeleteRow
        '
        Me.lblDeleteRow.BackColor = System.Drawing.Color.LightGray
        Me.lblDeleteRow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDeleteRow.Location = New System.Drawing.Point(280, 19)
        Me.lblDeleteRow.Name = "lblDeleteRow"
        Me.lblDeleteRow.Size = New System.Drawing.Size(144, 32)
        Me.lblDeleteRow.TabIndex = 6
        Me.lblDeleteRow.Text = "Enter 'x' in first column, Click Ok to Delete Row"
        Me.lblDeleteRow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblDeleteRow.Visible = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.Color.LightGray
        Me.cmdClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.Location = New System.Drawing.Point(631, 19)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(71, 35)
        Me.cmdClose.TabIndex = 5
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.LightGray
        Me.cmdCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.Location = New System.Drawing.Point(537, 19)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(71, 35)
        Me.cmdCancel.TabIndex = 4
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdOk
        '
        Me.cmdOk.BackColor = System.Drawing.Color.LightGray
        Me.cmdOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOk.Location = New System.Drawing.Point(460, 19)
        Me.cmdOk.Name = "cmdOk"
        Me.cmdOk.Size = New System.Drawing.Size(71, 35)
        Me.cmdOk.TabIndex = 3
        Me.cmdOk.Text = "&Ok"
        Me.cmdOk.UseVisualStyleBackColor = False
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.LightGray
        Me.cmdAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAdd.Location = New System.Drawing.Point(106, 19)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(71, 35)
        Me.cmdAdd.TabIndex = 2
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'cmdReport
        '
        Me.cmdReport.BackColor = System.Drawing.Color.LightGray
        Me.cmdReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdReport.Location = New System.Drawing.Point(16, 19)
        Me.cmdReport.Name = "cmdReport"
        Me.cmdReport.Size = New System.Drawing.Size(71, 35)
        Me.cmdReport.TabIndex = 1
        Me.cmdReport.Text = "&Report"
        Me.cmdReport.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.LightGray
        Me.cmdEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdEdit.Location = New System.Drawing.Point(183, 19)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(71, 35)
        Me.cmdEdit.TabIndex = 0
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'lblAccountHeader
        '
        Me.lblAccountHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lblAccountHeader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAccountHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccountHeader.Location = New System.Drawing.Point(10, 9)
        Me.lblAccountHeader.Name = "lblAccountHeader"
        Me.lblAccountHeader.Size = New System.Drawing.Size(716, 27)
        Me.lblAccountHeader.TabIndex = 12
        Me.lblAccountHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblAccountHeader.UseMnemonic = False
        '
        'AxCrystalReport2
        '
        Me.AxCrystalReport2.Enabled = True
        Me.AxCrystalReport2.Location = New System.Drawing.Point(0, 0)
        Me.AxCrystalReport2.Name = "AxCrystalReport2"
        Me.AxCrystalReport2.OcxState = CType(resources.GetObject("AxCrystalReport2.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxCrystalReport2.Size = New System.Drawing.Size(28, 28)
        Me.AxCrystalReport2.TabIndex = 13
        '
        'frmFinanceStatement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ClientSize = New System.Drawing.Size(737, 597)
        Me.ControlBox = False
        Me.Controls.Add(Me.AxCrystalReport2)
        Me.Controls.Add(Me.lblAccountHeader)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmFinanceStatement"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Finance Statement"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.grpBankAccounts.ResumeLayout(False)
        Me.grpBankAccounts.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.grpCreditCards.ResumeLayout(False)
        Me.grpCreditCards.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.grpToPayToCome.ResumeLayout(False)
        Me.grpToPayToCome.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.grpAquavista.ResumeLayout(False)
        Me.grpAquavista.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.grpMortgages.ResumeLayout(False)
        Me.grpMortgages.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.AxCrystalReport2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents grpBankAccounts As System.Windows.Forms.GroupBox
    Friend WithEvents txtCcy0 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtTotal0 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance8 As System.Windows.Forms.TextBox
    Friend WithEvents txtName8 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo8 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance7 As System.Windows.Forms.TextBox
    Friend WithEvents txtName7 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo7 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance6 As System.Windows.Forms.TextBox
    Friend WithEvents txtName6 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo6 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance5 As System.Windows.Forms.TextBox
    Friend WithEvents txtName5 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo5 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance4 As System.Windows.Forms.TextBox
    Friend WithEvents txtName4 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo4 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance3 As System.Windows.Forms.TextBox
    Friend WithEvents txtName3 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo3 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance2 As System.Windows.Forms.TextBox
    Friend WithEvents txtName2 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo2 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance1 As System.Windows.Forms.TextBox
    Friend WithEvents txtName1 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo1 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdOk As System.Windows.Forms.Button
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents cmdReport As System.Windows.Forms.Button
    Friend WithEvents lblAccountHeader As System.Windows.Forms.Label
    Friend WithEvents grpCreditCards As System.Windows.Forms.GroupBox
    Friend WithEvents txtCcy1 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal1 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate16 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd16 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate16 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt16 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance16 As System.Windows.Forms.TextBox
    Friend WithEvents txtName16 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo16 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate15 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd15 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate15 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt15 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance15 As System.Windows.Forms.TextBox
    Friend WithEvents txtName15 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo15 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate14 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd14 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate14 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt14 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance14 As System.Windows.Forms.TextBox
    Friend WithEvents txtName14 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo14 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate13 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd13 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate13 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt13 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance13 As System.Windows.Forms.TextBox
    Friend WithEvents txtName13 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo13 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate12 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd12 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate12 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt12 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance12 As System.Windows.Forms.TextBox
    Friend WithEvents txtName12 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo12 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate11 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd11 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate11 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt11 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance11 As System.Windows.Forms.TextBox
    Friend WithEvents txtName11 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo11 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate10 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd10 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate10 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt10 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance10 As System.Windows.Forms.TextBox
    Friend WithEvents txtName10 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo10 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate9 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd9 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate9 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt9 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance9 As System.Windows.Forms.TextBox
    Friend WithEvents txtName9 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo9 As System.Windows.Forms.TextBox
    Friend WithEvents AxCrystalReport2 As AxCrystal.AxCrystalReport
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox65 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox66 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox67 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox68 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox69 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox70 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox71 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox72 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox73 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents grpAquavista As System.Windows.Forms.GroupBox
    Friend WithEvents grpToPayToCome As System.Windows.Forms.GroupBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtDueDate22 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance22 As System.Windows.Forms.TextBox
    Friend WithEvents txtName22 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo22 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate21 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance21 As System.Windows.Forms.TextBox
    Friend WithEvents txtName21 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo21 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate20 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance20 As System.Windows.Forms.TextBox
    Friend WithEvents txtName20 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo20 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate19 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance19 As System.Windows.Forms.TextBox
    Friend WithEvents txtName19 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo19 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate18 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance18 As System.Windows.Forms.TextBox
    Friend WithEvents txtName18 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo18 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate17 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance17 As System.Windows.Forms.TextBox
    Friend WithEvents txtName17 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo17 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtDueDate37 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance37 As System.Windows.Forms.TextBox
    Friend WithEvents txtName37 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo37 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate36 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance36 As System.Windows.Forms.TextBox
    Friend WithEvents txtName36 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo36 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate35 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance35 As System.Windows.Forms.TextBox
    Friend WithEvents txtName35 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo35 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate34 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance34 As System.Windows.Forms.TextBox
    Friend WithEvents txtName34 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo34 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate33 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance33 As System.Windows.Forms.TextBox
    Friend WithEvents txtName33 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo33 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate32 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance32 As System.Windows.Forms.TextBox
    Friend WithEvents txtName32 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo32 As System.Windows.Forms.TextBox
    Friend WithEvents txtCcy4 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance31 As System.Windows.Forms.TextBox
    Friend WithEvents txtName31 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo31 As System.Windows.Forms.TextBox
    Friend WithEvents txtCcy3 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance30 As System.Windows.Forms.TextBox
    Friend WithEvents txtName30 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo30 As System.Windows.Forms.TextBox
    Friend WithEvents grpMortgages As System.Windows.Forms.GroupBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtRate39 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd39 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate39 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt39 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate38 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd38 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate38 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt38 As System.Windows.Forms.TextBox
    Friend WithEvents txtCcy5 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtBalance39 As System.Windows.Forms.TextBox
    Friend WithEvents txtName39 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo39 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance38 As System.Windows.Forms.TextBox
    Friend WithEvents txtName38 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo38 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTotal4 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal3 As System.Windows.Forms.TextBox
    Friend WithEvents txtRateX As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEndX As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDateX As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymtX As System.Windows.Forms.TextBox
    Friend WithEvents txtBalanceX As System.Windows.Forms.TextBox
    Friend WithEvents txtNameX As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNoX As System.Windows.Forms.TextBox
    Friend WithEvents txtCcyX As System.Windows.Forms.TextBox
    Friend WithEvents lblDeleteRow As System.Windows.Forms.Label
    Friend WithEvents txtRate40 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd40 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate40 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt40 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance40 As System.Windows.Forms.TextBox
    Friend WithEvents txtName40 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo40 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate41 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd41 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate41 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt41 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance41 As System.Windows.Forms.TextBox
    Friend WithEvents txtName41 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo41 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate43 As System.Windows.Forms.TextBox
    Friend WithEvents txtRate42 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd43 As System.Windows.Forms.TextBox
    Friend WithEvents txtZeropcEnd42 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate43 As System.Windows.Forms.TextBox
    Friend WithEvents txtDueDate42 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt43 As System.Windows.Forms.TextBox
    Friend WithEvents txtMinPymt42 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance43 As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance42 As System.Windows.Forms.TextBox
    Friend WithEvents txtName43 As System.Windows.Forms.TextBox
    Friend WithEvents txtName42 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo43 As System.Windows.Forms.TextBox
    Friend WithEvents txtAcctNo42 As System.Windows.Forms.TextBox
End Class
