﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAux
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAux))
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdOk = New System.Windows.Forms.Button()
        Me.cmdReport = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdChange = New System.Windows.Forms.Button()
        Me.cmdSaveQuery = New System.Windows.Forms.Button()
        Me.cmdView = New System.Windows.Forms.Button()
        Me.CmdAdd = New System.Windows.Forms.Button()
        Me.CmdDelete = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.FldList = New System.Windows.Forms.ListBox()
        Me.TblList = New System.Windows.Forms.ListBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txtSQLDisp = New System.Windows.Forms.TextBox()
        Me.txtSQL = New System.Windows.Forms.TextBox()
        Me.QryList = New System.Windows.Forms.ListBox()
        Me.VideoQryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VideoDataSet1 = New VPBS13.VIDEODataSet1()
        Me.BooksDataGridView = New System.Windows.Forms.DataGridView()
        Me.ID1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TitleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MediaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CategoryDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AuthorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PublisherDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LocationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReadByDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReportTitleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BooksDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BooksDataSet1 = New VPBS13.BOOKSDataSet1()
        Me.VideoDataGridView = New System.Windows.Forms.DataGridView()
        Me.TapeIdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DescriptionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MediaDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CategoryDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ArtistDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TimeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalTimeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReportTitleDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VideoDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LifeLineDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LifeLineDataSet1 = New VPBS13.LifeLineDataSet1()
        Me.AddressesDataGridView = New System.Windows.Forms.DataGridView()
        Me.CustNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TitleDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TownDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CountyDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PostCodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhoneDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailAddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InterestDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SourceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AmountDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateOfLastContactDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateOfNextContactDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CompanyNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NotesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SalutationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastMailedDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NextMailedDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CampaignDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReportTitleDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AxCrystalReport1 = New AxCrystal.AxCrystalReport()
        Me.txtQryName = New System.Windows.Forms.TextBox()
        Me.RptTempTableAdapterV = New VPBS13.VIDEODataSet1TableAdapters.RptTempTableAdapter()
        Me.VideoTableAdapter = New VPBS13.VIDEODataSet1TableAdapters.VIDEO3TableAdapter()
        Me.Prospects___COITableAdapter = New VPBS13.LifeLineDataSet1TableAdapters.Prospects___COITableAdapter()
        Me.QryVideoTableAdapter = New VPBS13.VIDEODataSet1TableAdapters.qryVideoTableAdapter()
        Me.LifelineQryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.QryLifelineTableAdapter = New VPBS13.LifeLineDataSet1TableAdapters.qryLifelineTableAdapter()
        Me.SharpTableAdapter = New VPBS13.LifeLineDataSet1TableAdapters.SharpTableAdapter()
        Me.Prospects___ex_HiltonTableAdapter = New VPBS13.LifeLineDataSet1TableAdapters.Prospects___ex_HiltonTableAdapter()
        Me.SharpDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.AddressesSharpDataGridView = New System.Windows.Forms.DataGridView()
        Me.CategoryDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastNameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstNameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TitleDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CompanyDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Address1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Address2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TownDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CountyDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PostcodeDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CountryDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HomeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OfficeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MobileDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NoteDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ChristmascardDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReportTitleDataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BooksQryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.QryBooksTableAdapter = New VPBS13.BOOKSDataSet1TableAdapters.qryBooksTableAdapter()
        Me.BooksTableAdapter = New VPBS13.BOOKSDataSet1TableAdapters.BooksTableAdapter()
        Me.RptTempTableAdapterB = New VPBS13.BOOKSDataSet1TableAdapters.RptTempTableAdapter()
        Me.GroupBoxBooks = New System.Windows.Forms.GroupBox()
        Me.cboLocation = New System.Windows.Forms.ComboBox()
        Me.cboCategory = New System.Windows.Forms.ComboBox()
        Me.txtPublisher = New System.Windows.Forms.TextBox()
        Me.lblPublisher = New System.Windows.Forms.Label()
        Me.txtReadby = New System.Windows.Forms.TextBox()
        Me.txtAuthor = New System.Windows.Forms.TextBox()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.lblReadby = New System.Windows.Forms.Label()
        Me.lblLocation = New System.Windows.Forms.Label()
        Me.lblAuthor = New System.Windows.Forms.Label()
        Me.lblCategory = New System.Windows.Forms.Label()
        Me.lblMedia = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.cboMedia = New System.Windows.Forms.ComboBox()
        Me.GroupBoxSaveQuery = New System.Windows.Forms.GroupBox()
        Me.txtQueryName = New System.Windows.Forms.TextBox()
        Me.lblSaveQueryName = New System.Windows.Forms.Label()
        Me.GroupBoxVideos = New System.Windows.Forms.GroupBox()
        Me.txtTime = New System.Windows.Forms.TextBox()
        Me.txtArtist = New System.Windows.Forms.TextBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtTapeID = New System.Windows.Forms.TextBox()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.lblArtist = New System.Windows.Forms.Label()
        Me.lblVideoCategory = New System.Windows.Forms.Label()
        Me.lblVideoMedia = New System.Windows.Forms.Label()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.lblTapeID = New System.Windows.Forms.Label()
        Me.cboVideoCategory = New System.Windows.Forms.ComboBox()
        Me.cboVideoMedia = New System.Windows.Forms.ComboBox()
        Me.GroupBoxAddress = New System.Windows.Forms.GroupBox()
        Me.txtCountry = New System.Windows.Forms.TextBox()
        Me.lblCountry = New System.Windows.Forms.Label()
        Me.txtTown = New System.Windows.Forms.TextBox()
        Me.lblAddress2 = New System.Windows.Forms.Label()
        Me.txtOfficePhone = New System.Windows.Forms.TextBox()
        Me.lblOfficePhone = New System.Windows.Forms.Label()
        Me.txtMobilePhone = New System.Windows.Forms.TextBox()
        Me.lblMobile = New System.Windows.Forms.Label()
        Me.txtHomePhone = New System.Windows.Forms.TextBox()
        Me.txtAddressTitle = New System.Windows.Forms.TextBox()
        Me.txtStatus = New System.Windows.Forms.TextBox()
        Me.lblNotes = New System.Windows.Forms.Label()
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.txtCompany = New System.Windows.Forms.TextBox()
        Me.lblCompany = New System.Windows.Forms.Label()
        Me.lblCard = New System.Windows.Forms.Label()
        Me.txtCounty = New System.Windows.Forms.TextBox()
        Me.txtCard = New System.Windows.Forms.TextBox()
        Me.lblCounty = New System.Windows.Forms.Label()
        Me.txtPostCode = New System.Windows.Forms.TextBox()
        Me.lblPostCode = New System.Windows.Forms.Label()
        Me.txtAddress2 = New System.Windows.Forms.TextBox()
        Me.lblTown = New System.Windows.Forms.Label()
        Me.lblAddress1 = New System.Windows.Forms.Label()
        Me.txtAddress1 = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtSource = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtCustID = New System.Windows.Forms.TextBox()
        Me.lblSource = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblAdressTitle = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblCustID = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.VideoQryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VideoDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BooksDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BooksDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BooksDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VideoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VideoDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LifeLineDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LifeLineDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AddressesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxCrystalReport1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LifelineQryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SharpDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AddressesSharpDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BooksQryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxBooks.SuspendLayout()
        Me.GroupBoxSaveQuery.SuspendLayout()
        Me.GroupBoxVideos.SuspendLayout()
        Me.GroupBoxAddress.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.cmdCancel)
        Me.GroupBox1.Controls.Add(Me.cmdOk)
        Me.GroupBox1.Controls.Add(Me.cmdReport)
        Me.GroupBox1.Controls.Add(Me.cmdClose)
        Me.GroupBox1.Controls.Add(Me.cmdChange)
        Me.GroupBox1.Controls.Add(Me.cmdSaveQuery)
        Me.GroupBox1.Controls.Add(Me.cmdView)
        Me.GroupBox1.Controls.Add(Me.CmdAdd)
        Me.GroupBox1.Controls.Add(Me.CmdDelete)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 583)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(808, 67)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.LightGray
        Me.cmdCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.Location = New System.Drawing.Point(634, 19)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(80, 35)
        Me.cmdCancel.TabIndex = 17
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdOk
        '
        Me.cmdOk.BackColor = System.Drawing.Color.LightGray
        Me.cmdOk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOk.Location = New System.Drawing.Point(548, 19)
        Me.cmdOk.Name = "cmdOk"
        Me.cmdOk.Size = New System.Drawing.Size(80, 35)
        Me.cmdOk.TabIndex = 16
        Me.cmdOk.Text = "&Ok"
        Me.cmdOk.UseVisualStyleBackColor = False
        '
        'cmdReport
        '
        Me.cmdReport.BackColor = System.Drawing.Color.LightGray
        Me.cmdReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdReport.Location = New System.Drawing.Point(12, 19)
        Me.cmdReport.Name = "cmdReport"
        Me.cmdReport.Size = New System.Drawing.Size(80, 35)
        Me.cmdReport.TabIndex = 15
        Me.cmdReport.Text = "&Report"
        Me.cmdReport.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.Color.LightGray
        Me.cmdClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.Location = New System.Drawing.Point(720, 19)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(80, 35)
        Me.cmdClose.TabIndex = 7
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdChange
        '
        Me.cmdChange.BackColor = System.Drawing.Color.LightGray
        Me.cmdChange.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdChange.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdChange.Location = New System.Drawing.Point(376, 19)
        Me.cmdChange.Name = "cmdChange"
        Me.cmdChange.Size = New System.Drawing.Size(80, 35)
        Me.cmdChange.TabIndex = 14
        Me.cmdChange.Text = "&Change"
        Me.cmdChange.UseVisualStyleBackColor = False
        '
        'cmdSaveQuery
        '
        Me.cmdSaveQuery.BackColor = System.Drawing.Color.LightGray
        Me.cmdSaveQuery.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdSaveQuery.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveQuery.Location = New System.Drawing.Point(194, 19)
        Me.cmdSaveQuery.Name = "cmdSaveQuery"
        Me.cmdSaveQuery.Size = New System.Drawing.Size(90, 35)
        Me.cmdSaveQuery.TabIndex = 6
        Me.cmdSaveQuery.Text = "&Save Query"
        Me.cmdSaveQuery.UseVisualStyleBackColor = False
        '
        'cmdView
        '
        Me.cmdView.BackColor = System.Drawing.Color.LightGray
        Me.cmdView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdView.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdView.Location = New System.Drawing.Point(98, 19)
        Me.cmdView.Name = "cmdView"
        Me.cmdView.Size = New System.Drawing.Size(90, 35)
        Me.cmdView.TabIndex = 5
        Me.cmdView.Text = "&View Query"
        Me.cmdView.UseVisualStyleBackColor = False
        '
        'CmdAdd
        '
        Me.CmdAdd.BackColor = System.Drawing.Color.LightGray
        Me.CmdAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdAdd.Location = New System.Drawing.Point(290, 19)
        Me.CmdAdd.Name = "CmdAdd"
        Me.CmdAdd.Size = New System.Drawing.Size(80, 35)
        Me.CmdAdd.TabIndex = 4
        Me.CmdAdd.Text = "&Add"
        Me.CmdAdd.UseVisualStyleBackColor = False
        '
        'CmdDelete
        '
        Me.CmdDelete.BackColor = System.Drawing.Color.LightGray
        Me.CmdDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdDelete.Location = New System.Drawing.Point(462, 19)
        Me.CmdDelete.Name = "CmdDelete"
        Me.CmdDelete.Size = New System.Drawing.Size(80, 35)
        Me.CmdDelete.TabIndex = 1
        Me.CmdDelete.Text = "&Delete"
        Me.CmdDelete.UseVisualStyleBackColor = False
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(12, 7)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(808, 108)
        Me.TabControl1.TabIndex = 22
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage1.Controls.Add(Me.FldList)
        Me.TabPage1.Controls.Add(Me.TblList)
        Me.TabPage1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 28)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(800, 76)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tables                    "
        '
        'FldList
        '
        Me.FldList.FormattingEnabled = True
        Me.FldList.ItemHeight = 16
        Me.FldList.Location = New System.Drawing.Point(337, 2)
        Me.FldList.Name = "FldList"
        Me.FldList.Size = New System.Drawing.Size(453, 68)
        Me.FldList.TabIndex = 2
        '
        'TblList
        '
        Me.TblList.FormattingEnabled = True
        Me.TblList.ItemHeight = 16
        Me.TblList.Location = New System.Drawing.Point(6, 2)
        Me.TblList.Name = "TblList"
        Me.TblList.Size = New System.Drawing.Size(325, 68)
        Me.TblList.TabIndex = 1
        '
        'TabPage2
        '
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage2.Controls.Add(Me.txtSQLDisp)
        Me.TabPage2.Controls.Add(Me.txtSQL)
        Me.TabPage2.Controls.Add(Me.QryList)
        Me.TabPage2.Location = New System.Drawing.Point(4, 28)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(800, 76)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Queries                    "
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txtSQLDisp
        '
        Me.txtSQLDisp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSQLDisp.Location = New System.Drawing.Point(337, 29)
        Me.txtSQLDisp.Multiline = True
        Me.txtSQLDisp.Name = "txtSQLDisp"
        Me.txtSQLDisp.Size = New System.Drawing.Size(451, 68)
        Me.txtSQLDisp.TabIndex = 5
        '
        'txtSQL
        '
        Me.txtSQL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSQL.Location = New System.Drawing.Point(337, 2)
        Me.txtSQL.Multiline = True
        Me.txtSQL.Name = "txtSQL"
        Me.txtSQL.Size = New System.Drawing.Size(452, 68)
        Me.txtSQL.TabIndex = 4
        '
        'QryList
        '
        Me.QryList.DataSource = Me.VideoQryBindingSource
        Me.QryList.DisplayMember = "qryName"
        Me.QryList.FormattingEnabled = True
        Me.QryList.ItemHeight = 16
        Me.QryList.Location = New System.Drawing.Point(6, 2)
        Me.QryList.Name = "QryList"
        Me.QryList.Size = New System.Drawing.Size(325, 68)
        Me.QryList.TabIndex = 3
        Me.QryList.ValueMember = "Sql"
        '
        'VideoQryBindingSource
        '
        Me.VideoQryBindingSource.DataMember = "qryVideo"
        Me.VideoQryBindingSource.DataSource = Me.VideoDataSet1
        '
        'VideoDataSet1
        '
        Me.VideoDataSet1.DataSetName = "VIDEODataSet1"
        Me.VideoDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BooksDataGridView
        '
        Me.BooksDataGridView.AllowUserToAddRows = False
        Me.BooksDataGridView.AllowUserToDeleteRows = False
        Me.BooksDataGridView.AllowUserToResizeRows = False
        Me.BooksDataGridView.AutoGenerateColumns = False
        Me.BooksDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.BooksDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BooksDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.BooksDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BooksDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ID1DataGridViewTextBoxColumn, Me.TitleDataGridViewTextBoxColumn, Me.MediaDataGridViewTextBoxColumn, Me.CategoryDataGridViewTextBoxColumn, Me.AuthorDataGridViewTextBoxColumn, Me.PublisherDataGridViewTextBoxColumn, Me.LocationDataGridViewTextBoxColumn, Me.ReadByDataGridViewTextBoxColumn, Me.ReportTitleDataGridViewTextBoxColumn})
        Me.BooksDataGridView.DataSource = Me.BooksDataSetBindingSource
        Me.BooksDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.BooksDataGridView.Location = New System.Drawing.Point(12, 121)
        Me.BooksDataGridView.MultiSelect = False
        Me.BooksDataGridView.Name = "BooksDataGridView"
        Me.BooksDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.BooksDataGridView.Size = New System.Drawing.Size(808, 261)
        Me.BooksDataGridView.TabIndex = 23
        Me.BooksDataGridView.Visible = False
        '
        'ID1DataGridViewTextBoxColumn
        '
        Me.ID1DataGridViewTextBoxColumn.DataPropertyName = "ID1"
        Me.ID1DataGridViewTextBoxColumn.HeaderText = "ID1"
        Me.ID1DataGridViewTextBoxColumn.Name = "ID1DataGridViewTextBoxColumn"
        Me.ID1DataGridViewTextBoxColumn.ReadOnly = True
        Me.ID1DataGridViewTextBoxColumn.Width = 50
        '
        'TitleDataGridViewTextBoxColumn
        '
        Me.TitleDataGridViewTextBoxColumn.DataPropertyName = "Title"
        Me.TitleDataGridViewTextBoxColumn.HeaderText = "Title"
        Me.TitleDataGridViewTextBoxColumn.Name = "TitleDataGridViewTextBoxColumn"
        Me.TitleDataGridViewTextBoxColumn.Width = 150
        '
        'MediaDataGridViewTextBoxColumn
        '
        Me.MediaDataGridViewTextBoxColumn.DataPropertyName = "Media"
        Me.MediaDataGridViewTextBoxColumn.HeaderText = "Media"
        Me.MediaDataGridViewTextBoxColumn.Name = "MediaDataGridViewTextBoxColumn"
        Me.MediaDataGridViewTextBoxColumn.Width = 50
        '
        'CategoryDataGridViewTextBoxColumn
        '
        Me.CategoryDataGridViewTextBoxColumn.DataPropertyName = "Category"
        Me.CategoryDataGridViewTextBoxColumn.HeaderText = "Category"
        Me.CategoryDataGridViewTextBoxColumn.Name = "CategoryDataGridViewTextBoxColumn"
        '
        'AuthorDataGridViewTextBoxColumn
        '
        Me.AuthorDataGridViewTextBoxColumn.DataPropertyName = "Author"
        Me.AuthorDataGridViewTextBoxColumn.HeaderText = "Author"
        Me.AuthorDataGridViewTextBoxColumn.Name = "AuthorDataGridViewTextBoxColumn"
        Me.AuthorDataGridViewTextBoxColumn.Width = 150
        '
        'PublisherDataGridViewTextBoxColumn
        '
        Me.PublisherDataGridViewTextBoxColumn.DataPropertyName = "Publisher"
        Me.PublisherDataGridViewTextBoxColumn.HeaderText = "Publisher"
        Me.PublisherDataGridViewTextBoxColumn.Name = "PublisherDataGridViewTextBoxColumn"
        '
        'LocationDataGridViewTextBoxColumn
        '
        Me.LocationDataGridViewTextBoxColumn.DataPropertyName = "Location"
        Me.LocationDataGridViewTextBoxColumn.HeaderText = "Location"
        Me.LocationDataGridViewTextBoxColumn.Name = "LocationDataGridViewTextBoxColumn"
        '
        'ReadByDataGridViewTextBoxColumn
        '
        Me.ReadByDataGridViewTextBoxColumn.DataPropertyName = "ReadBy"
        Me.ReadByDataGridViewTextBoxColumn.HeaderText = "ReadBy"
        Me.ReadByDataGridViewTextBoxColumn.Name = "ReadByDataGridViewTextBoxColumn"
        Me.ReadByDataGridViewTextBoxColumn.Width = 60
        '
        'ReportTitleDataGridViewTextBoxColumn
        '
        Me.ReportTitleDataGridViewTextBoxColumn.DataPropertyName = "ReportTitle"
        Me.ReportTitleDataGridViewTextBoxColumn.HeaderText = "ReportTitle"
        Me.ReportTitleDataGridViewTextBoxColumn.Name = "ReportTitleDataGridViewTextBoxColumn"
        '
        'BooksDataSetBindingSource
        '
        Me.BooksDataSetBindingSource.DataMember = "Books"
        Me.BooksDataSetBindingSource.DataSource = Me.BooksDataSet1
        Me.BooksDataSetBindingSource.Filter = ""
        Me.BooksDataSetBindingSource.Sort = ""
        '
        'BooksDataSet1
        '
        Me.BooksDataSet1.DataSetName = "BOOKSDataSet1"
        Me.BooksDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VideoDataGridView
        '
        Me.VideoDataGridView.AllowUserToAddRows = False
        Me.VideoDataGridView.AllowUserToDeleteRows = False
        Me.VideoDataGridView.AllowUserToResizeRows = False
        Me.VideoDataGridView.AutoGenerateColumns = False
        Me.VideoDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.VideoDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.VideoDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.VideoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.VideoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.TapeIdDataGridViewTextBoxColumn, Me.DescriptionDataGridViewTextBoxColumn, Me.MediaDataGridViewTextBoxColumn1, Me.CategoryDataGridViewTextBoxColumn1, Me.ArtistDataGridViewTextBoxColumn, Me.TimeDataGridViewTextBoxColumn, Me.TotalTimeDataGridViewTextBoxColumn, Me.ReportTitleDataGridViewTextBoxColumn1})
        Me.VideoDataGridView.DataSource = Me.VideoDataSetBindingSource
        Me.VideoDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.VideoDataGridView.Location = New System.Drawing.Point(12, 121)
        Me.VideoDataGridView.MultiSelect = False
        Me.VideoDataGridView.Name = "VideoDataGridView"
        Me.VideoDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.VideoDataGridView.Size = New System.Drawing.Size(808, 261)
        Me.VideoDataGridView.TabIndex = 24
        Me.VideoDataGridView.Visible = False
        '
        'TapeIdDataGridViewTextBoxColumn
        '
        Me.TapeIdDataGridViewTextBoxColumn.DataPropertyName = "Tape Id"
        Me.TapeIdDataGridViewTextBoxColumn.HeaderText = "Tape Id"
        Me.TapeIdDataGridViewTextBoxColumn.Name = "TapeIdDataGridViewTextBoxColumn"
        '
        'DescriptionDataGridViewTextBoxColumn
        '
        Me.DescriptionDataGridViewTextBoxColumn.DataPropertyName = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.HeaderText = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.Name = "DescriptionDataGridViewTextBoxColumn"
        '
        'MediaDataGridViewTextBoxColumn1
        '
        Me.MediaDataGridViewTextBoxColumn1.DataPropertyName = "Media"
        Me.MediaDataGridViewTextBoxColumn1.HeaderText = "Media"
        Me.MediaDataGridViewTextBoxColumn1.Name = "MediaDataGridViewTextBoxColumn1"
        '
        'CategoryDataGridViewTextBoxColumn1
        '
        Me.CategoryDataGridViewTextBoxColumn1.DataPropertyName = "Category"
        Me.CategoryDataGridViewTextBoxColumn1.HeaderText = "Category"
        Me.CategoryDataGridViewTextBoxColumn1.Name = "CategoryDataGridViewTextBoxColumn1"
        '
        'ArtistDataGridViewTextBoxColumn
        '
        Me.ArtistDataGridViewTextBoxColumn.DataPropertyName = "Artist"
        Me.ArtistDataGridViewTextBoxColumn.HeaderText = "Artist"
        Me.ArtistDataGridViewTextBoxColumn.Name = "ArtistDataGridViewTextBoxColumn"
        '
        'TimeDataGridViewTextBoxColumn
        '
        Me.TimeDataGridViewTextBoxColumn.DataPropertyName = "Time"
        Me.TimeDataGridViewTextBoxColumn.HeaderText = "Time"
        Me.TimeDataGridViewTextBoxColumn.Name = "TimeDataGridViewTextBoxColumn"
        '
        'TotalTimeDataGridViewTextBoxColumn
        '
        Me.TotalTimeDataGridViewTextBoxColumn.DataPropertyName = "Total Time"
        Me.TotalTimeDataGridViewTextBoxColumn.HeaderText = "Total Time"
        Me.TotalTimeDataGridViewTextBoxColumn.Name = "TotalTimeDataGridViewTextBoxColumn"
        '
        'ReportTitleDataGridViewTextBoxColumn1
        '
        Me.ReportTitleDataGridViewTextBoxColumn1.DataPropertyName = "ReportTitle"
        Me.ReportTitleDataGridViewTextBoxColumn1.HeaderText = "ReportTitle"
        Me.ReportTitleDataGridViewTextBoxColumn1.Name = "ReportTitleDataGridViewTextBoxColumn1"
        '
        'VideoDataSetBindingSource
        '
        Me.VideoDataSetBindingSource.DataMember = "VIDEO3"
        Me.VideoDataSetBindingSource.DataSource = Me.VideoDataSet1
        '
        'LifeLineDataSetBindingSource
        '
        Me.LifeLineDataSetBindingSource.DataMember = "Prospects - COI"
        Me.LifeLineDataSetBindingSource.DataSource = Me.LifeLineDataSet1
        '
        'LifeLineDataSet1
        '
        Me.LifeLineDataSet1.DataSetName = "LifeLineDataSet1"
        Me.LifeLineDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AddressesDataGridView
        '
        Me.AddressesDataGridView.AllowUserToAddRows = False
        Me.AddressesDataGridView.AllowUserToDeleteRows = False
        Me.AddressesDataGridView.AllowUserToResizeRows = False
        Me.AddressesDataGridView.AutoGenerateColumns = False
        Me.AddressesDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.AddressesDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AddressesDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.AddressesDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CustNoDataGridViewTextBoxColumn, Me.LastNameDataGridViewTextBoxColumn, Me.FirstNameDataGridViewTextBoxColumn, Me.TitleDataGridViewTextBoxColumn1, Me.AddressDataGridViewTextBoxColumn, Me.TownDataGridViewTextBoxColumn, Me.CountyDataGridViewTextBoxColumn, Me.PostCodeDataGridViewTextBoxColumn, Me.PhoneDataGridViewTextBoxColumn, Me.EmailAddressDataGridViewTextBoxColumn, Me.InterestDataGridViewTextBoxColumn, Me.SourceDataGridViewTextBoxColumn, Me.AmountDataGridViewTextBoxColumn, Me.DateOfLastContactDataGridViewTextBoxColumn, Me.DateOfNextContactDataGridViewTextBoxColumn, Me.StatusDataGridViewTextBoxColumn, Me.CompanyNameDataGridViewTextBoxColumn, Me.NotesDataGridViewTextBoxColumn, Me.SalutationDataGridViewTextBoxColumn, Me.LastMailedDateDataGridViewTextBoxColumn, Me.NextMailedDateDataGridViewTextBoxColumn, Me.CampaignDataGridViewTextBoxColumn, Me.ReportTitleDataGridViewTextBoxColumn2})
        Me.AddressesDataGridView.DataSource = Me.LifeLineDataSetBindingSource
        Me.AddressesDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.AddressesDataGridView.Location = New System.Drawing.Point(12, 121)
        Me.AddressesDataGridView.MultiSelect = False
        Me.AddressesDataGridView.Name = "AddressesDataGridView"
        Me.AddressesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.AddressesDataGridView.Size = New System.Drawing.Size(808, 261)
        Me.AddressesDataGridView.TabIndex = 25
        Me.AddressesDataGridView.Visible = False
        '
        'CustNoDataGridViewTextBoxColumn
        '
        Me.CustNoDataGridViewTextBoxColumn.DataPropertyName = "CustNo"
        Me.CustNoDataGridViewTextBoxColumn.HeaderText = "CustNo"
        Me.CustNoDataGridViewTextBoxColumn.Name = "CustNoDataGridViewTextBoxColumn"
        Me.CustNoDataGridViewTextBoxColumn.Width = 60
        '
        'LastNameDataGridViewTextBoxColumn
        '
        Me.LastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.HeaderText = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.Name = "LastNameDataGridViewTextBoxColumn"
        '
        'FirstNameDataGridViewTextBoxColumn
        '
        Me.FirstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.HeaderText = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.Name = "FirstNameDataGridViewTextBoxColumn"
        '
        'TitleDataGridViewTextBoxColumn1
        '
        Me.TitleDataGridViewTextBoxColumn1.DataPropertyName = "Title"
        Me.TitleDataGridViewTextBoxColumn1.HeaderText = "Title"
        Me.TitleDataGridViewTextBoxColumn1.Name = "TitleDataGridViewTextBoxColumn1"
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        Me.AddressDataGridViewTextBoxColumn.Width = 150
        '
        'TownDataGridViewTextBoxColumn
        '
        Me.TownDataGridViewTextBoxColumn.DataPropertyName = "Town"
        Me.TownDataGridViewTextBoxColumn.HeaderText = "Town"
        Me.TownDataGridViewTextBoxColumn.Name = "TownDataGridViewTextBoxColumn"
        '
        'CountyDataGridViewTextBoxColumn
        '
        Me.CountyDataGridViewTextBoxColumn.DataPropertyName = "County"
        Me.CountyDataGridViewTextBoxColumn.HeaderText = "County"
        Me.CountyDataGridViewTextBoxColumn.Name = "CountyDataGridViewTextBoxColumn"
        '
        'PostCodeDataGridViewTextBoxColumn
        '
        Me.PostCodeDataGridViewTextBoxColumn.DataPropertyName = "PostCode"
        Me.PostCodeDataGridViewTextBoxColumn.HeaderText = "PostCode"
        Me.PostCodeDataGridViewTextBoxColumn.Name = "PostCodeDataGridViewTextBoxColumn"
        '
        'PhoneDataGridViewTextBoxColumn
        '
        Me.PhoneDataGridViewTextBoxColumn.DataPropertyName = "Phone"
        Me.PhoneDataGridViewTextBoxColumn.HeaderText = "Phone"
        Me.PhoneDataGridViewTextBoxColumn.Name = "PhoneDataGridViewTextBoxColumn"
        '
        'EmailAddressDataGridViewTextBoxColumn
        '
        Me.EmailAddressDataGridViewTextBoxColumn.DataPropertyName = "Email address"
        Me.EmailAddressDataGridViewTextBoxColumn.HeaderText = "Email address"
        Me.EmailAddressDataGridViewTextBoxColumn.Name = "EmailAddressDataGridViewTextBoxColumn"
        '
        'InterestDataGridViewTextBoxColumn
        '
        Me.InterestDataGridViewTextBoxColumn.DataPropertyName = "Interest"
        Me.InterestDataGridViewTextBoxColumn.HeaderText = "Interest"
        Me.InterestDataGridViewTextBoxColumn.Name = "InterestDataGridViewTextBoxColumn"
        '
        'SourceDataGridViewTextBoxColumn
        '
        Me.SourceDataGridViewTextBoxColumn.DataPropertyName = "Source"
        Me.SourceDataGridViewTextBoxColumn.HeaderText = "Source"
        Me.SourceDataGridViewTextBoxColumn.Name = "SourceDataGridViewTextBoxColumn"
        '
        'AmountDataGridViewTextBoxColumn
        '
        Me.AmountDataGridViewTextBoxColumn.DataPropertyName = "Amount"
        Me.AmountDataGridViewTextBoxColumn.HeaderText = "Amount"
        Me.AmountDataGridViewTextBoxColumn.Name = "AmountDataGridViewTextBoxColumn"
        '
        'DateOfLastContactDataGridViewTextBoxColumn
        '
        Me.DateOfLastContactDataGridViewTextBoxColumn.DataPropertyName = "Date of last contact"
        Me.DateOfLastContactDataGridViewTextBoxColumn.HeaderText = "Date of last contact"
        Me.DateOfLastContactDataGridViewTextBoxColumn.Name = "DateOfLastContactDataGridViewTextBoxColumn"
        '
        'DateOfNextContactDataGridViewTextBoxColumn
        '
        Me.DateOfNextContactDataGridViewTextBoxColumn.DataPropertyName = "Date of next contact"
        Me.DateOfNextContactDataGridViewTextBoxColumn.HeaderText = "Date of next contact"
        Me.DateOfNextContactDataGridViewTextBoxColumn.Name = "DateOfNextContactDataGridViewTextBoxColumn"
        '
        'StatusDataGridViewTextBoxColumn
        '
        Me.StatusDataGridViewTextBoxColumn.DataPropertyName = "Status"
        Me.StatusDataGridViewTextBoxColumn.HeaderText = "Status"
        Me.StatusDataGridViewTextBoxColumn.Name = "StatusDataGridViewTextBoxColumn"
        '
        'CompanyNameDataGridViewTextBoxColumn
        '
        Me.CompanyNameDataGridViewTextBoxColumn.DataPropertyName = "CompanyName"
        Me.CompanyNameDataGridViewTextBoxColumn.HeaderText = "CompanyName"
        Me.CompanyNameDataGridViewTextBoxColumn.Name = "CompanyNameDataGridViewTextBoxColumn"
        '
        'NotesDataGridViewTextBoxColumn
        '
        Me.NotesDataGridViewTextBoxColumn.DataPropertyName = "Notes"
        Me.NotesDataGridViewTextBoxColumn.HeaderText = "Notes"
        Me.NotesDataGridViewTextBoxColumn.Name = "NotesDataGridViewTextBoxColumn"
        '
        'SalutationDataGridViewTextBoxColumn
        '
        Me.SalutationDataGridViewTextBoxColumn.DataPropertyName = "Salutation"
        Me.SalutationDataGridViewTextBoxColumn.HeaderText = "Salutation"
        Me.SalutationDataGridViewTextBoxColumn.Name = "SalutationDataGridViewTextBoxColumn"
        '
        'LastMailedDateDataGridViewTextBoxColumn
        '
        Me.LastMailedDateDataGridViewTextBoxColumn.DataPropertyName = "Last MailedDate"
        Me.LastMailedDateDataGridViewTextBoxColumn.HeaderText = "Last MailedDate"
        Me.LastMailedDateDataGridViewTextBoxColumn.Name = "LastMailedDateDataGridViewTextBoxColumn"
        '
        'NextMailedDateDataGridViewTextBoxColumn
        '
        Me.NextMailedDateDataGridViewTextBoxColumn.DataPropertyName = "Next MailedDate"
        Me.NextMailedDateDataGridViewTextBoxColumn.HeaderText = "Next MailedDate"
        Me.NextMailedDateDataGridViewTextBoxColumn.Name = "NextMailedDateDataGridViewTextBoxColumn"
        '
        'CampaignDataGridViewTextBoxColumn
        '
        Me.CampaignDataGridViewTextBoxColumn.DataPropertyName = "Campaign"
        Me.CampaignDataGridViewTextBoxColumn.HeaderText = "Campaign"
        Me.CampaignDataGridViewTextBoxColumn.Name = "CampaignDataGridViewTextBoxColumn"
        '
        'ReportTitleDataGridViewTextBoxColumn2
        '
        Me.ReportTitleDataGridViewTextBoxColumn2.DataPropertyName = "ReportTitle"
        Me.ReportTitleDataGridViewTextBoxColumn2.HeaderText = "ReportTitle"
        Me.ReportTitleDataGridViewTextBoxColumn2.Name = "ReportTitleDataGridViewTextBoxColumn2"
        '
        'AxCrystalReport1
        '
        Me.AxCrystalReport1.Enabled = True
        Me.AxCrystalReport1.Location = New System.Drawing.Point(0, 0)
        Me.AxCrystalReport1.Name = "AxCrystalReport1"
        Me.AxCrystalReport1.OcxState = CType(resources.GetObject("AxCrystalReport1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxCrystalReport1.Size = New System.Drawing.Size(28, 28)
        Me.AxCrystalReport1.TabIndex = 26
        '
        'txtQryName
        '
        Me.txtQryName.Location = New System.Drawing.Point(338, 0)
        Me.txtQryName.Name = "txtQryName"
        Me.txtQryName.Size = New System.Drawing.Size(138, 20)
        Me.txtQryName.TabIndex = 27
        Me.txtQryName.Visible = False
        '
        'RptTempTableAdapterV
        '
        Me.RptTempTableAdapterV.ClearBeforeFill = True
        '
        'VideoTableAdapter
        '
        Me.VideoTableAdapter.ClearBeforeFill = True
        '
        'Prospects___COITableAdapter
        '
        Me.Prospects___COITableAdapter.ClearBeforeFill = True
        '
        'QryVideoTableAdapter
        '
        Me.QryVideoTableAdapter.ClearBeforeFill = True
        '
        'LifelineQryBindingSource
        '
        Me.LifelineQryBindingSource.DataMember = "qryLifeline"
        Me.LifelineQryBindingSource.DataSource = Me.LifeLineDataSet1
        '
        'QryLifelineTableAdapter
        '
        Me.QryLifelineTableAdapter.ClearBeforeFill = True
        '
        'SharpTableAdapter
        '
        Me.SharpTableAdapter.ClearBeforeFill = True
        '
        'Prospects___ex_HiltonTableAdapter
        '
        Me.Prospects___ex_HiltonTableAdapter.ClearBeforeFill = True
        '
        'SharpDataSetBindingSource
        '
        Me.SharpDataSetBindingSource.DataMember = "Sharp"
        Me.SharpDataSetBindingSource.DataSource = Me.LifeLineDataSet1
        '
        'AddressesSharpDataGridView
        '
        Me.AddressesSharpDataGridView.AllowUserToAddRows = False
        Me.AddressesSharpDataGridView.AllowUserToDeleteRows = False
        Me.AddressesSharpDataGridView.AllowUserToResizeRows = False
        Me.AddressesSharpDataGridView.AutoGenerateColumns = False
        Me.AddressesSharpDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.AddressesSharpDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AddressesSharpDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.AddressesSharpDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.AddressesSharpDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CategoryDataGridViewTextBoxColumn2, Me.LastNameDataGridViewTextBoxColumn1, Me.FirstNameDataGridViewTextBoxColumn1, Me.TitleDataGridViewTextBoxColumn2, Me.CompanyDataGridViewTextBoxColumn, Me.Address1DataGridViewTextBoxColumn, Me.Address2DataGridViewTextBoxColumn, Me.TownDataGridViewTextBoxColumn1, Me.CountyDataGridViewTextBoxColumn1, Me.PostcodeDataGridViewTextBoxColumn1, Me.CountryDataGridViewTextBoxColumn, Me.HomeDataGridViewTextBoxColumn, Me.OfficeDataGridViewTextBoxColumn, Me.MobileDataGridViewTextBoxColumn, Me.EmailDataGridViewTextBoxColumn, Me.NoteDataGridViewTextBoxColumn, Me.ChristmascardDataGridViewTextBoxColumn, Me.ReportTitleDataGridViewTextBoxColumn3})
        Me.AddressesSharpDataGridView.DataSource = Me.SharpDataSetBindingSource
        Me.AddressesSharpDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.AddressesSharpDataGridView.Location = New System.Drawing.Point(12, 121)
        Me.AddressesSharpDataGridView.MultiSelect = False
        Me.AddressesSharpDataGridView.Name = "AddressesSharpDataGridView"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AddressesSharpDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.AddressesSharpDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.AddressesSharpDataGridView.Size = New System.Drawing.Size(808, 261)
        Me.AddressesSharpDataGridView.TabIndex = 28
        Me.AddressesSharpDataGridView.Visible = False
        '
        'CategoryDataGridViewTextBoxColumn2
        '
        Me.CategoryDataGridViewTextBoxColumn2.DataPropertyName = "Category"
        Me.CategoryDataGridViewTextBoxColumn2.HeaderText = "Category"
        Me.CategoryDataGridViewTextBoxColumn2.Name = "CategoryDataGridViewTextBoxColumn2"
        '
        'LastNameDataGridViewTextBoxColumn1
        '
        Me.LastNameDataGridViewTextBoxColumn1.DataPropertyName = "LastName"
        Me.LastNameDataGridViewTextBoxColumn1.HeaderText = "LastName"
        Me.LastNameDataGridViewTextBoxColumn1.Name = "LastNameDataGridViewTextBoxColumn1"
        '
        'FirstNameDataGridViewTextBoxColumn1
        '
        Me.FirstNameDataGridViewTextBoxColumn1.DataPropertyName = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn1.HeaderText = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn1.Name = "FirstNameDataGridViewTextBoxColumn1"
        '
        'TitleDataGridViewTextBoxColumn2
        '
        Me.TitleDataGridViewTextBoxColumn2.DataPropertyName = "Title"
        Me.TitleDataGridViewTextBoxColumn2.HeaderText = "Title"
        Me.TitleDataGridViewTextBoxColumn2.Name = "TitleDataGridViewTextBoxColumn2"
        '
        'CompanyDataGridViewTextBoxColumn
        '
        Me.CompanyDataGridViewTextBoxColumn.DataPropertyName = "Company"
        Me.CompanyDataGridViewTextBoxColumn.HeaderText = "Company"
        Me.CompanyDataGridViewTextBoxColumn.Name = "CompanyDataGridViewTextBoxColumn"
        '
        'Address1DataGridViewTextBoxColumn
        '
        Me.Address1DataGridViewTextBoxColumn.DataPropertyName = "Address1"
        Me.Address1DataGridViewTextBoxColumn.HeaderText = "Address1"
        Me.Address1DataGridViewTextBoxColumn.Name = "Address1DataGridViewTextBoxColumn"
        '
        'Address2DataGridViewTextBoxColumn
        '
        Me.Address2DataGridViewTextBoxColumn.DataPropertyName = "Address2"
        Me.Address2DataGridViewTextBoxColumn.HeaderText = "Address2"
        Me.Address2DataGridViewTextBoxColumn.Name = "Address2DataGridViewTextBoxColumn"
        '
        'TownDataGridViewTextBoxColumn1
        '
        Me.TownDataGridViewTextBoxColumn1.DataPropertyName = "Town"
        Me.TownDataGridViewTextBoxColumn1.HeaderText = "Town"
        Me.TownDataGridViewTextBoxColumn1.Name = "TownDataGridViewTextBoxColumn1"
        '
        'CountyDataGridViewTextBoxColumn1
        '
        Me.CountyDataGridViewTextBoxColumn1.DataPropertyName = "County"
        Me.CountyDataGridViewTextBoxColumn1.HeaderText = "County"
        Me.CountyDataGridViewTextBoxColumn1.Name = "CountyDataGridViewTextBoxColumn1"
        '
        'PostcodeDataGridViewTextBoxColumn1
        '
        Me.PostcodeDataGridViewTextBoxColumn1.DataPropertyName = "Postcode"
        Me.PostcodeDataGridViewTextBoxColumn1.HeaderText = "Postcode"
        Me.PostcodeDataGridViewTextBoxColumn1.Name = "PostcodeDataGridViewTextBoxColumn1"
        '
        'CountryDataGridViewTextBoxColumn
        '
        Me.CountryDataGridViewTextBoxColumn.DataPropertyName = "Country"
        Me.CountryDataGridViewTextBoxColumn.HeaderText = "Country"
        Me.CountryDataGridViewTextBoxColumn.Name = "CountryDataGridViewTextBoxColumn"
        '
        'HomeDataGridViewTextBoxColumn
        '
        Me.HomeDataGridViewTextBoxColumn.DataPropertyName = "Home#"
        Me.HomeDataGridViewTextBoxColumn.HeaderText = "Home#"
        Me.HomeDataGridViewTextBoxColumn.Name = "HomeDataGridViewTextBoxColumn"
        '
        'OfficeDataGridViewTextBoxColumn
        '
        Me.OfficeDataGridViewTextBoxColumn.DataPropertyName = "Office#"
        Me.OfficeDataGridViewTextBoxColumn.HeaderText = "Office#"
        Me.OfficeDataGridViewTextBoxColumn.Name = "OfficeDataGridViewTextBoxColumn"
        '
        'MobileDataGridViewTextBoxColumn
        '
        Me.MobileDataGridViewTextBoxColumn.DataPropertyName = "Mobile#"
        Me.MobileDataGridViewTextBoxColumn.HeaderText = "Mobile#"
        Me.MobileDataGridViewTextBoxColumn.Name = "MobileDataGridViewTextBoxColumn"
        '
        'EmailDataGridViewTextBoxColumn
        '
        Me.EmailDataGridViewTextBoxColumn.DataPropertyName = "E-mail"
        Me.EmailDataGridViewTextBoxColumn.HeaderText = "E-mail"
        Me.EmailDataGridViewTextBoxColumn.Name = "EmailDataGridViewTextBoxColumn"
        '
        'NoteDataGridViewTextBoxColumn
        '
        Me.NoteDataGridViewTextBoxColumn.DataPropertyName = "Note"
        Me.NoteDataGridViewTextBoxColumn.HeaderText = "Note"
        Me.NoteDataGridViewTextBoxColumn.Name = "NoteDataGridViewTextBoxColumn"
        '
        'ChristmascardDataGridViewTextBoxColumn
        '
        Me.ChristmascardDataGridViewTextBoxColumn.DataPropertyName = "Christmascard"
        Me.ChristmascardDataGridViewTextBoxColumn.HeaderText = "Christmascard"
        Me.ChristmascardDataGridViewTextBoxColumn.Name = "ChristmascardDataGridViewTextBoxColumn"
        '
        'ReportTitleDataGridViewTextBoxColumn3
        '
        Me.ReportTitleDataGridViewTextBoxColumn3.DataPropertyName = "ReportTitle"
        Me.ReportTitleDataGridViewTextBoxColumn3.HeaderText = "ReportTitle"
        Me.ReportTitleDataGridViewTextBoxColumn3.Name = "ReportTitleDataGridViewTextBoxColumn3"
        '
        'BooksQryBindingSource
        '
        Me.BooksQryBindingSource.DataMember = "qryBooks"
        Me.BooksQryBindingSource.DataSource = Me.BooksDataSet1
        '
        'QryBooksTableAdapter
        '
        Me.QryBooksTableAdapter.ClearBeforeFill = True
        '
        'BooksTableAdapter
        '
        Me.BooksTableAdapter.ClearBeforeFill = True
        '
        'RptTempTableAdapterB
        '
        Me.RptTempTableAdapterB.ClearBeforeFill = True
        '
        'GroupBoxBooks
        '
        Me.GroupBoxBooks.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBoxBooks.Controls.Add(Me.cboLocation)
        Me.GroupBoxBooks.Controls.Add(Me.cboCategory)
        Me.GroupBoxBooks.Controls.Add(Me.txtPublisher)
        Me.GroupBoxBooks.Controls.Add(Me.lblPublisher)
        Me.GroupBoxBooks.Controls.Add(Me.txtReadby)
        Me.GroupBoxBooks.Controls.Add(Me.txtAuthor)
        Me.GroupBoxBooks.Controls.Add(Me.txtTitle)
        Me.GroupBoxBooks.Controls.Add(Me.txtID)
        Me.GroupBoxBooks.Controls.Add(Me.lblReadby)
        Me.GroupBoxBooks.Controls.Add(Me.lblLocation)
        Me.GroupBoxBooks.Controls.Add(Me.lblAuthor)
        Me.GroupBoxBooks.Controls.Add(Me.lblCategory)
        Me.GroupBoxBooks.Controls.Add(Me.lblMedia)
        Me.GroupBoxBooks.Controls.Add(Me.lblTitle)
        Me.GroupBoxBooks.Controls.Add(Me.lblID)
        Me.GroupBoxBooks.Controls.Add(Me.cboMedia)
        Me.GroupBoxBooks.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxBooks.Location = New System.Drawing.Point(12, 388)
        Me.GroupBoxBooks.Name = "GroupBoxBooks"
        Me.GroupBoxBooks.Size = New System.Drawing.Size(808, 126)
        Me.GroupBoxBooks.TabIndex = 29
        Me.GroupBoxBooks.TabStop = False
        Me.GroupBoxBooks.Text = "Books"
        Me.GroupBoxBooks.Visible = False
        '
        'cboLocation
        '
        Me.cboLocation.FormattingEnabled = True
        Me.cboLocation.Location = New System.Drawing.Point(115, 91)
        Me.cboLocation.Name = "cboLocation"
        Me.cboLocation.Size = New System.Drawing.Size(93, 24)
        Me.cboLocation.TabIndex = 21
        '
        'cboCategory
        '
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Location = New System.Drawing.Point(115, 53)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(93, 24)
        Me.cboCategory.TabIndex = 19
        '
        'txtPublisher
        '
        Me.txtPublisher.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPublisher.Location = New System.Drawing.Point(343, 91)
        Me.txtPublisher.Name = "txtPublisher"
        Me.txtPublisher.Size = New System.Drawing.Size(247, 22)
        Me.txtPublisher.TabIndex = 18
        '
        'lblPublisher
        '
        Me.lblPublisher.BackColor = System.Drawing.Color.Silver
        Me.lblPublisher.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPublisher.Location = New System.Drawing.Point(237, 91)
        Me.lblPublisher.Name = "lblPublisher"
        Me.lblPublisher.Size = New System.Drawing.Size(100, 22)
        Me.lblPublisher.TabIndex = 17
        Me.lblPublisher.Text = "Publisher"
        Me.lblPublisher.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtReadby
        '
        Me.txtReadby.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReadby.Location = New System.Drawing.Point(718, 91)
        Me.txtReadby.Name = "txtReadby"
        Me.txtReadby.Size = New System.Drawing.Size(83, 22)
        Me.txtReadby.TabIndex = 16
        '
        'txtAuthor
        '
        Me.txtAuthor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAuthor.Location = New System.Drawing.Point(343, 53)
        Me.txtAuthor.Name = "txtAuthor"
        Me.txtAuthor.Size = New System.Drawing.Size(247, 22)
        Me.txtAuthor.TabIndex = 14
        '
        'txtTitle
        '
        Me.txtTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTitle.Location = New System.Drawing.Point(343, 19)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(247, 22)
        Me.txtTitle.TabIndex = 11
        '
        'txtID
        '
        Me.txtID.Enabled = False
        Me.txtID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtID.Location = New System.Drawing.Point(115, 19)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(93, 22)
        Me.txtID.TabIndex = 10
        '
        'lblReadby
        '
        Me.lblReadby.BackColor = System.Drawing.Color.Silver
        Me.lblReadby.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReadby.Location = New System.Drawing.Point(615, 91)
        Me.lblReadby.Name = "lblReadby"
        Me.lblReadby.Size = New System.Drawing.Size(97, 22)
        Me.lblReadby.TabIndex = 7
        Me.lblReadby.Text = "Read By"
        Me.lblReadby.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLocation
        '
        Me.lblLocation.BackColor = System.Drawing.Color.Silver
        Me.lblLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocation.Location = New System.Drawing.Point(9, 91)
        Me.lblLocation.Name = "lblLocation"
        Me.lblLocation.Size = New System.Drawing.Size(100, 22)
        Me.lblLocation.TabIndex = 5
        Me.lblLocation.Text = "Location"
        Me.lblLocation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAuthor
        '
        Me.lblAuthor.BackColor = System.Drawing.Color.Silver
        Me.lblAuthor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAuthor.Location = New System.Drawing.Point(237, 53)
        Me.lblAuthor.Name = "lblAuthor"
        Me.lblAuthor.Size = New System.Drawing.Size(100, 22)
        Me.lblAuthor.TabIndex = 4
        Me.lblAuthor.Text = "Author"
        Me.lblAuthor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblCategory
        '
        Me.lblCategory.BackColor = System.Drawing.Color.Silver
        Me.lblCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory.Location = New System.Drawing.Point(9, 53)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(100, 22)
        Me.lblCategory.TabIndex = 3
        Me.lblCategory.Text = "Category"
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblMedia
        '
        Me.lblMedia.BackColor = System.Drawing.Color.Silver
        Me.lblMedia.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMedia.Location = New System.Drawing.Point(615, 19)
        Me.lblMedia.Name = "lblMedia"
        Me.lblMedia.Size = New System.Drawing.Size(97, 22)
        Me.lblMedia.TabIndex = 2
        Me.lblMedia.Text = "Media"
        Me.lblMedia.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.Silver
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(237, 19)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(100, 22)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "Title"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblID
        '
        Me.lblID.BackColor = System.Drawing.Color.Silver
        Me.lblID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(9, 19)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(100, 22)
        Me.lblID.TabIndex = 0
        Me.lblID.Text = "Book ID"
        Me.lblID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboMedia
        '
        Me.cboMedia.FormattingEnabled = True
        Me.cboMedia.Location = New System.Drawing.Point(718, 19)
        Me.cboMedia.Name = "cboMedia"
        Me.cboMedia.Size = New System.Drawing.Size(82, 24)
        Me.cboMedia.TabIndex = 20
        '
        'GroupBoxSaveQuery
        '
        Me.GroupBoxSaveQuery.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBoxSaveQuery.Controls.Add(Me.txtQueryName)
        Me.GroupBoxSaveQuery.Controls.Add(Me.lblSaveQueryName)
        Me.GroupBoxSaveQuery.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxSaveQuery.Location = New System.Drawing.Point(12, 520)
        Me.GroupBoxSaveQuery.Name = "GroupBoxSaveQuery"
        Me.GroupBoxSaveQuery.Size = New System.Drawing.Size(808, 57)
        Me.GroupBoxSaveQuery.TabIndex = 30
        Me.GroupBoxSaveQuery.TabStop = False
        Me.GroupBoxSaveQuery.Text = "Save Query?"
        Me.GroupBoxSaveQuery.Visible = False
        '
        'txtQueryName
        '
        Me.txtQueryName.Location = New System.Drawing.Point(343, 18)
        Me.txtQueryName.Name = "txtQueryName"
        Me.txtQueryName.Size = New System.Drawing.Size(458, 22)
        Me.txtQueryName.TabIndex = 1
        '
        'lblSaveQueryName
        '
        Me.lblSaveQueryName.BackColor = System.Drawing.Color.Silver
        Me.lblSaveQueryName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSaveQueryName.Location = New System.Drawing.Point(6, 18)
        Me.lblSaveQueryName.Name = "lblSaveQueryName"
        Me.lblSaveQueryName.Size = New System.Drawing.Size(331, 22)
        Me.lblSaveQueryName.TabIndex = 0
        Me.lblSaveQueryName.Text = "Enter Query name, Click Save Query or Cancel"
        Me.lblSaveQueryName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBoxVideos
        '
        Me.GroupBoxVideos.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBoxVideos.Controls.Add(Me.txtTime)
        Me.GroupBoxVideos.Controls.Add(Me.txtArtist)
        Me.GroupBoxVideos.Controls.Add(Me.txtDescription)
        Me.GroupBoxVideos.Controls.Add(Me.txtTapeID)
        Me.GroupBoxVideos.Controls.Add(Me.lblTime)
        Me.GroupBoxVideos.Controls.Add(Me.lblArtist)
        Me.GroupBoxVideos.Controls.Add(Me.lblVideoCategory)
        Me.GroupBoxVideos.Controls.Add(Me.lblVideoMedia)
        Me.GroupBoxVideos.Controls.Add(Me.lblDescription)
        Me.GroupBoxVideos.Controls.Add(Me.lblTapeID)
        Me.GroupBoxVideos.Controls.Add(Me.cboVideoCategory)
        Me.GroupBoxVideos.Controls.Add(Me.cboVideoMedia)
        Me.GroupBoxVideos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxVideos.Location = New System.Drawing.Point(12, 388)
        Me.GroupBoxVideos.Name = "GroupBoxVideos"
        Me.GroupBoxVideos.Size = New System.Drawing.Size(808, 88)
        Me.GroupBoxVideos.TabIndex = 31
        Me.GroupBoxVideos.TabStop = False
        Me.GroupBoxVideos.Text = "Videos"
        Me.GroupBoxVideos.Visible = False
        '
        'txtTime
        '
        Me.txtTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTime.Location = New System.Drawing.Point(721, 53)
        Me.txtTime.Name = "txtTime"
        Me.txtTime.Size = New System.Drawing.Size(80, 22)
        Me.txtTime.TabIndex = 15
        '
        'txtArtist
        '
        Me.txtArtist.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtArtist.Location = New System.Drawing.Point(343, 53)
        Me.txtArtist.Name = "txtArtist"
        Me.txtArtist.Size = New System.Drawing.Size(247, 22)
        Me.txtArtist.TabIndex = 14
        '
        'txtDescription
        '
        Me.txtDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDescription.Location = New System.Drawing.Point(343, 19)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(247, 22)
        Me.txtDescription.TabIndex = 11
        '
        'txtTapeID
        '
        Me.txtTapeID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTapeID.Location = New System.Drawing.Point(115, 19)
        Me.txtTapeID.Name = "txtTapeID"
        Me.txtTapeID.Size = New System.Drawing.Size(93, 22)
        Me.txtTapeID.TabIndex = 10
        '
        'lblTime
        '
        Me.lblTime.BackColor = System.Drawing.Color.Silver
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.Location = New System.Drawing.Point(615, 53)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(97, 22)
        Me.lblTime.TabIndex = 5
        Me.lblTime.Text = "Time"
        Me.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblArtist
        '
        Me.lblArtist.BackColor = System.Drawing.Color.Silver
        Me.lblArtist.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblArtist.Location = New System.Drawing.Point(237, 53)
        Me.lblArtist.Name = "lblArtist"
        Me.lblArtist.Size = New System.Drawing.Size(100, 22)
        Me.lblArtist.TabIndex = 4
        Me.lblArtist.Text = "Arthst"
        Me.lblArtist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblVideoCategory
        '
        Me.lblVideoCategory.BackColor = System.Drawing.Color.Silver
        Me.lblVideoCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVideoCategory.Location = New System.Drawing.Point(9, 53)
        Me.lblVideoCategory.Name = "lblVideoCategory"
        Me.lblVideoCategory.Size = New System.Drawing.Size(100, 22)
        Me.lblVideoCategory.TabIndex = 3
        Me.lblVideoCategory.Text = "Category"
        Me.lblVideoCategory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblVideoMedia
        '
        Me.lblVideoMedia.BackColor = System.Drawing.Color.Silver
        Me.lblVideoMedia.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVideoMedia.Location = New System.Drawing.Point(615, 19)
        Me.lblVideoMedia.Name = "lblVideoMedia"
        Me.lblVideoMedia.Size = New System.Drawing.Size(97, 22)
        Me.lblVideoMedia.TabIndex = 2
        Me.lblVideoMedia.Text = "Media"
        Me.lblVideoMedia.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDescription
        '
        Me.lblDescription.BackColor = System.Drawing.Color.Silver
        Me.lblDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.Location = New System.Drawing.Point(237, 19)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(100, 22)
        Me.lblDescription.TabIndex = 1
        Me.lblDescription.Text = "Description"
        Me.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTapeID
        '
        Me.lblTapeID.BackColor = System.Drawing.Color.Silver
        Me.lblTapeID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTapeID.Location = New System.Drawing.Point(9, 19)
        Me.lblTapeID.Name = "lblTapeID"
        Me.lblTapeID.Size = New System.Drawing.Size(100, 22)
        Me.lblTapeID.TabIndex = 0
        Me.lblTapeID.Text = "Video ID"
        Me.lblTapeID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboVideoCategory
        '
        Me.cboVideoCategory.FormattingEnabled = True
        Me.cboVideoCategory.Location = New System.Drawing.Point(115, 51)
        Me.cboVideoCategory.Name = "cboVideoCategory"
        Me.cboVideoCategory.Size = New System.Drawing.Size(93, 24)
        Me.cboVideoCategory.TabIndex = 16
        '
        'cboVideoMedia
        '
        Me.cboVideoMedia.FormattingEnabled = True
        Me.cboVideoMedia.Location = New System.Drawing.Point(718, 19)
        Me.cboVideoMedia.Name = "cboVideoMedia"
        Me.cboVideoMedia.Size = New System.Drawing.Size(82, 24)
        Me.cboVideoMedia.TabIndex = 17
        '
        'GroupBoxAddress
        '
        Me.GroupBoxAddress.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBoxAddress.Controls.Add(Me.txtCountry)
        Me.GroupBoxAddress.Controls.Add(Me.lblCountry)
        Me.GroupBoxAddress.Controls.Add(Me.txtTown)
        Me.GroupBoxAddress.Controls.Add(Me.lblAddress2)
        Me.GroupBoxAddress.Controls.Add(Me.txtOfficePhone)
        Me.GroupBoxAddress.Controls.Add(Me.lblOfficePhone)
        Me.GroupBoxAddress.Controls.Add(Me.txtMobilePhone)
        Me.GroupBoxAddress.Controls.Add(Me.lblMobile)
        Me.GroupBoxAddress.Controls.Add(Me.txtHomePhone)
        Me.GroupBoxAddress.Controls.Add(Me.txtAddressTitle)
        Me.GroupBoxAddress.Controls.Add(Me.txtStatus)
        Me.GroupBoxAddress.Controls.Add(Me.lblNotes)
        Me.GroupBoxAddress.Controls.Add(Me.txtNotes)
        Me.GroupBoxAddress.Controls.Add(Me.lblStatus)
        Me.GroupBoxAddress.Controls.Add(Me.txtCompany)
        Me.GroupBoxAddress.Controls.Add(Me.lblCompany)
        Me.GroupBoxAddress.Controls.Add(Me.lblCard)
        Me.GroupBoxAddress.Controls.Add(Me.txtCounty)
        Me.GroupBoxAddress.Controls.Add(Me.txtCard)
        Me.GroupBoxAddress.Controls.Add(Me.lblCounty)
        Me.GroupBoxAddress.Controls.Add(Me.txtPostCode)
        Me.GroupBoxAddress.Controls.Add(Me.lblPostCode)
        Me.GroupBoxAddress.Controls.Add(Me.txtAddress2)
        Me.GroupBoxAddress.Controls.Add(Me.lblTown)
        Me.GroupBoxAddress.Controls.Add(Me.lblAddress1)
        Me.GroupBoxAddress.Controls.Add(Me.txtAddress1)
        Me.GroupBoxAddress.Controls.Add(Me.txtEmail)
        Me.GroupBoxAddress.Controls.Add(Me.lblEmail)
        Me.GroupBoxAddress.Controls.Add(Me.txtFirstName)
        Me.GroupBoxAddress.Controls.Add(Me.txtSource)
        Me.GroupBoxAddress.Controls.Add(Me.txtLastName)
        Me.GroupBoxAddress.Controls.Add(Me.txtCustID)
        Me.GroupBoxAddress.Controls.Add(Me.lblSource)
        Me.GroupBoxAddress.Controls.Add(Me.lblFirstName)
        Me.GroupBoxAddress.Controls.Add(Me.lblPhone)
        Me.GroupBoxAddress.Controls.Add(Me.lblAdressTitle)
        Me.GroupBoxAddress.Controls.Add(Me.lblLastName)
        Me.GroupBoxAddress.Controls.Add(Me.lblCustID)
        Me.GroupBoxAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxAddress.Location = New System.Drawing.Point(12, 388)
        Me.GroupBoxAddress.Name = "GroupBoxAddress"
        Me.GroupBoxAddress.Size = New System.Drawing.Size(808, 197)
        Me.GroupBoxAddress.TabIndex = 32
        Me.GroupBoxAddress.TabStop = False
        Me.GroupBoxAddress.Text = "Address"
        Me.GroupBoxAddress.Visible = False
        '
        'txtCountry
        '
        Me.txtCountry.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCountry.Location = New System.Drawing.Point(705, 164)
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.Size = New System.Drawing.Size(95, 22)
        Me.txtCountry.TabIndex = 47
        '
        'lblCountry
        '
        Me.lblCountry.BackColor = System.Drawing.Color.Silver
        Me.lblCountry.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCountry.Location = New System.Drawing.Point(599, 164)
        Me.lblCountry.Name = "lblCountry"
        Me.lblCountry.Size = New System.Drawing.Size(100, 22)
        Me.lblCountry.TabIndex = 46
        Me.lblCountry.Text = "Country"
        Me.lblCountry.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTown
        '
        Me.txtTown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTown.Location = New System.Drawing.Point(705, 108)
        Me.txtTown.Multiline = True
        Me.txtTown.Name = "txtTown"
        Me.txtTown.Size = New System.Drawing.Size(95, 22)
        Me.txtTown.TabIndex = 45
        '
        'lblAddress2
        '
        Me.lblAddress2.BackColor = System.Drawing.Color.Silver
        Me.lblAddress2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress2.Location = New System.Drawing.Point(346, 108)
        Me.lblAddress2.Name = "lblAddress2"
        Me.lblAddress2.Size = New System.Drawing.Size(100, 22)
        Me.lblAddress2.TabIndex = 44
        Me.lblAddress2.Text = "Address2"
        Me.lblAddress2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtOfficePhone
        '
        Me.txtOfficePhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOfficePhone.Location = New System.Drawing.Point(505, 75)
        Me.txtOfficePhone.Name = "txtOfficePhone"
        Me.txtOfficePhone.Size = New System.Drawing.Size(88, 22)
        Me.txtOfficePhone.TabIndex = 43
        '
        'lblOfficePhone
        '
        Me.lblOfficePhone.BackColor = System.Drawing.Color.Silver
        Me.lblOfficePhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOfficePhone.Location = New System.Drawing.Point(408, 75)
        Me.lblOfficePhone.Name = "lblOfficePhone"
        Me.lblOfficePhone.Size = New System.Drawing.Size(90, 22)
        Me.lblOfficePhone.TabIndex = 42
        Me.lblOfficePhone.Text = "Office phone"
        Me.lblOfficePhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtMobilePhone
        '
        Me.txtMobilePhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMobilePhone.Location = New System.Drawing.Point(313, 75)
        Me.txtMobilePhone.Name = "txtMobilePhone"
        Me.txtMobilePhone.Size = New System.Drawing.Size(88, 22)
        Me.txtMobilePhone.TabIndex = 41
        '
        'lblMobile
        '
        Me.lblMobile.BackColor = System.Drawing.Color.Silver
        Me.lblMobile.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMobile.Location = New System.Drawing.Point(217, 75)
        Me.lblMobile.Name = "lblMobile"
        Me.lblMobile.Size = New System.Drawing.Size(90, 22)
        Me.lblMobile.TabIndex = 40
        Me.lblMobile.Text = "Mobile phone"
        Me.lblMobile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtHomePhone
        '
        Me.txtHomePhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomePhone.Location = New System.Drawing.Point(118, 75)
        Me.txtHomePhone.Name = "txtHomePhone"
        Me.txtHomePhone.Size = New System.Drawing.Size(93, 22)
        Me.txtHomePhone.TabIndex = 39
        '
        'txtAddressTitle
        '
        Me.txtAddressTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddressTitle.Location = New System.Drawing.Point(705, 19)
        Me.txtAddressTitle.Name = "txtAddressTitle"
        Me.txtAddressTitle.Size = New System.Drawing.Size(95, 22)
        Me.txtAddressTitle.TabIndex = 38
        '
        'txtStatus
        '
        Me.txtStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStatus.Location = New System.Drawing.Point(118, 47)
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.Size = New System.Drawing.Size(93, 22)
        Me.txtStatus.TabIndex = 37
        '
        'lblNotes
        '
        Me.lblNotes.BackColor = System.Drawing.Color.Silver
        Me.lblNotes.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNotes.Location = New System.Drawing.Point(346, 164)
        Me.lblNotes.Name = "lblNotes"
        Me.lblNotes.Size = New System.Drawing.Size(100, 22)
        Me.lblNotes.TabIndex = 36
        Me.lblNotes.Text = "Notes"
        Me.lblNotes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtNotes
        '
        Me.txtNotes.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNotes.Location = New System.Drawing.Point(452, 164)
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(141, 22)
        Me.txtNotes.TabIndex = 35
        '
        'lblStatus
        '
        Me.lblStatus.BackColor = System.Drawing.Color.Silver
        Me.lblStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(9, 47)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(103, 22)
        Me.lblStatus.TabIndex = 34
        Me.lblStatus.Text = "Status"
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCompany
        '
        Me.txtCompany.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCompany.Location = New System.Drawing.Point(118, 164)
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.Size = New System.Drawing.Size(222, 22)
        Me.txtCompany.TabIndex = 33
        '
        'lblCompany
        '
        Me.lblCompany.BackColor = System.Drawing.Color.Silver
        Me.lblCompany.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCompany.Location = New System.Drawing.Point(9, 164)
        Me.lblCompany.Name = "lblCompany"
        Me.lblCompany.Size = New System.Drawing.Size(103, 22)
        Me.lblCompany.TabIndex = 32
        Me.lblCompany.Text = "Company name"
        Me.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblCard
        '
        Me.lblCard.BackColor = System.Drawing.Color.Silver
        Me.lblCard.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCard.Location = New System.Drawing.Point(599, 47)
        Me.lblCard.Name = "lblCard"
        Me.lblCard.Size = New System.Drawing.Size(100, 22)
        Me.lblCard.TabIndex = 31
        Me.lblCard.Text = "Card (Y/N)"
        Me.lblCard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCounty
        '
        Me.txtCounty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCounty.Location = New System.Drawing.Point(452, 136)
        Me.txtCounty.Name = "txtCounty"
        Me.txtCounty.Size = New System.Drawing.Size(141, 22)
        Me.txtCounty.TabIndex = 30
        '
        'txtCard
        '
        Me.txtCard.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCard.Location = New System.Drawing.Point(705, 47)
        Me.txtCard.Name = "txtCard"
        Me.txtCard.Size = New System.Drawing.Size(95, 22)
        Me.txtCard.TabIndex = 29
        '
        'lblCounty
        '
        Me.lblCounty.BackColor = System.Drawing.Color.Silver
        Me.lblCounty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCounty.Location = New System.Drawing.Point(346, 136)
        Me.lblCounty.Name = "lblCounty"
        Me.lblCounty.Size = New System.Drawing.Size(100, 22)
        Me.lblCounty.TabIndex = 28
        Me.lblCounty.Text = "County"
        Me.lblCounty.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtPostCode
        '
        Me.txtPostCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPostCode.Location = New System.Drawing.Point(705, 136)
        Me.txtPostCode.Name = "txtPostCode"
        Me.txtPostCode.Size = New System.Drawing.Size(95, 22)
        Me.txtPostCode.TabIndex = 27
        '
        'lblPostCode
        '
        Me.lblPostCode.BackColor = System.Drawing.Color.Silver
        Me.lblPostCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPostCode.Location = New System.Drawing.Point(599, 136)
        Me.lblPostCode.Name = "lblPostCode"
        Me.lblPostCode.Size = New System.Drawing.Size(100, 22)
        Me.lblPostCode.TabIndex = 26
        Me.lblPostCode.Text = "Post code"
        Me.lblPostCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAddress2
        '
        Me.txtAddress2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress2.Location = New System.Drawing.Point(452, 108)
        Me.txtAddress2.Name = "txtAddress2"
        Me.txtAddress2.Size = New System.Drawing.Size(141, 22)
        Me.txtAddress2.TabIndex = 25
        '
        'lblTown
        '
        Me.lblTown.BackColor = System.Drawing.Color.Silver
        Me.lblTown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTown.Location = New System.Drawing.Point(599, 108)
        Me.lblTown.Name = "lblTown"
        Me.lblTown.Size = New System.Drawing.Size(100, 22)
        Me.lblTown.TabIndex = 24
        Me.lblTown.Text = "Town"
        Me.lblTown.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAddress1
        '
        Me.lblAddress1.BackColor = System.Drawing.Color.Silver
        Me.lblAddress1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress1.Location = New System.Drawing.Point(9, 108)
        Me.lblAddress1.Name = "lblAddress1"
        Me.lblAddress1.Size = New System.Drawing.Size(103, 22)
        Me.lblAddress1.TabIndex = 23
        Me.lblAddress1.Text = "Address1"
        Me.lblAddress1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAddress1
        '
        Me.txtAddress1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress1.Location = New System.Drawing.Point(118, 108)
        Me.txtAddress1.Name = "txtAddress1"
        Me.txtAddress1.Size = New System.Drawing.Size(222, 22)
        Me.txtAddress1.TabIndex = 22
        '
        'txtEmail
        '
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.Location = New System.Drawing.Point(118, 136)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(222, 22)
        Me.txtEmail.TabIndex = 18
        '
        'lblEmail
        '
        Me.lblEmail.BackColor = System.Drawing.Color.Silver
        Me.lblEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(9, 136)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(103, 22)
        Me.lblEmail.TabIndex = 17
        Me.lblEmail.Text = "Email address"
        Me.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtFirstName
        '
        Me.txtFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.Location = New System.Drawing.Point(314, 19)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(279, 22)
        Me.txtFirstName.TabIndex = 14
        '
        'txtSource
        '
        Me.txtSource.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSource.Location = New System.Drawing.Point(705, 75)
        Me.txtSource.Multiline = True
        Me.txtSource.Name = "txtSource"
        Me.txtSource.Size = New System.Drawing.Size(95, 22)
        Me.txtSource.TabIndex = 13
        '
        'txtLastName
        '
        Me.txtLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastName.Location = New System.Drawing.Point(314, 47)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(279, 22)
        Me.txtLastName.TabIndex = 11
        '
        'txtCustID
        '
        Me.txtCustID.Enabled = False
        Me.txtCustID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustID.Location = New System.Drawing.Point(118, 19)
        Me.txtCustID.Name = "txtCustID"
        Me.txtCustID.Size = New System.Drawing.Size(93, 22)
        Me.txtCustID.TabIndex = 10
        '
        'lblSource
        '
        Me.lblSource.BackColor = System.Drawing.Color.Silver
        Me.lblSource.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSource.Location = New System.Drawing.Point(599, 75)
        Me.lblSource.Name = "lblSource"
        Me.lblSource.Size = New System.Drawing.Size(100, 22)
        Me.lblSource.TabIndex = 5
        Me.lblSource.Text = "Source"
        Me.lblSource.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFirstName
        '
        Me.lblFirstName.BackColor = System.Drawing.Color.Silver
        Me.lblFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstName.Location = New System.Drawing.Point(217, 19)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(90, 22)
        Me.lblFirstName.TabIndex = 4
        Me.lblFirstName.Text = "First names"
        Me.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblPhone
        '
        Me.lblPhone.BackColor = System.Drawing.Color.Silver
        Me.lblPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhone.Location = New System.Drawing.Point(9, 75)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(103, 22)
        Me.lblPhone.TabIndex = 3
        Me.lblPhone.Text = "Home phone"
        Me.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAdressTitle
        '
        Me.lblAdressTitle.BackColor = System.Drawing.Color.Silver
        Me.lblAdressTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdressTitle.Location = New System.Drawing.Point(599, 19)
        Me.lblAdressTitle.Name = "lblAdressTitle"
        Me.lblAdressTitle.Size = New System.Drawing.Size(100, 22)
        Me.lblAdressTitle.TabIndex = 2
        Me.lblAdressTitle.Text = "Title"
        Me.lblAdressTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLastName
        '
        Me.lblLastName.BackColor = System.Drawing.Color.Silver
        Me.lblLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastName.Location = New System.Drawing.Point(217, 47)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(90, 22)
        Me.lblLastName.TabIndex = 1
        Me.lblLastName.Text = "Last name"
        Me.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblCustID
        '
        Me.lblCustID.BackColor = System.Drawing.Color.Silver
        Me.lblCustID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustID.Location = New System.Drawing.Point(9, 19)
        Me.lblCustID.Name = "lblCustID"
        Me.lblCustID.Size = New System.Drawing.Size(103, 22)
        Me.lblCustID.TabIndex = 0
        Me.lblCustID.Text = "ID"
        Me.lblCustID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmAux
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ClientSize = New System.Drawing.Size(832, 658)
        Me.Controls.Add(Me.GroupBoxSaveQuery)
        Me.Controls.Add(Me.txtQryName)
        Me.Controls.Add(Me.AxCrystalReport1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBoxBooks)
        Me.Controls.Add(Me.GroupBoxVideos)
        Me.Controls.Add(Me.AddressesDataGridView)
        Me.Controls.Add(Me.AddressesSharpDataGridView)
        Me.Controls.Add(Me.BooksDataGridView)
        Me.Controls.Add(Me.VideoDataGridView)
        Me.Controls.Add(Me.GroupBoxAddress)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "frmAux"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Personal Data System - Database -"
        Me.GroupBox1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.VideoQryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VideoDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BooksDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BooksDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BooksDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VideoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VideoDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LifeLineDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LifeLineDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AddressesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxCrystalReport1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LifelineQryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SharpDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AddressesSharpDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BooksQryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxBooks.ResumeLayout(False)
        Me.GroupBoxBooks.PerformLayout()
        Me.GroupBoxSaveQuery.ResumeLayout(False)
        Me.GroupBoxSaveQuery.PerformLayout()
        Me.GroupBoxVideos.ResumeLayout(False)
        Me.GroupBoxVideos.PerformLayout()
        Me.GroupBoxAddress.ResumeLayout(False)
        Me.GroupBoxAddress.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdReport As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdChange As System.Windows.Forms.Button
    Friend WithEvents cmdSaveQuery As System.Windows.Forms.Button
    Friend WithEvents cmdView As System.Windows.Forms.Button
    Friend WithEvents CmdAdd As System.Windows.Forms.Button
    Friend WithEvents CmdDelete As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents BooksDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents BooksDataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents FldList As System.Windows.Forms.ListBox
    Friend WithEvents TblList As System.Windows.Forms.ListBox
    Friend WithEvents txtSQL As System.Windows.Forms.TextBox
    Friend WithEvents QryList As System.Windows.Forms.ListBox
    Friend WithEvents VideoDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents VideoDataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents LifeLineDataSetBindingSource As System.Windows.Forms.BindingSource
    'Friend WithEvents RptTempTableAdapter1 As VPBS13.LifeLineDataSetTableAdapters.RptTempTableAdapter
    Friend WithEvents AddressesDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents AxCrystalReport1 As AxCrystal.AxCrystalReport
    Friend WithEvents BooksDataSet1 As VPBS13.BOOKSDataSet1
    Friend WithEvents BooksQryBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents QryBooksTableAdapter As VPBS13.BOOKSDataSet1TableAdapters.qryBooksTableAdapter
    Friend WithEvents BooksTableAdapter As VPBS13.BOOKSDataSet1TableAdapters.BooksTableAdapter
    Friend WithEvents RptTempTableAdapterB As VPBS13.BOOKSDataSet1TableAdapters.RptTempTableAdapter
    Friend WithEvents txtQryName As System.Windows.Forms.TextBox
    Friend WithEvents VideoDataSet1 As VPBS13.VIDEODataSet1
    Friend WithEvents LifeLineDataSet1 As VPBS13.LifeLineDataSet1
    Friend WithEvents TapeIdDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DescriptionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MediaDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CategoryDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ArtistDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TimeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalTimeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReportTitleDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RptTempTableAdapterV As VPBS13.VIDEODataSet1TableAdapters.RptTempTableAdapter
    Friend WithEvents VideoTableAdapter As VPBS13.VIDEODataSet1TableAdapters.VIDEO3TableAdapter
    Friend WithEvents Prospects___COITableAdapter As VPBS13.LifeLineDataSet1TableAdapters.Prospects___COITableAdapter
    Friend WithEvents VideoQryBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents QryVideoTableAdapter As VPBS13.VIDEODataSet1TableAdapters.qryVideoTableAdapter
    Friend WithEvents LifelineQryBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents QryLifelineTableAdapter As VPBS13.LifeLineDataSet1TableAdapters.qryLifelineTableAdapter
    Friend WithEvents SharpTableAdapter As VPBS13.LifeLineDataSet1TableAdapters.SharpTableAdapter
    Friend WithEvents Prospects___ex_HiltonTableAdapter As VPBS13.LifeLineDataSet1TableAdapters.Prospects___ex_HiltonTableAdapter
    Friend WithEvents SharpDataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AddressesSharpDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents CategoryDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastNameDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FirstNameDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TitleDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CompanyDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Address1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Address2DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TownDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CountyDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PostcodeDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CountryDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HomeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OfficeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MobileDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EmailDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NoteDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ChristmascardDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReportTitleDataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdOk As System.Windows.Forms.Button
    Friend WithEvents GroupBoxBooks As System.Windows.Forms.GroupBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtReadby As System.Windows.Forms.TextBox
    Friend WithEvents txtAuthor As System.Windows.Forms.TextBox
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents lblReadby As System.Windows.Forms.Label
    Friend WithEvents lblLocation As System.Windows.Forms.Label
    Friend WithEvents lblAuthor As System.Windows.Forms.Label
    Friend WithEvents lblCategory As System.Windows.Forms.Label
    Friend WithEvents lblMedia As System.Windows.Forms.Label
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents txtPublisher As System.Windows.Forms.TextBox
    Friend WithEvents lblPublisher As System.Windows.Forms.Label
    Friend WithEvents ID1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TitleDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MediaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CategoryDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AuthorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PublisherDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LocationDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReadByDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReportTitleDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FirstNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TitleDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TownDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CountyDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PostCodeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhoneDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EmailAddressDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InterestDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SourceDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AmountDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DateOfLastContactDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DateOfNextContactDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CompanyNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NotesDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SalutationDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastMailedDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NextMailedDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CampaignDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReportTitleDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtSQLDisp As System.Windows.Forms.TextBox
    Friend WithEvents GroupBoxSaveQuery As System.Windows.Forms.GroupBox
    Friend WithEvents lblSaveQueryName As System.Windows.Forms.Label
    Friend WithEvents txtQueryName As System.Windows.Forms.TextBox
    Friend WithEvents GroupBoxVideos As System.Windows.Forms.GroupBox
    Friend WithEvents txtTime As System.Windows.Forms.TextBox
    Friend WithEvents txtArtist As System.Windows.Forms.TextBox
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents txtTapeID As System.Windows.Forms.TextBox
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents lblArtist As System.Windows.Forms.Label
    Friend WithEvents lblVideoCategory As System.Windows.Forms.Label
    Friend WithEvents lblVideoMedia As System.Windows.Forms.Label
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents lblTapeID As System.Windows.Forms.Label
    Friend WithEvents cboVideoCategory As System.Windows.Forms.ComboBox
    Friend WithEvents cboVideoMedia As System.Windows.Forms.ComboBox
    Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
    Friend WithEvents cboMedia As System.Windows.Forms.ComboBox
    Friend WithEvents cboLocation As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBoxAddress As System.Windows.Forms.GroupBox
    Friend WithEvents lblCard As System.Windows.Forms.Label
    Friend WithEvents txtCounty As System.Windows.Forms.TextBox
    Friend WithEvents txtCard As System.Windows.Forms.TextBox
    Friend WithEvents lblCounty As System.Windows.Forms.Label
    Friend WithEvents txtPostCode As System.Windows.Forms.TextBox
    Friend WithEvents lblPostCode As System.Windows.Forms.Label
    Friend WithEvents txtAddress2 As System.Windows.Forms.TextBox
    Friend WithEvents lblTown As System.Windows.Forms.Label
    Friend WithEvents lblAddress1 As System.Windows.Forms.Label
    Friend WithEvents txtAddress1 As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtSource As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtCustID As System.Windows.Forms.TextBox
    Friend WithEvents lblSource As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblAdressTitle As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblCustID As System.Windows.Forms.Label
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents lblNotes As System.Windows.Forms.Label
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents txtCompany As System.Windows.Forms.TextBox
    Friend WithEvents lblCompany As System.Windows.Forms.Label
    Friend WithEvents txtAddressTitle As System.Windows.Forms.TextBox
    Friend WithEvents txtHomePhone As System.Windows.Forms.TextBox
    Friend WithEvents txtTown As System.Windows.Forms.TextBox
    Friend WithEvents lblAddress2 As System.Windows.Forms.Label
    Friend WithEvents txtOfficePhone As System.Windows.Forms.TextBox
    Friend WithEvents lblOfficePhone As System.Windows.Forms.Label
    Friend WithEvents txtMobilePhone As System.Windows.Forms.TextBox
    Friend WithEvents lblMobile As System.Windows.Forms.Label
    Friend WithEvents txtCountry As System.Windows.Forms.TextBox
    Friend WithEvents lblCountry As System.Windows.Forms.Label
End Class
