﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSetup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSetup))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdChange = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdOk = New System.Windows.Forms.Button()
        Me.CmdNew = New System.Windows.Forms.Button()
        Me.CmdDelete = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.txtAccountName = New System.Windows.Forms.TextBox()
        Me.txtShortAccountName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DataGridViewAccountNames = New System.Windows.Forms.DataGridView()
        Me.ShortNameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountNamesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VPBSDataSet = New VPBS13.VPBSDataSet()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtBankName = New System.Windows.Forms.TextBox()
        Me.txtShortBankName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridViewBankNames = New System.Windows.Forms.DataGridView()
        Me.ShortNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BankNamesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.txtCustName = New System.Windows.Forms.TextBox()
        Me.txtShortCustName = New System.Windows.Forms.TextBox()
        Me.lblCustName = New System.Windows.Forms.Label()
        Me.lblCustShortName = New System.Windows.Forms.Label()
        Me.DataGridViewCustomers = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.txtAddPassword = New System.Windows.Forms.TextBox()
        Me.lblAddPassword = New System.Windows.Forms.Label()
        Me.lblVerifyPassword = New System.Windows.Forms.Label()
        Me.txtVerifyPassword = New System.Windows.Forms.TextBox()
        Me.lblChangePassword = New System.Windows.Forms.Label()
        Me.lblCurrentPassword = New System.Windows.Forms.Label()
        Me.txtNewPassword = New System.Windows.Forms.TextBox()
        Me.txtOldPassword = New System.Windows.Forms.TextBox()
        Me.txtUserLevel = New System.Windows.Forms.TextBox()
        Me.txtUserName = New System.Windows.Forms.TextBox()
        Me.lblUserLevel = New System.Windows.Forms.Label()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.DataGridViewUsers = New System.Windows.Forms.DataGridView()
        Me.UserNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UserLevelDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PasswordDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UsersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.txtAnalysisDesc = New System.Windows.Forms.TextBox()
        Me.txtAnalysisCode = New System.Windows.Forms.TextBox()
        Me.lblAnalysisDesc = New System.Windows.Forms.Label()
        Me.lblAnalysisCode = New System.Windows.Forms.Label()
        Me.DataGridViewAnalysisCodes = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AnalysisBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.txtGLCodeDesc = New System.Windows.Forms.TextBox()
        Me.txtGLCodeCode = New System.Windows.Forms.TextBox()
        Me.lblGLCodeDesc = New System.Windows.Forms.Label()
        Me.lblGLCodeCode = New System.Windows.Forms.Label()
        Me.DataGridViewGLCodes = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GLCodeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.cboActivate = New System.Windows.Forms.ComboBox()
        Me.cboRefresh = New System.Windows.Forms.ComboBox()
        Me.cboStartMonth = New System.Windows.Forms.ComboBox()
        Me.cboBudgetType = New System.Windows.Forms.ComboBox()
        Me.txtPeriodTo = New System.Windows.Forms.TextBox()
        Me.txtPeriodFrom = New System.Windows.Forms.TextBox()
        Me.lblPeriodTo = New System.Windows.Forms.Label()
        Me.lblActivate = New System.Windows.Forms.Label()
        Me.lblPeriodFrom = New System.Windows.Forms.Label()
        Me.lblRefresh = New System.Windows.Forms.Label()
        Me.lblBudgetStartMonth = New System.Windows.Forms.Label()
        Me.lblBudgetType = New System.Windows.Forms.Label()
        Me.txtBudgetDesc = New System.Windows.Forms.TextBox()
        Me.txtBudgetNo = New System.Windows.Forms.TextBox()
        Me.lblBudgetDesc = New System.Windows.Forms.Label()
        Me.lblBudgetNo = New System.Windows.Forms.Label()
        Me.DataGridViewBudgets = New System.Windows.Forms.DataGridView()
        Me.BudgetNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BudgetTypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DescriptionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PeriodFromDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PeriodToDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartMonthDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RefreshReqdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DirbudBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.lblDorM = New System.Windows.Forms.Label()
        Me.lblNofDecPlaces = New System.Windows.Forms.Label()
        Me.lblBaseCCY = New System.Windows.Forms.Label()
        Me.lblRate = New System.Windows.Forms.Label()
        Me.txtBaseCCY = New System.Windows.Forms.TextBox()
        Me.txtDorM = New System.Windows.Forms.TextBox()
        Me.txtDecPlaces = New System.Windows.Forms.TextBox()
        Me.txtRate = New System.Windows.Forms.TextBox()
        Me.txtCurrencyDesc = New System.Windows.Forms.TextBox()
        Me.txtCurrencyCode = New System.Windows.Forms.TextBox()
        Me.lblCCYDesc = New System.Windows.Forms.Label()
        Me.lblCCYCode = New System.Windows.Forms.Label()
        Me.DataGridViewCurrencies = New System.Windows.Forms.DataGridView()
        Me.CodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DescriptionDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DecimalPlacesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BaseCCYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CurrenciesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VPBSTestDataSet = New VPBS13.VPBSTestDataSet()
        Me.BankNamesTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.BankNamesTableAdapter()
        Me.AccountNamesTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.AccountNamesTableAdapter()
        Me.BankNamesTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.BankNamesTableAdapter()
        Me.AnalysisTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.AnalysisTableAdapter()
        Me.GLCodeTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.GLCodeTableAdapter()
        Me.CustomersTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.CustomersTableAdapter()
        Me.UsersTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.UsersTableAdapter()
        Me.BudgetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BudgetTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.BudgetTableAdapter()
        Me.CurrenciesTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.CurrenciesTableAdapter()
        Me.DirbudTestTableAdapter = New VPBS13.VPBSTestDataSetTableAdapters.dirbudTableAdapter()
        Me.VpbsArchiveDataSet = New VPBS13.VpbsArchiveDataSet()
        Me.BankNamesTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.BankNamesTableAdapter()
        Me.AccountNamesTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.AccountNamesTableAdapter()
        Me.AnalysisTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.AnalysisTableAdapter()
        Me.GLCodeTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.GLCodeTableAdapter()
        Me.CustomersTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.CustomersTableAdapter()
        Me.UsersTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.UsersTableAdapter()
        Me.DirbudTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.dirbudTableAdapter()
        Me.CurrenciesTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.CurrenciesTableAdapter()
        Me.BudgetTableAdapterArc = New VPBS13.VpbsArchiveDataSetTableAdapters.BudgetTableAdapter()
        Me.DirbudTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.dirbudTableAdapter()
        Me.AccountNamesTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.AccountNamesTableAdapter()
        Me.GLCodeTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.GLCodeTableAdapter()
        Me.AnalysisTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.AnalysisTableAdapter()
        Me.UsersTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.UsersTableAdapter()
        Me.CustomersTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.CustomersTableAdapter()
        Me.BudgetTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.BudgetTableAdapter()
        Me.CurrenciesTableAdapterLive = New VPBS13.VPBSDataSetTableAdapters.CurrenciesTableAdapter()
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.DataGridViewAccountNames, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AccountNamesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VPBSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.DataGridViewBankNames, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BankNamesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        CType(Me.DataGridViewCustomers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        CType(Me.DataGridViewUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UsersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        CType(Me.DataGridViewAnalysisCodes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AnalysisBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        CType(Me.DataGridViewGLCodes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GLCodeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage10.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        CType(Me.DataGridViewBudgets, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DirbudBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        Me.GroupBox17.SuspendLayout()
        CType(Me.DataGridViewCurrencies, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CurrenciesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VPBSTestDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BudgetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VpbsArchiveDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.cmdChange)
        Me.GroupBox1.Controls.Add(Me.cmdClose)
        Me.GroupBox1.Controls.Add(Me.cmdCancel)
        Me.GroupBox1.Controls.Add(Me.cmdOk)
        Me.GroupBox1.Controls.Add(Me.CmdNew)
        Me.GroupBox1.Controls.Add(Me.CmdDelete)
        Me.GroupBox1.Location = New System.Drawing.Point(10, 378)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(561, 66)
        Me.GroupBox1.TabIndex = 20
        Me.GroupBox1.TabStop = False
        '
        'cmdChange
        '
        Me.cmdChange.BackColor = System.Drawing.Color.LightGray
        Me.cmdChange.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdChange.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdChange.Location = New System.Drawing.Point(105, 19)
        Me.cmdChange.Name = "cmdChange"
        Me.cmdChange.Size = New System.Drawing.Size(80, 35)
        Me.cmdChange.TabIndex = 14
        Me.cmdChange.Text = "&Change"
        Me.cmdChange.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.Color.LightGray
        Me.cmdClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.Location = New System.Drawing.Point(470, 19)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(80, 35)
        Me.cmdClose.TabIndex = 7
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.LightGray
        Me.cmdCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.Location = New System.Drawing.Point(384, 19)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(80, 35)
        Me.cmdCancel.TabIndex = 6
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdOk
        '
        Me.cmdOk.BackColor = System.Drawing.Color.LightGray
        Me.cmdOk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.cmdOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOk.Location = New System.Drawing.Point(298, 19)
        Me.cmdOk.Name = "cmdOk"
        Me.cmdOk.Size = New System.Drawing.Size(80, 35)
        Me.cmdOk.TabIndex = 5
        Me.cmdOk.Text = "&Ok"
        Me.cmdOk.UseVisualStyleBackColor = False
        '
        'CmdNew
        '
        Me.CmdNew.BackColor = System.Drawing.Color.LightGray
        Me.CmdNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdNew.Location = New System.Drawing.Point(19, 19)
        Me.CmdNew.Name = "CmdNew"
        Me.CmdNew.Size = New System.Drawing.Size(80, 35)
        Me.CmdNew.TabIndex = 4
        Me.CmdNew.Text = "&New"
        Me.CmdNew.UseVisualStyleBackColor = False
        '
        'CmdDelete
        '
        Me.CmdDelete.BackColor = System.Drawing.Color.LightGray
        Me.CmdDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.CmdDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdDelete.Location = New System.Drawing.Point(191, 19)
        Me.CmdDelete.Name = "CmdDelete"
        Me.CmdDelete.Size = New System.Drawing.Size(80, 35)
        Me.CmdDelete.TabIndex = 1
        Me.CmdDelete.Text = "&Delete"
        Me.CmdDelete.UseVisualStyleBackColor = False
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.HotTrack = True
        Me.TabControl1.Location = New System.Drawing.Point(6, 0)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(561, 360)
        Me.TabControl1.TabIndex = 22
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 53)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(553, 303)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Account Names             "
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.GroupBox6)
        Me.GroupBox3.Controls.Add(Me.DataGridViewAccountNames)
        Me.GroupBox3.Location = New System.Drawing.Point(7, 3)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(538, 296)
        Me.GroupBox3.TabIndex = 23
        Me.GroupBox3.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox6.Controls.Add(Me.txtAccountName)
        Me.GroupBox6.Controls.Add(Me.txtShortAccountName)
        Me.GroupBox6.Controls.Add(Me.Label3)
        Me.GroupBox6.Controls.Add(Me.Label4)
        Me.GroupBox6.Location = New System.Drawing.Point(8, 156)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(524, 135)
        Me.GroupBox6.TabIndex = 2
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Account Names"
        '
        'txtAccountName
        '
        Me.txtAccountName.Location = New System.Drawing.Point(171, 80)
        Me.txtAccountName.Name = "txtAccountName"
        Me.txtAccountName.Size = New System.Drawing.Size(273, 21)
        Me.txtAccountName.TabIndex = 3
        '
        'txtShortAccountName
        '
        Me.txtShortAccountName.Location = New System.Drawing.Point(171, 40)
        Me.txtShortAccountName.Name = "txtShortAccountName"
        Me.txtShortAccountName.Size = New System.Drawing.Size(187, 21)
        Me.txtShortAccountName.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Silver
        Me.Label3.Location = New System.Drawing.Point(34, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 21)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Name:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Silver
        Me.Label4.Location = New System.Drawing.Point(34, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 21)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Short Name:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridViewAccountNames
        '
        Me.DataGridViewAccountNames.AllowUserToAddRows = False
        Me.DataGridViewAccountNames.AllowUserToDeleteRows = False
        Me.DataGridViewAccountNames.AllowUserToResizeRows = False
        Me.DataGridViewAccountNames.AutoGenerateColumns = False
        Me.DataGridViewAccountNames.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewAccountNames.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridViewAccountNames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewAccountNames.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ShortNameDataGridViewTextBoxColumn1, Me.NameDataGridViewTextBoxColumn1})
        Me.DataGridViewAccountNames.DataSource = Me.AccountNamesBindingSource
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewAccountNames.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridViewAccountNames.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridViewAccountNames.GridColor = System.Drawing.Color.Silver
        Me.DataGridViewAccountNames.Location = New System.Drawing.Point(6, 0)
        Me.DataGridViewAccountNames.MultiSelect = False
        Me.DataGridViewAccountNames.Name = "DataGridViewAccountNames"
        Me.DataGridViewAccountNames.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewAccountNames.Size = New System.Drawing.Size(529, 155)
        Me.DataGridViewAccountNames.TabIndex = 1
        '
        'ShortNameDataGridViewTextBoxColumn1
        '
        Me.ShortNameDataGridViewTextBoxColumn1.DataPropertyName = "ShortName"
        Me.ShortNameDataGridViewTextBoxColumn1.HeaderText = "ShortName"
        Me.ShortNameDataGridViewTextBoxColumn1.Name = "ShortNameDataGridViewTextBoxColumn1"
        '
        'NameDataGridViewTextBoxColumn1
        '
        Me.NameDataGridViewTextBoxColumn1.DataPropertyName = "Name"
        Me.NameDataGridViewTextBoxColumn1.HeaderText = "Name"
        Me.NameDataGridViewTextBoxColumn1.Name = "NameDataGridViewTextBoxColumn1"
        Me.NameDataGridViewTextBoxColumn1.Width = 386
        '
        'AccountNamesBindingSource
        '
        Me.AccountNamesBindingSource.DataMember = "AccountNames"
        Me.AccountNamesBindingSource.DataSource = Me.VPBSDataSet
        Me.AccountNamesBindingSource.Sort = "ShortName"
        '
        'VPBSDataSet
        '
        Me.VPBSDataSet.DataSetName = "VPBSDataSet"
        Me.VPBSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TabPage3
        '
        Me.TabPage3.AutoScroll = True
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 53)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(553, 303)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Bank Names                "
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.GroupBox5)
        Me.GroupBox4.Controls.Add(Me.DataGridViewBankNames)
        Me.GroupBox4.Location = New System.Drawing.Point(7, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(538, 299)
        Me.GroupBox4.TabIndex = 23
        Me.GroupBox4.TabStop = False
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox5.Controls.Add(Me.txtBankName)
        Me.GroupBox5.Controls.Add(Me.txtShortBankName)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Location = New System.Drawing.Point(8, 156)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(524, 135)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Bank Names"
        '
        'txtBankName
        '
        Me.txtBankName.Location = New System.Drawing.Point(171, 80)
        Me.txtBankName.Name = "txtBankName"
        Me.txtBankName.Size = New System.Drawing.Size(273, 21)
        Me.txtBankName.TabIndex = 3
        '
        'txtShortBankName
        '
        Me.txtShortBankName.Location = New System.Drawing.Point(171, 40)
        Me.txtShortBankName.Name = "txtShortBankName"
        Me.txtShortBankName.Size = New System.Drawing.Size(187, 21)
        Me.txtShortBankName.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Silver
        Me.Label2.Location = New System.Drawing.Point(34, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 21)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Silver
        Me.Label1.Location = New System.Drawing.Point(34, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Short Name:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridViewBankNames
        '
        Me.DataGridViewBankNames.AllowUserToAddRows = False
        Me.DataGridViewBankNames.AllowUserToDeleteRows = False
        Me.DataGridViewBankNames.AllowUserToResizeRows = False
        Me.DataGridViewBankNames.AutoGenerateColumns = False
        Me.DataGridViewBankNames.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewBankNames.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridViewBankNames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewBankNames.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ShortNameDataGridViewTextBoxColumn, Me.NameDataGridViewTextBoxColumn})
        Me.DataGridViewBankNames.DataSource = Me.BankNamesBindingSource
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewBankNames.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridViewBankNames.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridViewBankNames.GridColor = System.Drawing.Color.Silver
        Me.DataGridViewBankNames.Location = New System.Drawing.Point(6, 0)
        Me.DataGridViewBankNames.MultiSelect = False
        Me.DataGridViewBankNames.Name = "DataGridViewBankNames"
        Me.DataGridViewBankNames.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewBankNames.Size = New System.Drawing.Size(529, 155)
        Me.DataGridViewBankNames.TabIndex = 0
        '
        'ShortNameDataGridViewTextBoxColumn
        '
        Me.ShortNameDataGridViewTextBoxColumn.DataPropertyName = "ShortName"
        Me.ShortNameDataGridViewTextBoxColumn.HeaderText = "ShortName"
        Me.ShortNameDataGridViewTextBoxColumn.Name = "ShortNameDataGridViewTextBoxColumn"
        '
        'NameDataGridViewTextBoxColumn
        '
        Me.NameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.NameDataGridViewTextBoxColumn.DataPropertyName = "Name"
        Me.NameDataGridViewTextBoxColumn.HeaderText = "Name"
        Me.NameDataGridViewTextBoxColumn.MaxInputLength = 500
        Me.NameDataGridViewTextBoxColumn.Name = "NameDataGridViewTextBoxColumn"
        '
        'BankNamesBindingSource
        '
        Me.BankNamesBindingSource.DataMember = "BankNames"
        Me.BankNamesBindingSource.DataSource = Me.VPBSDataSet
        Me.BankNamesBindingSource.Sort = "ShortName"
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabPage7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage7.Controls.Add(Me.GroupBox13)
        Me.TabPage7.Location = New System.Drawing.Point(4, 53)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(553, 303)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Customer Names             "
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.GroupBox14)
        Me.GroupBox13.Controls.Add(Me.DataGridViewCustomers)
        Me.GroupBox13.Location = New System.Drawing.Point(7, 3)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(538, 296)
        Me.GroupBox13.TabIndex = 24
        Me.GroupBox13.TabStop = False
        '
        'GroupBox14
        '
        Me.GroupBox14.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox14.Controls.Add(Me.txtCustName)
        Me.GroupBox14.Controls.Add(Me.txtShortCustName)
        Me.GroupBox14.Controls.Add(Me.lblCustName)
        Me.GroupBox14.Controls.Add(Me.lblCustShortName)
        Me.GroupBox14.Location = New System.Drawing.Point(8, 156)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(524, 135)
        Me.GroupBox14.TabIndex = 2
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Customer Names"
        '
        'txtCustName
        '
        Me.txtCustName.Location = New System.Drawing.Point(171, 80)
        Me.txtCustName.Name = "txtCustName"
        Me.txtCustName.Size = New System.Drawing.Size(273, 21)
        Me.txtCustName.TabIndex = 3
        '
        'txtShortCustName
        '
        Me.txtShortCustName.Location = New System.Drawing.Point(171, 40)
        Me.txtShortCustName.Name = "txtShortCustName"
        Me.txtShortCustName.Size = New System.Drawing.Size(187, 21)
        Me.txtShortCustName.TabIndex = 2
        '
        'lblCustName
        '
        Me.lblCustName.BackColor = System.Drawing.Color.Silver
        Me.lblCustName.Location = New System.Drawing.Point(34, 80)
        Me.lblCustName.Name = "lblCustName"
        Me.lblCustName.Size = New System.Drawing.Size(97, 21)
        Me.lblCustName.TabIndex = 1
        Me.lblCustName.Text = "Name:"
        Me.lblCustName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblCustShortName
        '
        Me.lblCustShortName.BackColor = System.Drawing.Color.Silver
        Me.lblCustShortName.Location = New System.Drawing.Point(34, 40)
        Me.lblCustShortName.Name = "lblCustShortName"
        Me.lblCustShortName.Size = New System.Drawing.Size(97, 21)
        Me.lblCustShortName.TabIndex = 0
        Me.lblCustShortName.Text = "Short Name:"
        Me.lblCustShortName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridViewCustomers
        '
        Me.DataGridViewCustomers.AllowUserToAddRows = False
        Me.DataGridViewCustomers.AllowUserToDeleteRows = False
        Me.DataGridViewCustomers.AllowUserToResizeRows = False
        Me.DataGridViewCustomers.AutoGenerateColumns = False
        Me.DataGridViewCustomers.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewCustomers.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridViewCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewCustomers.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10})
        Me.DataGridViewCustomers.DataSource = Me.CustomersBindingSource
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewCustomers.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridViewCustomers.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridViewCustomers.GridColor = System.Drawing.Color.Silver
        Me.DataGridViewCustomers.Location = New System.Drawing.Point(6, 0)
        Me.DataGridViewCustomers.MultiSelect = False
        Me.DataGridViewCustomers.Name = "DataGridViewCustomers"
        Me.DataGridViewCustomers.ReadOnly = True
        Me.DataGridViewCustomers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewCustomers.Size = New System.Drawing.Size(529, 155)
        Me.DataGridViewCustomers.TabIndex = 1
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "ShortName"
        Me.DataGridViewTextBoxColumn9.HeaderText = "ShortName"
        Me.DataGridViewTextBoxColumn9.MaxInputLength = 500
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "Name"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'CustomersBindingSource
        '
        Me.CustomersBindingSource.DataMember = "Customers"
        Me.CustomersBindingSource.DataSource = Me.VPBSDataSet
        Me.CustomersBindingSource.Sort = "ShortName"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage5.Controls.Add(Me.GroupBox11)
        Me.TabPage5.Location = New System.Drawing.Point(4, 53)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(553, 303)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "User Names                 "
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.GroupBox12)
        Me.GroupBox11.Controls.Add(Me.DataGridViewUsers)
        Me.GroupBox11.Location = New System.Drawing.Point(7, 3)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(538, 299)
        Me.GroupBox11.TabIndex = 24
        Me.GroupBox11.TabStop = False
        '
        'GroupBox12
        '
        Me.GroupBox12.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox12.Controls.Add(Me.txtAddPassword)
        Me.GroupBox12.Controls.Add(Me.lblAddPassword)
        Me.GroupBox12.Controls.Add(Me.lblVerifyPassword)
        Me.GroupBox12.Controls.Add(Me.txtVerifyPassword)
        Me.GroupBox12.Controls.Add(Me.lblChangePassword)
        Me.GroupBox12.Controls.Add(Me.lblCurrentPassword)
        Me.GroupBox12.Controls.Add(Me.txtNewPassword)
        Me.GroupBox12.Controls.Add(Me.txtOldPassword)
        Me.GroupBox12.Controls.Add(Me.txtUserLevel)
        Me.GroupBox12.Controls.Add(Me.txtUserName)
        Me.GroupBox12.Controls.Add(Me.lblUserLevel)
        Me.GroupBox12.Controls.Add(Me.lblUserName)
        Me.GroupBox12.Location = New System.Drawing.Point(8, 156)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(524, 135)
        Me.GroupBox12.TabIndex = 1
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "User Names/Passwords"
        '
        'txtAddPassword
        '
        Me.txtAddPassword.Location = New System.Drawing.Point(145, 102)
        Me.txtAddPassword.Name = "txtAddPassword"
        Me.txtAddPassword.Size = New System.Drawing.Size(100, 21)
        Me.txtAddPassword.TabIndex = 11
        '
        'lblAddPassword
        '
        Me.lblAddPassword.BackColor = System.Drawing.Color.Silver
        Me.lblAddPassword.Location = New System.Drawing.Point(6, 102)
        Me.lblAddPassword.Name = "lblAddPassword"
        Me.lblAddPassword.Size = New System.Drawing.Size(114, 21)
        Me.lblAddPassword.TabIndex = 10
        Me.lblAddPassword.Text = "New Password:"
        Me.lblAddPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblVerifyPassword
        '
        Me.lblVerifyPassword.BackColor = System.Drawing.Color.Silver
        Me.lblVerifyPassword.Location = New System.Drawing.Point(277, 102)
        Me.lblVerifyPassword.Name = "lblVerifyPassword"
        Me.lblVerifyPassword.Size = New System.Drawing.Size(69, 21)
        Me.lblVerifyPassword.TabIndex = 9
        Me.lblVerifyPassword.Text = "Verify P/W:"
        Me.lblVerifyPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtVerifyPassword
        '
        Me.txtVerifyPassword.Location = New System.Drawing.Point(356, 102)
        Me.txtVerifyPassword.Name = "txtVerifyPassword"
        Me.txtVerifyPassword.Size = New System.Drawing.Size(100, 21)
        Me.txtVerifyPassword.TabIndex = 8
        '
        'lblChangePassword
        '
        Me.lblChangePassword.BackColor = System.Drawing.Color.Silver
        Me.lblChangePassword.Location = New System.Drawing.Point(277, 102)
        Me.lblChangePassword.Name = "lblChangePassword"
        Me.lblChangePassword.Size = New System.Drawing.Size(69, 21)
        Me.lblChangePassword.TabIndex = 7
        Me.lblChangePassword.Text = "Change to:"
        Me.lblChangePassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblCurrentPassword
        '
        Me.lblCurrentPassword.BackColor = System.Drawing.Color.Silver
        Me.lblCurrentPassword.Location = New System.Drawing.Point(6, 102)
        Me.lblCurrentPassword.Name = "lblCurrentPassword"
        Me.lblCurrentPassword.Size = New System.Drawing.Size(114, 21)
        Me.lblCurrentPassword.TabIndex = 6
        Me.lblCurrentPassword.Text = "Current Password:"
        Me.lblCurrentPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtNewPassword
        '
        Me.txtNewPassword.Location = New System.Drawing.Point(356, 102)
        Me.txtNewPassword.Name = "txtNewPassword"
        Me.txtNewPassword.Size = New System.Drawing.Size(100, 21)
        Me.txtNewPassword.TabIndex = 5
        '
        'txtOldPassword
        '
        Me.txtOldPassword.Location = New System.Drawing.Point(145, 102)
        Me.txtOldPassword.Name = "txtOldPassword"
        Me.txtOldPassword.Size = New System.Drawing.Size(100, 21)
        Me.txtOldPassword.TabIndex = 4
        '
        'txtUserLevel
        '
        Me.txtUserLevel.Location = New System.Drawing.Point(145, 65)
        Me.txtUserLevel.Name = "txtUserLevel"
        Me.txtUserLevel.Size = New System.Drawing.Size(311, 21)
        Me.txtUserLevel.TabIndex = 3
        '
        'txtUserName
        '
        Me.txtUserName.Location = New System.Drawing.Point(145, 28)
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.Size = New System.Drawing.Size(311, 21)
        Me.txtUserName.TabIndex = 2
        '
        'lblUserLevel
        '
        Me.lblUserLevel.BackColor = System.Drawing.Color.Silver
        Me.lblUserLevel.Location = New System.Drawing.Point(6, 65)
        Me.lblUserLevel.Name = "lblUserLevel"
        Me.lblUserLevel.Size = New System.Drawing.Size(97, 21)
        Me.lblUserLevel.TabIndex = 1
        Me.lblUserLevel.Text = "User Level:"
        Me.lblUserLevel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblUserName
        '
        Me.lblUserName.BackColor = System.Drawing.Color.Silver
        Me.lblUserName.Location = New System.Drawing.Point(6, 28)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(97, 21)
        Me.lblUserName.TabIndex = 0
        Me.lblUserName.Text = "User Name:"
        Me.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridViewUsers
        '
        Me.DataGridViewUsers.AllowUserToAddRows = False
        Me.DataGridViewUsers.AllowUserToDeleteRows = False
        Me.DataGridViewUsers.AllowUserToResizeRows = False
        Me.DataGridViewUsers.AutoGenerateColumns = False
        Me.DataGridViewUsers.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewUsers.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridViewUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewUsers.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.UserNameDataGridViewTextBoxColumn, Me.UserLevelDataGridViewTextBoxColumn, Me.PasswordDataGridViewTextBoxColumn})
        Me.DataGridViewUsers.DataSource = Me.UsersBindingSource
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewUsers.DefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridViewUsers.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridViewUsers.GridColor = System.Drawing.Color.Silver
        Me.DataGridViewUsers.Location = New System.Drawing.Point(6, 0)
        Me.DataGridViewUsers.MultiSelect = False
        Me.DataGridViewUsers.Name = "DataGridViewUsers"
        Me.DataGridViewUsers.ReadOnly = True
        Me.DataGridViewUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewUsers.ShowEditingIcon = False
        Me.DataGridViewUsers.Size = New System.Drawing.Size(529, 155)
        Me.DataGridViewUsers.TabIndex = 0
        '
        'UserNameDataGridViewTextBoxColumn
        '
        Me.UserNameDataGridViewTextBoxColumn.DataPropertyName = "UserName"
        Me.UserNameDataGridViewTextBoxColumn.HeaderText = "UserName"
        Me.UserNameDataGridViewTextBoxColumn.Name = "UserNameDataGridViewTextBoxColumn"
        Me.UserNameDataGridViewTextBoxColumn.ReadOnly = True
        Me.UserNameDataGridViewTextBoxColumn.Width = 180
        '
        'UserLevelDataGridViewTextBoxColumn
        '
        Me.UserLevelDataGridViewTextBoxColumn.DataPropertyName = "UserLevel"
        Me.UserLevelDataGridViewTextBoxColumn.HeaderText = "UserLevel"
        Me.UserLevelDataGridViewTextBoxColumn.Name = "UserLevelDataGridViewTextBoxColumn"
        Me.UserLevelDataGridViewTextBoxColumn.ReadOnly = True
        Me.UserLevelDataGridViewTextBoxColumn.Width = 180
        '
        'PasswordDataGridViewTextBoxColumn
        '
        Me.PasswordDataGridViewTextBoxColumn.DataPropertyName = "Password"
        Me.PasswordDataGridViewTextBoxColumn.HeaderText = "Password"
        Me.PasswordDataGridViewTextBoxColumn.Name = "PasswordDataGridViewTextBoxColumn"
        Me.PasswordDataGridViewTextBoxColumn.ReadOnly = True
        Me.PasswordDataGridViewTextBoxColumn.Width = 110
        '
        'UsersBindingSource
        '
        Me.UsersBindingSource.DataMember = "Users"
        Me.UsersBindingSource.DataSource = Me.VPBSDataSet
        Me.UsersBindingSource.Sort = "UserName"
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabPage8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage8.Controls.Add(Me.GroupBox7)
        Me.TabPage8.Location = New System.Drawing.Point(4, 53)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(553, 303)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Analysis Codes              "
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.GroupBox8)
        Me.GroupBox7.Controls.Add(Me.DataGridViewAnalysisCodes)
        Me.GroupBox7.Location = New System.Drawing.Point(7, 3)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(538, 299)
        Me.GroupBox7.TabIndex = 24
        Me.GroupBox7.TabStop = False
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox8.Controls.Add(Me.txtAnalysisDesc)
        Me.GroupBox8.Controls.Add(Me.txtAnalysisCode)
        Me.GroupBox8.Controls.Add(Me.lblAnalysisDesc)
        Me.GroupBox8.Controls.Add(Me.lblAnalysisCode)
        Me.GroupBox8.Location = New System.Drawing.Point(8, 156)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(524, 135)
        Me.GroupBox8.TabIndex = 1
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Analysis Codes"
        '
        'txtAnalysisDesc
        '
        Me.txtAnalysisDesc.Location = New System.Drawing.Point(171, 80)
        Me.txtAnalysisDesc.Name = "txtAnalysisDesc"
        Me.txtAnalysisDesc.Size = New System.Drawing.Size(273, 21)
        Me.txtAnalysisDesc.TabIndex = 3
        '
        'txtAnalysisCode
        '
        Me.txtAnalysisCode.Location = New System.Drawing.Point(171, 40)
        Me.txtAnalysisCode.Name = "txtAnalysisCode"
        Me.txtAnalysisCode.Size = New System.Drawing.Size(187, 21)
        Me.txtAnalysisCode.TabIndex = 2
        '
        'lblAnalysisDesc
        '
        Me.lblAnalysisDesc.BackColor = System.Drawing.Color.Silver
        Me.lblAnalysisDesc.Location = New System.Drawing.Point(34, 80)
        Me.lblAnalysisDesc.Name = "lblAnalysisDesc"
        Me.lblAnalysisDesc.Size = New System.Drawing.Size(97, 21)
        Me.lblAnalysisDesc.TabIndex = 1
        Me.lblAnalysisDesc.Text = "Description:"
        Me.lblAnalysisDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAnalysisCode
        '
        Me.lblAnalysisCode.BackColor = System.Drawing.Color.Silver
        Me.lblAnalysisCode.Location = New System.Drawing.Point(34, 40)
        Me.lblAnalysisCode.Name = "lblAnalysisCode"
        Me.lblAnalysisCode.Size = New System.Drawing.Size(97, 21)
        Me.lblAnalysisCode.TabIndex = 0
        Me.lblAnalysisCode.Text = "Code:"
        Me.lblAnalysisCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridViewAnalysisCodes
        '
        Me.DataGridViewAnalysisCodes.AllowUserToDeleteRows = False
        Me.DataGridViewAnalysisCodes.AllowUserToResizeRows = False
        Me.DataGridViewAnalysisCodes.AutoGenerateColumns = False
        Me.DataGridViewAnalysisCodes.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewAnalysisCodes.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.DataGridViewAnalysisCodes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewAnalysisCodes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.DataGridViewAnalysisCodes.DataSource = Me.AnalysisBindingSource
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewAnalysisCodes.DefaultCellStyle = DataGridViewCellStyle10
        Me.DataGridViewAnalysisCodes.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridViewAnalysisCodes.GridColor = System.Drawing.Color.Silver
        Me.DataGridViewAnalysisCodes.Location = New System.Drawing.Point(6, 0)
        Me.DataGridViewAnalysisCodes.MultiSelect = False
        Me.DataGridViewAnalysisCodes.Name = "DataGridViewAnalysisCodes"
        Me.DataGridViewAnalysisCodes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewAnalysisCodes.Size = New System.Drawing.Size(529, 155)
        Me.DataGridViewAnalysisCodes.TabIndex = 0
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Code"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Code"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Description"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'AnalysisBindingSource
        '
        Me.AnalysisBindingSource.DataMember = "Analysis"
        Me.AnalysisBindingSource.DataSource = Me.VPBSDataSet
        Me.AnalysisBindingSource.Sort = "Code"
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabPage9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage9.Controls.Add(Me.GroupBox9)
        Me.TabPage9.Location = New System.Drawing.Point(4, 53)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(553, 303)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "G L Codes                     "
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox9.Controls.Add(Me.GroupBox10)
        Me.GroupBox9.Controls.Add(Me.DataGridViewGLCodes)
        Me.GroupBox9.Location = New System.Drawing.Point(7, 3)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(538, 299)
        Me.GroupBox9.TabIndex = 25
        Me.GroupBox9.TabStop = False
        '
        'GroupBox10
        '
        Me.GroupBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox10.Controls.Add(Me.txtGLCodeDesc)
        Me.GroupBox10.Controls.Add(Me.txtGLCodeCode)
        Me.GroupBox10.Controls.Add(Me.lblGLCodeDesc)
        Me.GroupBox10.Controls.Add(Me.lblGLCodeCode)
        Me.GroupBox10.Location = New System.Drawing.Point(8, 156)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(524, 135)
        Me.GroupBox10.TabIndex = 1
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "General Ledger Codes"
        '
        'txtGLCodeDesc
        '
        Me.txtGLCodeDesc.Location = New System.Drawing.Point(171, 80)
        Me.txtGLCodeDesc.Name = "txtGLCodeDesc"
        Me.txtGLCodeDesc.Size = New System.Drawing.Size(273, 21)
        Me.txtGLCodeDesc.TabIndex = 3
        '
        'txtGLCodeCode
        '
        Me.txtGLCodeCode.Location = New System.Drawing.Point(171, 40)
        Me.txtGLCodeCode.Name = "txtGLCodeCode"
        Me.txtGLCodeCode.Size = New System.Drawing.Size(187, 21)
        Me.txtGLCodeCode.TabIndex = 2
        '
        'lblGLCodeDesc
        '
        Me.lblGLCodeDesc.BackColor = System.Drawing.Color.Silver
        Me.lblGLCodeDesc.Location = New System.Drawing.Point(34, 80)
        Me.lblGLCodeDesc.Name = "lblGLCodeDesc"
        Me.lblGLCodeDesc.Size = New System.Drawing.Size(97, 21)
        Me.lblGLCodeDesc.TabIndex = 1
        Me.lblGLCodeDesc.Text = "Description:"
        Me.lblGLCodeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblGLCodeCode
        '
        Me.lblGLCodeCode.BackColor = System.Drawing.Color.Silver
        Me.lblGLCodeCode.Location = New System.Drawing.Point(34, 40)
        Me.lblGLCodeCode.Name = "lblGLCodeCode"
        Me.lblGLCodeCode.Size = New System.Drawing.Size(97, 21)
        Me.lblGLCodeCode.TabIndex = 0
        Me.lblGLCodeCode.Text = "Code:"
        Me.lblGLCodeCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridViewGLCodes
        '
        Me.DataGridViewGLCodes.AllowUserToAddRows = False
        Me.DataGridViewGLCodes.AllowUserToResizeRows = False
        Me.DataGridViewGLCodes.AutoGenerateColumns = False
        Me.DataGridViewGLCodes.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewGLCodes.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.DataGridViewGLCodes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewGLCodes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.DataGridViewGLCodes.DataSource = Me.GLCodeBindingSource
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewGLCodes.DefaultCellStyle = DataGridViewCellStyle12
        Me.DataGridViewGLCodes.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridViewGLCodes.GridColor = System.Drawing.Color.Silver
        Me.DataGridViewGLCodes.Location = New System.Drawing.Point(6, 0)
        Me.DataGridViewGLCodes.MultiSelect = False
        Me.DataGridViewGLCodes.Name = "DataGridViewGLCodes"
        Me.DataGridViewGLCodes.ReadOnly = True
        Me.DataGridViewGLCodes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewGLCodes.Size = New System.Drawing.Size(529, 155)
        Me.DataGridViewGLCodes.TabIndex = 0
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Code"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Code"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Description"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'GLCodeBindingSource
        '
        Me.GLCodeBindingSource.DataMember = "GLCode"
        Me.GLCodeBindingSource.DataSource = Me.VPBSDataSet
        Me.GLCodeBindingSource.Sort = "Code"
        '
        'TabPage10
        '
        Me.TabPage10.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabPage10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage10.Controls.Add(Me.GroupBox2)
        Me.TabPage10.Location = New System.Drawing.Point(4, 53)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(553, 303)
        Me.TabPage10.TabIndex = 9
        Me.TabPage10.Text = "Budgets                              "
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.GroupBox15)
        Me.GroupBox2.Controls.Add(Me.DataGridViewBudgets)
        Me.GroupBox2.Location = New System.Drawing.Point(1, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(552, 299)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        '
        'GroupBox15
        '
        Me.GroupBox15.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox15.Controls.Add(Me.cboActivate)
        Me.GroupBox15.Controls.Add(Me.cboRefresh)
        Me.GroupBox15.Controls.Add(Me.cboStartMonth)
        Me.GroupBox15.Controls.Add(Me.cboBudgetType)
        Me.GroupBox15.Controls.Add(Me.txtPeriodTo)
        Me.GroupBox15.Controls.Add(Me.txtPeriodFrom)
        Me.GroupBox15.Controls.Add(Me.lblPeriodTo)
        Me.GroupBox15.Controls.Add(Me.lblActivate)
        Me.GroupBox15.Controls.Add(Me.lblPeriodFrom)
        Me.GroupBox15.Controls.Add(Me.lblRefresh)
        Me.GroupBox15.Controls.Add(Me.lblBudgetStartMonth)
        Me.GroupBox15.Controls.Add(Me.lblBudgetType)
        Me.GroupBox15.Controls.Add(Me.txtBudgetDesc)
        Me.GroupBox15.Controls.Add(Me.txtBudgetNo)
        Me.GroupBox15.Controls.Add(Me.lblBudgetDesc)
        Me.GroupBox15.Controls.Add(Me.lblBudgetNo)
        Me.GroupBox15.Location = New System.Drawing.Point(8, 157)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(534, 135)
        Me.GroupBox15.TabIndex = 1
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Budgets"
        '
        'cboActivate
        '
        Me.cboActivate.FormattingEnabled = True
        Me.cboActivate.Location = New System.Drawing.Point(458, 65)
        Me.cboActivate.Name = "cboActivate"
        Me.cboActivate.Size = New System.Drawing.Size(69, 23)
        Me.cboActivate.TabIndex = 15
        '
        'cboRefresh
        '
        Me.cboRefresh.FormattingEnabled = True
        Me.cboRefresh.Location = New System.Drawing.Point(317, 65)
        Me.cboRefresh.Name = "cboRefresh"
        Me.cboRefresh.Size = New System.Drawing.Size(69, 23)
        Me.cboRefresh.TabIndex = 14
        '
        'cboStartMonth
        '
        Me.cboStartMonth.FormattingEnabled = True
        Me.cboStartMonth.Location = New System.Drawing.Point(109, 102)
        Me.cboStartMonth.Name = "cboStartMonth"
        Me.cboStartMonth.Size = New System.Drawing.Size(99, 23)
        Me.cboStartMonth.TabIndex = 13
        '
        'cboBudgetType
        '
        Me.cboBudgetType.FormattingEnabled = True
        Me.cboBudgetType.Location = New System.Drawing.Point(109, 65)
        Me.cboBudgetType.Name = "cboBudgetType"
        Me.cboBudgetType.Size = New System.Drawing.Size(99, 23)
        Me.cboBudgetType.TabIndex = 12
        '
        'txtPeriodTo
        '
        Me.txtPeriodTo.Location = New System.Drawing.Point(459, 102)
        Me.txtPeriodTo.Name = "txtPeriodTo"
        Me.txtPeriodTo.Size = New System.Drawing.Size(68, 21)
        Me.txtPeriodTo.TabIndex = 11
        '
        'txtPeriodFrom
        '
        Me.txtPeriodFrom.Location = New System.Drawing.Point(317, 102)
        Me.txtPeriodFrom.Name = "txtPeriodFrom"
        Me.txtPeriodFrom.Size = New System.Drawing.Size(68, 21)
        Me.txtPeriodFrom.TabIndex = 10
        '
        'lblPeriodTo
        '
        Me.lblPeriodTo.BackColor = System.Drawing.Color.Silver
        Me.lblPeriodTo.Location = New System.Drawing.Point(391, 102)
        Me.lblPeriodTo.Name = "lblPeriodTo"
        Me.lblPeriodTo.Size = New System.Drawing.Size(62, 21)
        Me.lblPeriodTo.TabIndex = 9
        Me.lblPeriodTo.Text = "To:"
        Me.lblPeriodTo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblActivate
        '
        Me.lblActivate.BackColor = System.Drawing.Color.Silver
        Me.lblActivate.Location = New System.Drawing.Point(391, 65)
        Me.lblActivate.Name = "lblActivate"
        Me.lblActivate.Size = New System.Drawing.Size(62, 21)
        Me.lblActivate.TabIndex = 8
        Me.lblActivate.Text = "Activate?:"
        Me.lblActivate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblPeriodFrom
        '
        Me.lblPeriodFrom.BackColor = System.Drawing.Color.Silver
        Me.lblPeriodFrom.Location = New System.Drawing.Point(214, 102)
        Me.lblPeriodFrom.Name = "lblPeriodFrom"
        Me.lblPeriodFrom.Size = New System.Drawing.Size(97, 21)
        Me.lblPeriodFrom.TabIndex = 7
        Me.lblPeriodFrom.Text = "Period From:"
        Me.lblPeriodFrom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRefresh
        '
        Me.lblRefresh.BackColor = System.Drawing.Color.Silver
        Me.lblRefresh.Location = New System.Drawing.Point(214, 65)
        Me.lblRefresh.Name = "lblRefresh"
        Me.lblRefresh.Size = New System.Drawing.Size(97, 21)
        Me.lblRefresh.TabIndex = 6
        Me.lblRefresh.Text = "Refresh?:"
        Me.lblRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblBudgetStartMonth
        '
        Me.lblBudgetStartMonth.BackColor = System.Drawing.Color.Silver
        Me.lblBudgetStartMonth.Location = New System.Drawing.Point(6, 102)
        Me.lblBudgetStartMonth.Name = "lblBudgetStartMonth"
        Me.lblBudgetStartMonth.Size = New System.Drawing.Size(97, 21)
        Me.lblBudgetStartMonth.TabIndex = 5
        Me.lblBudgetStartMonth.Text = "Start Month:"
        Me.lblBudgetStartMonth.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblBudgetType
        '
        Me.lblBudgetType.BackColor = System.Drawing.Color.Silver
        Me.lblBudgetType.Location = New System.Drawing.Point(6, 65)
        Me.lblBudgetType.Name = "lblBudgetType"
        Me.lblBudgetType.Size = New System.Drawing.Size(97, 21)
        Me.lblBudgetType.TabIndex = 4
        Me.lblBudgetType.Text = "Budget Type:"
        Me.lblBudgetType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtBudgetDesc
        '
        Me.txtBudgetDesc.Location = New System.Drawing.Point(317, 28)
        Me.txtBudgetDesc.Name = "txtBudgetDesc"
        Me.txtBudgetDesc.Size = New System.Drawing.Size(210, 21)
        Me.txtBudgetDesc.TabIndex = 3
        '
        'txtBudgetNo
        '
        Me.txtBudgetNo.Location = New System.Drawing.Point(109, 28)
        Me.txtBudgetNo.Name = "txtBudgetNo"
        Me.txtBudgetNo.Size = New System.Drawing.Size(99, 21)
        Me.txtBudgetNo.TabIndex = 2
        '
        'lblBudgetDesc
        '
        Me.lblBudgetDesc.BackColor = System.Drawing.Color.Silver
        Me.lblBudgetDesc.Location = New System.Drawing.Point(214, 28)
        Me.lblBudgetDesc.Name = "lblBudgetDesc"
        Me.lblBudgetDesc.Size = New System.Drawing.Size(97, 21)
        Me.lblBudgetDesc.TabIndex = 1
        Me.lblBudgetDesc.Text = "Description:"
        Me.lblBudgetDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblBudgetNo
        '
        Me.lblBudgetNo.BackColor = System.Drawing.Color.Silver
        Me.lblBudgetNo.Location = New System.Drawing.Point(6, 28)
        Me.lblBudgetNo.Name = "lblBudgetNo"
        Me.lblBudgetNo.Size = New System.Drawing.Size(97, 21)
        Me.lblBudgetNo.TabIndex = 0
        Me.lblBudgetNo.Text = "Budget No:"
        Me.lblBudgetNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridViewBudgets
        '
        Me.DataGridViewBudgets.AllowUserToAddRows = False
        Me.DataGridViewBudgets.AllowUserToResizeRows = False
        Me.DataGridViewBudgets.AutoGenerateColumns = False
        Me.DataGridViewBudgets.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewBudgets.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.DataGridViewBudgets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewBudgets.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BudgetNoDataGridViewTextBoxColumn, Me.BudgetTypeDataGridViewTextBoxColumn, Me.DescriptionDataGridViewTextBoxColumn, Me.PeriodFromDataGridViewTextBoxColumn, Me.PeriodToDataGridViewTextBoxColumn, Me.StartMonthDataGridViewTextBoxColumn, Me.StatusDataGridViewTextBoxColumn, Me.RefreshReqdDataGridViewTextBoxColumn})
        Me.DataGridViewBudgets.DataSource = Me.DirbudBindingSource
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewBudgets.DefaultCellStyle = DataGridViewCellStyle14
        Me.DataGridViewBudgets.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridViewBudgets.GridColor = System.Drawing.Color.Silver
        Me.DataGridViewBudgets.Location = New System.Drawing.Point(12, 1)
        Me.DataGridViewBudgets.MultiSelect = False
        Me.DataGridViewBudgets.Name = "DataGridViewBudgets"
        Me.DataGridViewBudgets.ReadOnly = True
        Me.DataGridViewBudgets.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewBudgets.Size = New System.Drawing.Size(529, 155)
        Me.DataGridViewBudgets.TabIndex = 0
        '
        'BudgetNoDataGridViewTextBoxColumn
        '
        Me.BudgetNoDataGridViewTextBoxColumn.DataPropertyName = "BudgetNo"
        Me.BudgetNoDataGridViewTextBoxColumn.HeaderText = "BudgetNo"
        Me.BudgetNoDataGridViewTextBoxColumn.Name = "BudgetNoDataGridViewTextBoxColumn"
        Me.BudgetNoDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BudgetTypeDataGridViewTextBoxColumn
        '
        Me.BudgetTypeDataGridViewTextBoxColumn.DataPropertyName = "BudgetType"
        Me.BudgetTypeDataGridViewTextBoxColumn.HeaderText = "BudgetType"
        Me.BudgetTypeDataGridViewTextBoxColumn.Name = "BudgetTypeDataGridViewTextBoxColumn"
        Me.BudgetTypeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DescriptionDataGridViewTextBoxColumn
        '
        Me.DescriptionDataGridViewTextBoxColumn.DataPropertyName = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.HeaderText = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.Name = "DescriptionDataGridViewTextBoxColumn"
        Me.DescriptionDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PeriodFromDataGridViewTextBoxColumn
        '
        Me.PeriodFromDataGridViewTextBoxColumn.DataPropertyName = "PeriodFrom"
        Me.PeriodFromDataGridViewTextBoxColumn.HeaderText = "PeriodFrom"
        Me.PeriodFromDataGridViewTextBoxColumn.Name = "PeriodFromDataGridViewTextBoxColumn"
        Me.PeriodFromDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PeriodToDataGridViewTextBoxColumn
        '
        Me.PeriodToDataGridViewTextBoxColumn.DataPropertyName = "PeriodTo"
        Me.PeriodToDataGridViewTextBoxColumn.HeaderText = "PeriodTo"
        Me.PeriodToDataGridViewTextBoxColumn.Name = "PeriodToDataGridViewTextBoxColumn"
        Me.PeriodToDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StartMonthDataGridViewTextBoxColumn
        '
        Me.StartMonthDataGridViewTextBoxColumn.DataPropertyName = "StartMonth"
        Me.StartMonthDataGridViewTextBoxColumn.HeaderText = "StartMonth"
        Me.StartMonthDataGridViewTextBoxColumn.Name = "StartMonthDataGridViewTextBoxColumn"
        Me.StartMonthDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StatusDataGridViewTextBoxColumn
        '
        Me.StatusDataGridViewTextBoxColumn.DataPropertyName = "Status"
        Me.StatusDataGridViewTextBoxColumn.HeaderText = "Status"
        Me.StatusDataGridViewTextBoxColumn.Name = "StatusDataGridViewTextBoxColumn"
        Me.StatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'RefreshReqdDataGridViewTextBoxColumn
        '
        Me.RefreshReqdDataGridViewTextBoxColumn.DataPropertyName = "RefreshReqd"
        Me.RefreshReqdDataGridViewTextBoxColumn.HeaderText = "RefreshReqd"
        Me.RefreshReqdDataGridViewTextBoxColumn.Name = "RefreshReqdDataGridViewTextBoxColumn"
        Me.RefreshReqdDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DirbudBindingSource
        '
        Me.DirbudBindingSource.DataMember = "dirbud"
        Me.DirbudBindingSource.DataSource = Me.VPBSDataSet
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage4.Controls.Add(Me.GroupBox16)
        Me.TabPage4.Location = New System.Drawing.Point(4, 53)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(553, 303)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Currences                     "
        '
        'GroupBox16
        '
        Me.GroupBox16.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox16.Controls.Add(Me.GroupBox17)
        Me.GroupBox16.Controls.Add(Me.DataGridViewCurrencies)
        Me.GroupBox16.Location = New System.Drawing.Point(7, 2)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Size = New System.Drawing.Size(538, 299)
        Me.GroupBox16.TabIndex = 26
        Me.GroupBox16.TabStop = False
        '
        'GroupBox17
        '
        Me.GroupBox17.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GroupBox17.Controls.Add(Me.lblDorM)
        Me.GroupBox17.Controls.Add(Me.lblNofDecPlaces)
        Me.GroupBox17.Controls.Add(Me.lblBaseCCY)
        Me.GroupBox17.Controls.Add(Me.lblRate)
        Me.GroupBox17.Controls.Add(Me.txtBaseCCY)
        Me.GroupBox17.Controls.Add(Me.txtDorM)
        Me.GroupBox17.Controls.Add(Me.txtDecPlaces)
        Me.GroupBox17.Controls.Add(Me.txtRate)
        Me.GroupBox17.Controls.Add(Me.txtCurrencyDesc)
        Me.GroupBox17.Controls.Add(Me.txtCurrencyCode)
        Me.GroupBox17.Controls.Add(Me.lblCCYDesc)
        Me.GroupBox17.Controls.Add(Me.lblCCYCode)
        Me.GroupBox17.Location = New System.Drawing.Point(8, 157)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Size = New System.Drawing.Size(524, 135)
        Me.GroupBox17.TabIndex = 1
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "Currencies"
        '
        'lblDorM
        '
        Me.lblDorM.BackColor = System.Drawing.Color.Silver
        Me.lblDorM.Location = New System.Drawing.Point(183, 102)
        Me.lblDorM.Name = "lblDorM"
        Me.lblDorM.Size = New System.Drawing.Size(132, 21)
        Me.lblDorM.TabIndex = 11
        Me.lblDorM.Text = "Divide or Multiply:"
        Me.lblDorM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblNofDecPlaces
        '
        Me.lblNofDecPlaces.BackColor = System.Drawing.Color.Silver
        Me.lblNofDecPlaces.Location = New System.Drawing.Point(183, 28)
        Me.lblNofDecPlaces.Name = "lblNofDecPlaces"
        Me.lblNofDecPlaces.Size = New System.Drawing.Size(132, 21)
        Me.lblNofDecPlaces.TabIndex = 10
        Me.lblNofDecPlaces.Text = "No. of Decimal Places:"
        Me.lblNofDecPlaces.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblBaseCCY
        '
        Me.lblBaseCCY.BackColor = System.Drawing.Color.Silver
        Me.lblBaseCCY.Location = New System.Drawing.Point(376, 28)
        Me.lblBaseCCY.Name = "lblBaseCCY"
        Me.lblBaseCCY.Size = New System.Drawing.Size(98, 21)
        Me.lblBaseCCY.TabIndex = 9
        Me.lblBaseCCY.Text = "Base CCY? Y/N:"
        Me.lblBaseCCY.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRate
        '
        Me.lblRate.BackColor = System.Drawing.Color.Silver
        Me.lblRate.Location = New System.Drawing.Point(6, 102)
        Me.lblRate.Name = "lblRate"
        Me.lblRate.Size = New System.Drawing.Size(85, 21)
        Me.lblRate.TabIndex = 8
        Me.lblRate.Text = "Rate:"
        Me.lblRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtBaseCCY
        '
        Me.txtBaseCCY.Location = New System.Drawing.Point(480, 28)
        Me.txtBaseCCY.Name = "txtBaseCCY"
        Me.txtBaseCCY.Size = New System.Drawing.Size(38, 21)
        Me.txtBaseCCY.TabIndex = 7
        '
        'txtDorM
        '
        Me.txtDorM.Location = New System.Drawing.Point(321, 102)
        Me.txtDorM.Name = "txtDorM"
        Me.txtDorM.Size = New System.Drawing.Size(38, 21)
        Me.txtDorM.TabIndex = 6
        '
        'txtDecPlaces
        '
        Me.txtDecPlaces.Location = New System.Drawing.Point(321, 28)
        Me.txtDecPlaces.Name = "txtDecPlaces"
        Me.txtDecPlaces.Size = New System.Drawing.Size(38, 21)
        Me.txtDecPlaces.TabIndex = 5
        '
        'txtRate
        '
        Me.txtRate.Location = New System.Drawing.Point(97, 102)
        Me.txtRate.Name = "txtRate"
        Me.txtRate.Size = New System.Drawing.Size(75, 21)
        Me.txtRate.TabIndex = 4
        '
        'txtCurrencyDesc
        '
        Me.txtCurrencyDesc.Location = New System.Drawing.Point(97, 65)
        Me.txtCurrencyDesc.Name = "txtCurrencyDesc"
        Me.txtCurrencyDesc.Size = New System.Drawing.Size(262, 21)
        Me.txtCurrencyDesc.TabIndex = 3
        '
        'txtCurrencyCode
        '
        Me.txtCurrencyCode.Location = New System.Drawing.Point(97, 28)
        Me.txtCurrencyCode.Name = "txtCurrencyCode"
        Me.txtCurrencyCode.Size = New System.Drawing.Size(75, 21)
        Me.txtCurrencyCode.TabIndex = 2
        '
        'lblCCYDesc
        '
        Me.lblCCYDesc.BackColor = System.Drawing.Color.Silver
        Me.lblCCYDesc.Location = New System.Drawing.Point(6, 65)
        Me.lblCCYDesc.Name = "lblCCYDesc"
        Me.lblCCYDesc.Size = New System.Drawing.Size(85, 21)
        Me.lblCCYDesc.TabIndex = 1
        Me.lblCCYDesc.Text = "Description:"
        Me.lblCCYDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblCCYCode
        '
        Me.lblCCYCode.BackColor = System.Drawing.Color.Silver
        Me.lblCCYCode.Location = New System.Drawing.Point(6, 28)
        Me.lblCCYCode.Name = "lblCCYCode"
        Me.lblCCYCode.Size = New System.Drawing.Size(85, 21)
        Me.lblCCYCode.TabIndex = 0
        Me.lblCCYCode.Text = "Code:"
        Me.lblCCYCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridViewCurrencies
        '
        Me.DataGridViewCurrencies.AllowUserToAddRows = False
        Me.DataGridViewCurrencies.AllowUserToResizeRows = False
        Me.DataGridViewCurrencies.AutoGenerateColumns = False
        Me.DataGridViewCurrencies.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewCurrencies.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.DataGridViewCurrencies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewCurrencies.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CodeDataGridViewTextBoxColumn, Me.DescriptionDataGridViewTextBoxColumn1, Me.RateDataGridViewTextBoxColumn, Me.DateDataGridViewTextBoxColumn, Me.TypeDataGridViewTextBoxColumn, Me.DecimalPlacesDataGridViewTextBoxColumn, Me.BaseCCYDataGridViewTextBoxColumn})
        Me.DataGridViewCurrencies.DataSource = Me.CurrenciesBindingSource
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewCurrencies.DefaultCellStyle = DataGridViewCellStyle17
        Me.DataGridViewCurrencies.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridViewCurrencies.GridColor = System.Drawing.Color.Silver
        Me.DataGridViewCurrencies.Location = New System.Drawing.Point(6, 1)
        Me.DataGridViewCurrencies.MultiSelect = False
        Me.DataGridViewCurrencies.Name = "DataGridViewCurrencies"
        Me.DataGridViewCurrencies.ReadOnly = True
        Me.DataGridViewCurrencies.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewCurrencies.Size = New System.Drawing.Size(529, 155)
        Me.DataGridViewCurrencies.TabIndex = 0
        '
        'CodeDataGridViewTextBoxColumn
        '
        Me.CodeDataGridViewTextBoxColumn.DataPropertyName = "Code"
        Me.CodeDataGridViewTextBoxColumn.HeaderText = "Code"
        Me.CodeDataGridViewTextBoxColumn.Name = "CodeDataGridViewTextBoxColumn"
        Me.CodeDataGridViewTextBoxColumn.ReadOnly = True
        Me.CodeDataGridViewTextBoxColumn.Width = 50
        '
        'DescriptionDataGridViewTextBoxColumn1
        '
        Me.DescriptionDataGridViewTextBoxColumn1.DataPropertyName = "Description"
        Me.DescriptionDataGridViewTextBoxColumn1.HeaderText = "Description"
        Me.DescriptionDataGridViewTextBoxColumn1.Name = "DescriptionDataGridViewTextBoxColumn1"
        Me.DescriptionDataGridViewTextBoxColumn1.ReadOnly = True
        Me.DescriptionDataGridViewTextBoxColumn1.Width = 150
        '
        'RateDataGridViewTextBoxColumn
        '
        Me.RateDataGridViewTextBoxColumn.DataPropertyName = "Rate"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle16.Format = "N2"
        DataGridViewCellStyle16.NullValue = Nothing
        Me.RateDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle16
        Me.RateDataGridViewTextBoxColumn.HeaderText = "Rate"
        Me.RateDataGridViewTextBoxColumn.Name = "RateDataGridViewTextBoxColumn"
        Me.RateDataGridViewTextBoxColumn.ReadOnly = True
        Me.RateDataGridViewTextBoxColumn.Width = 80
        '
        'DateDataGridViewTextBoxColumn
        '
        Me.DateDataGridViewTextBoxColumn.DataPropertyName = "Date"
        Me.DateDataGridViewTextBoxColumn.HeaderText = "Date"
        Me.DateDataGridViewTextBoxColumn.Name = "DateDataGridViewTextBoxColumn"
        Me.DateDataGridViewTextBoxColumn.ReadOnly = True
        Me.DateDataGridViewTextBoxColumn.Width = 120
        '
        'TypeDataGridViewTextBoxColumn
        '
        Me.TypeDataGridViewTextBoxColumn.DataPropertyName = "Type"
        Me.TypeDataGridViewTextBoxColumn.HeaderText = "Type"
        Me.TypeDataGridViewTextBoxColumn.Name = "TypeDataGridViewTextBoxColumn"
        Me.TypeDataGridViewTextBoxColumn.ReadOnly = True
        Me.TypeDataGridViewTextBoxColumn.Width = 80
        '
        'DecimalPlacesDataGridViewTextBoxColumn
        '
        Me.DecimalPlacesDataGridViewTextBoxColumn.DataPropertyName = "DecimalPlaces"
        Me.DecimalPlacesDataGridViewTextBoxColumn.HeaderText = "DecimalPlaces"
        Me.DecimalPlacesDataGridViewTextBoxColumn.Name = "DecimalPlacesDataGridViewTextBoxColumn"
        Me.DecimalPlacesDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BaseCCYDataGridViewTextBoxColumn
        '
        Me.BaseCCYDataGridViewTextBoxColumn.DataPropertyName = "BaseCCY"
        Me.BaseCCYDataGridViewTextBoxColumn.HeaderText = "BaseCCY"
        Me.BaseCCYDataGridViewTextBoxColumn.Name = "BaseCCYDataGridViewTextBoxColumn"
        Me.BaseCCYDataGridViewTextBoxColumn.ReadOnly = True
        Me.BaseCCYDataGridViewTextBoxColumn.Width = 80
        '
        'CurrenciesBindingSource
        '
        Me.CurrenciesBindingSource.DataMember = "Currencies"
        Me.CurrenciesBindingSource.DataSource = Me.VPBSDataSet
        '
        'VPBSTestDataSet
        '
        Me.VPBSTestDataSet.DataSetName = "VPBSTestDataSet"
        Me.VPBSTestDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BankNamesTestTableAdapter
        '
        Me.BankNamesTestTableAdapter.ClearBeforeFill = True
        '
        'AccountNamesTestTableAdapter
        '
        Me.AccountNamesTestTableAdapter.ClearBeforeFill = True
        '
        'BankNamesTableAdapterLive
        '
        Me.BankNamesTableAdapterLive.ClearBeforeFill = True
        '
        'AnalysisTestTableAdapter
        '
        Me.AnalysisTestTableAdapter.ClearBeforeFill = True
        '
        'GLCodeTestTableAdapter
        '
        Me.GLCodeTestTableAdapter.ClearBeforeFill = True
        '
        'CustomersTestTableAdapter
        '
        Me.CustomersTestTableAdapter.ClearBeforeFill = True
        '
        'UsersTestTableAdapter
        '
        Me.UsersTestTableAdapter.ClearBeforeFill = True
        '
        'BudgetBindingSource
        '
        Me.BudgetBindingSource.DataMember = "Budget"
        Me.BudgetBindingSource.DataSource = Me.VPBSDataSet
        '
        'BudgetTestTableAdapter
        '
        Me.BudgetTestTableAdapter.ClearBeforeFill = True
        '
        'CurrenciesTestTableAdapter
        '
        Me.CurrenciesTestTableAdapter.ClearBeforeFill = True
        '
        'DirbudTestTableAdapter
        '
        Me.DirbudTestTableAdapter.ClearBeforeFill = True
        '
        'VpbsArchiveDataSet
        '
        Me.VpbsArchiveDataSet.DataSetName = "VpbsArchiveDataSet"
        Me.VpbsArchiveDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BankNamesTableAdapterArc
        '
        Me.BankNamesTableAdapterArc.ClearBeforeFill = True
        '
        'AccountNamesTableAdapterArc
        '
        Me.AccountNamesTableAdapterArc.ClearBeforeFill = True
        '
        'AnalysisTableAdapterArc
        '
        Me.AnalysisTableAdapterArc.ClearBeforeFill = True
        '
        'GLCodeTableAdapterArc
        '
        Me.GLCodeTableAdapterArc.ClearBeforeFill = True
        '
        'CustomersTableAdapterArc
        '
        Me.CustomersTableAdapterArc.ClearBeforeFill = True
        '
        'UsersTableAdapterArc
        '
        Me.UsersTableAdapterArc.ClearBeforeFill = True
        '
        'DirbudTableAdapterArc
        '
        Me.DirbudTableAdapterArc.ClearBeforeFill = True
        '
        'CurrenciesTableAdapterArc
        '
        Me.CurrenciesTableAdapterArc.ClearBeforeFill = True
        '
        'BudgetTableAdapterArc
        '
        Me.BudgetTableAdapterArc.ClearBeforeFill = True
        '
        'DirbudTableAdapterLive
        '
        Me.DirbudTableAdapterLive.ClearBeforeFill = True
        '
        'AccountNamesTableAdapterLive
        '
        Me.AccountNamesTableAdapterLive.ClearBeforeFill = True
        '
        'GLCodeTableAdapterLive
        '
        Me.GLCodeTableAdapterLive.ClearBeforeFill = True
        '
        'AnalysisTableAdapterLive
        '
        Me.AnalysisTableAdapterLive.ClearBeforeFill = True
        '
        'UsersTableAdapterLive
        '
        Me.UsersTableAdapterLive.ClearBeforeFill = True
        '
        'CustomersTableAdapterLive
        '
        Me.CustomersTableAdapterLive.ClearBeforeFill = True
        '
        'BudgetTableAdapterLive
        '
        Me.BudgetTableAdapterLive.ClearBeforeFill = True
        '
        'CurrenciesTableAdapterLive
        '
        Me.CurrenciesTableAdapterLive.ClearBeforeFill = True
        '
        'frmSetup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ClientSize = New System.Drawing.Size(583, 454)
        Me.ControlBox = False
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmSetup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "VPBS - Setup"
        Me.GroupBox1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.DataGridViewAccountNames, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AccountNamesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VPBSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.DataGridViewBankNames, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BankNamesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        CType(Me.DataGridViewCustomers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        CType(Me.DataGridViewUsers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UsersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.DataGridViewAnalysisCodes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AnalysisBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        CType(Me.DataGridViewGLCodes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GLCodeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage10.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        CType(Me.DataGridViewBudgets, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DirbudBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox17.ResumeLayout(False)
        Me.GroupBox17.PerformLayout()
        CType(Me.DataGridViewCurrencies, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CurrenciesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VPBSTestDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BudgetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VpbsArchiveDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdChange As System.Windows.Forms.Button
    Friend WithEvents CmdNew As System.Windows.Forms.Button
    Friend WithEvents CmdDelete As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdOk As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents VPBSDataSet As VPBS13.VPBSDataSet
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents VPBSTestDataSet As VPBS13.VPBSTestDataSet
    Friend WithEvents BankNamesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents BankNamesTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.BankNamesTableAdapter
    Friend WithEvents DataGridViewBankNames As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txtBankName As System.Windows.Forms.TextBox
    Friend WithEvents txtShortBankName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewAccountNames As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAccountName As System.Windows.Forms.TextBox
    Friend WithEvents txtShortAccountName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents AccountNamesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AccountNamesTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.AccountNamesTableAdapter
    Friend WithEvents BankNamesTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.BankNamesTableAdapter
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAnalysisDesc As System.Windows.Forms.TextBox
    Friend WithEvents txtAnalysisCode As System.Windows.Forms.TextBox
    Friend WithEvents lblAnalysisDesc As System.Windows.Forms.Label
    Friend WithEvents lblAnalysisCode As System.Windows.Forms.Label
    Friend WithEvents DataGridViewAnalysisCodes As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AnalysisBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AnalysisTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.AnalysisTableAdapter
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents txtGLCodeDesc As System.Windows.Forms.TextBox
    Friend WithEvents txtGLCodeCode As System.Windows.Forms.TextBox
    Friend WithEvents lblGLCodeDesc As System.Windows.Forms.Label
    Friend WithEvents lblGLCodeCode As System.Windows.Forms.Label
    Friend WithEvents DataGridViewGLCodes As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents txtUserLevel As System.Windows.Forms.TextBox
    Friend WithEvents txtUserName As System.Windows.Forms.TextBox
    Friend WithEvents lblUserLevel As System.Windows.Forms.Label
    Friend WithEvents lblUserName As System.Windows.Forms.Label
    Friend WithEvents DataGridViewUsers As System.Windows.Forms.DataGridView
    Friend WithEvents ShortNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GLCodeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GLCodeTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.GLCodeTableAdapter
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCustName As System.Windows.Forms.TextBox
    Friend WithEvents txtShortCustName As System.Windows.Forms.TextBox
    Friend WithEvents lblCustName As System.Windows.Forms.Label
    Friend WithEvents lblCustShortName As System.Windows.Forms.Label
    Friend WithEvents DataGridViewCustomers As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustomersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CustomersTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.CustomersTableAdapter
    Friend WithEvents UsersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents UsersTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.UsersTableAdapter
    Friend WithEvents UserNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UserLevelDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PasswordDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblCurrentPassword As System.Windows.Forms.Label
    Friend WithEvents txtNewPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtOldPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblChangePassword As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox15 As System.Windows.Forms.GroupBox
    Friend WithEvents txtBudgetDesc As System.Windows.Forms.TextBox
    Friend WithEvents txtBudgetNo As System.Windows.Forms.TextBox
    Friend WithEvents lblBudgetDesc As System.Windows.Forms.Label
    Friend WithEvents lblBudgetNo As System.Windows.Forms.Label
    Friend WithEvents DataGridViewBudgets As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox16 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox17 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCurrencyDesc As System.Windows.Forms.TextBox
    Friend WithEvents txtCurrencyCode As System.Windows.Forms.TextBox
    Friend WithEvents lblCCYDesc As System.Windows.Forms.Label
    Friend WithEvents lblCCYCode As System.Windows.Forms.Label
    Friend WithEvents DataGridViewCurrencies As System.Windows.Forms.DataGridView
    Friend WithEvents BudgetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents BudgetTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.BudgetTableAdapter
    Friend WithEvents CurrenciesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CurrenciesTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.CurrenciesTableAdapter
    Friend WithEvents BudgetNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BudgetTypeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DescriptionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PeriodFromDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PeriodToDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartMonthDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RefreshReqdDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DirbudTestTableAdapter As VPBS13.VPBSTestDataSetTableAdapters.dirbudTableAdapter
    Friend WithEvents DirbudBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CodeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DescriptionDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TypeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DecimalPlacesDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BaseCCYDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtPeriodTo As System.Windows.Forms.TextBox
    Friend WithEvents txtPeriodFrom As System.Windows.Forms.TextBox
    Friend WithEvents lblPeriodTo As System.Windows.Forms.Label
    Friend WithEvents lblActivate As System.Windows.Forms.Label
    Friend WithEvents lblPeriodFrom As System.Windows.Forms.Label
    Friend WithEvents lblRefresh As System.Windows.Forms.Label
    Friend WithEvents lblBudgetStartMonth As System.Windows.Forms.Label
    Friend WithEvents lblBudgetType As System.Windows.Forms.Label
    Friend WithEvents cboActivate As System.Windows.Forms.ComboBox
    Friend WithEvents cboRefresh As System.Windows.Forms.ComboBox
    Friend WithEvents cboStartMonth As System.Windows.Forms.ComboBox
    Friend WithEvents cboBudgetType As System.Windows.Forms.ComboBox
    Friend WithEvents lblDorM As System.Windows.Forms.Label
    Friend WithEvents lblNofDecPlaces As System.Windows.Forms.Label
    Friend WithEvents lblBaseCCY As System.Windows.Forms.Label
    Friend WithEvents lblRate As System.Windows.Forms.Label
    Friend WithEvents txtBaseCCY As System.Windows.Forms.TextBox
    Friend WithEvents txtDorM As System.Windows.Forms.TextBox
    Friend WithEvents txtDecPlaces As System.Windows.Forms.TextBox
    Friend WithEvents txtRate As System.Windows.Forms.TextBox
    Friend WithEvents txtAddPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblAddPassword As System.Windows.Forms.Label
    Friend WithEvents lblVerifyPassword As System.Windows.Forms.Label
    Friend WithEvents txtVerifyPassword As System.Windows.Forms.TextBox
    Friend WithEvents VpbsArchiveDataSet As VPBS13.VpbsArchiveDataSet
    Friend WithEvents BankNamesTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.BankNamesTableAdapter
    Friend WithEvents AccountNamesTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.AccountNamesTableAdapter
    Friend WithEvents AnalysisTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.AnalysisTableAdapter
    Friend WithEvents GLCodeTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.GLCodeTableAdapter
    Friend WithEvents CustomersTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.CustomersTableAdapter
    Friend WithEvents UsersTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.UsersTableAdapter
    Friend WithEvents DirbudTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.dirbudTableAdapter
    Friend WithEvents CurrenciesTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.CurrenciesTableAdapter
    Friend WithEvents BudgetTableAdapterArc As VPBS13.VpbsArchiveDataSetTableAdapters.BudgetTableAdapter
    Friend WithEvents DirbudTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.dirbudTableAdapter
    Friend WithEvents AccountNamesTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.AccountNamesTableAdapter
    Friend WithEvents GLCodeTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.GLCodeTableAdapter
    Friend WithEvents AnalysisTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.AnalysisTableAdapter
    Friend WithEvents UsersTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.UsersTableAdapter
    Friend WithEvents CustomersTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.CustomersTableAdapter
    Friend WithEvents BudgetTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.BudgetTableAdapter
    Friend WithEvents CurrenciesTableAdapterLive As VPBS13.VPBSDataSetTableAdapters.CurrenciesTableAdapter
    Friend WithEvents ShortNameDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NameDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
