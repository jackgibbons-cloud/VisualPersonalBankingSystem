﻿Partial Class VPBSDataSet9
    Partial Class RecTransTempDataTable

    End Class

    Partial Class RecTransDataTable

    End Class

End Class
