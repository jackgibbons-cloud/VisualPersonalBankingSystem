﻿Partial Class BOOKSDataSet1
    Partial Class BooksDataTable

    End Class

End Class
